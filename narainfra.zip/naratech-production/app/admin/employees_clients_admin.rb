Trestle.resource(:employees_clients) do
  remove_action :show
  controller do
    def destroy
      @employee_client = EmployeesClient.find(params[:id])
      employee_id = @employee_client.employee_id
      @employee_client.destroy
      redirect_to "/admin/employees/#{employee_id}#!tab-Clients"
    end
  end
end
