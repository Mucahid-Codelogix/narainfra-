require 'roo'
Trestle.resource(:clients) do
  routes do
    get :specification_codes, on: :member
    post :create_contact_person, on: :member
    post :create_discipline, on: :member
    post :create_finance, on: :member
  end

  menu do
    group :Relatie, priority: 1 do
      item :clients, icon: "fas fa-user-tie", label: t("menu.clients"), priority: 2
    end
  end

  collection do
    model.order(client_name: :asc)
  end

  table do
    column :client_id, link: true
    column :client_name
    column :email
    column :phone
    column :address
    column :postal_code
    actions
  end

  form do |client|
    @active_tab = params[:tab] ? params[:tab].to_sym : :client_details
    tab :client_details, label: t("tabs.client_tabs.client_details") do
      next unless @active_tab == :client_details

      row do
        col(sm: 4) { number_field :client_id, min: 0, value: client.client_id || next_available_client_id }
        col(sm: 4) { text_field :client_name }
        col(sm: 4) { email_field :email }
      end
      row do
        col(sm: 4) { text_field :contactperson }
        col(sm: 4) { text_field :postal_code }
        col(sm: 4) { text_field :city }
      end
      row do
        col(sm: 4) { text_field :address }
        col(sm: 4) do
          telephone_field :phone, pattern: '(\+31\d{3,11}|0\d{5,13})', oninvalid: "this.setCustomValidity('#{t('validations.valid_phone_format')}')", oninput: "this.setCustomValidity('')"
        end
      end
      check_box :active
      render partial: "admin/shared/warning", locals: { text: "Deze opdrachtgever bestaat al" }
      render partial: "trestle/clients/hidden_field_for_warning_param"
    end

    unless client.new_record?
      tab :disciplines, label: t("tabs.client_tabs.disciplines") do
        render partial: "trestle/clients/add_discipline_button", locals: { client: client }
        disciplines = Discipline.where(client_id: client.id)
        table disciplines, admin: DisciplinesAdmin do |t|
          t.column :client, ->(discipline) { discipline.client.client_name }
          t.column :name
          actions
        end
      end
      tab :Contact_persons, label: t("tabs.client_tabs.contact_persons") do
        render partial: "admin/shared/add_contact_person_button", locals: { id: client.id, source: "clients" }
        table ClientContactPersonsAdmin.table, collection: ClientContactPerson.where(client_id: client.id).order(id: :asc)
      end
      tab :Finance, label: t("tabs.client_tabs.bank_details") do
        render partial: "admin/shared/add_finance_button", locals: { id: client.id, source: "clients" } if client.finance.blank?
        finances = Finance.where(client_id: client.id)
        table finances, admin: FinancesAdmin do |t|
          t.column :vat_number
          t.column :kvk_number
          t.column :vat
          t.column :c_account_percentage
          t.column :g_account_percentage
          actions
        end
      end
    end
  end

  controller do
    def create_contact_person
      client = Client.find(params[:id])

      redirect_to new_client_contact_persons_admin_path(client: client)
    end

    def create
      duplicate_name_allow_client = params[:client_warning].map { |cw| cw.split(',') }.flatten

      existing_client = Client.find_by(client_name: client_params[:client_name])
      duplicate_name_allow_client.include?(existing_client&.client_name)

      if duplicate_name_allow_client.include?(existing_client&.client_name)
        client = Client.new(client_params)
        if client.valid?
          super
        else
          render json: { errors: client.errors.full_messages }, status: :unprocessable_entity
        end
      elsif existing_client
        render json: { errors: "client already exist" }, status: :unprocessable_entity
      else
        client = Client.new(client_params)
        if client.valid?
          super
        else
          render json: { errors: client.errors.full_messages }, status: :unprocessable_entity
        end
      end
    end

    # def create
    #   puts "create method calling #{params}"
    #   client_warning = params[:client_warning]
    #   client_warning&.each do |client_name|
    #     puts "clientname===>#{client_name}"
    #   end
    #   existing_client = Client.find_by(client_name: client_params[:client_name])
    #   if existing_client
    #     render json: { errors: "client already exist" }, status: :unprocessable_entity
    #   end
    # end

    def create_discipline
      client = Client.find(params[:id])

      redirect_to new_disciplines_admin_path(client: client)
    end

    def create_finance
      client = Client.find(params[:id])

      redirect_to new_finances_admin_path(client: client)
    end

    private

    def client_params
      params.require(:client).permit(
        :client_name,
        :address,
        :postal_code,
        :email,
        :phone,
        :contactperson,
        :city,
        :client_id,
        :active
      )
    end
  end

  helper do
    def next_available_client_id
      starting_id = 1001
      next_id = starting_id
      while Client.exists?(client_id: next_id)
        next_id += 1
      end
      next_id
    end
  end
end
