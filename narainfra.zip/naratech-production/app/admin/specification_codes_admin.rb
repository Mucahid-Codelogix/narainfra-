Trestle.resource(:specification_codes) do
  collection do
    SpecificationCode.order(id: :asc)
  end

  table do
    column :select, header: false, sortable: false do |specification_code|
      check_box_tag "selected_ids[]", specification_code.id, false, class: "select-checkbox"
    end
    column :specification_code, class: 'table-codes', link: true
    column :description, class: 'table-font-description', &:description
    column :measurement
    column :price, class: 'table-font-code' do |spec_code|
      spec_code.client.euro_format(spec_code.client.format_number(spec_code.price))
    end
    column :client do |c|
      c.client.client_name
    end
    actions
  end

  form do |code|
    flash.now[:error] = code.errors.full_messages.join(', ') if code.errors.any?
    if params[:discipline]
      discipline_id = params[:discipline].to_i
      discipline = Discipline.find(discipline_id)
      client = discipline.client
    elsif code&.discipline_id
      discipline_id = code.discipline_id.to_i
      discipline = Discipline.find(discipline_id)
      client = discipline.client
    end

    hidden_field :client_id, value: client.id
    hidden_field :discipline_id, value: discipline_id

    row do
      col(sm: 6) { text_field :specification_code }
      col(sm: 6) { text_field :measurement }
    end

    row do
      col(sm: 6) { text_field :description }
      col(sm: 6) { number_field :price, step: 'any' }
    end
  end

  controller do
    def create
      specification_code = SpecificationCode.new(specification_code_params)
      discipline = specification_code.discipline

      if specification_code.save
        redirect_to "/admin/disciplines/#{discipline.id}?tab=SpecificationCode#!tab-SpecificationCode"
      else
        flash[:error] = specification_code.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def update
      specification_code = SpecificationCode.find(params[:id])
      specification_code.assign_attributes(specification_code_params)
      discipline = specification_code.discipline

      if specification_code.save
        redirect_to "/admin/disciplines/#{discipline.id}?tab=SpecificationCode#!tab-SpecificationCode"
      else
        flash[:error] = specification_code.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def destroy
      @specification_code = SpecificationCode.find(params[:id])
      discipline = @specification_code.discipline
      @specification_code.destroy
      redirect_to "/admin/disciplines/#{discipline.id}?tab=SpecificationCode#!tab-SpecificationCode"
    end

    private

    def specification_code_params
      params.require(:specification_code).permit(:client_id, :discipline_id, :specification_code, :measurement, :description, :price)
    end
  end
end
