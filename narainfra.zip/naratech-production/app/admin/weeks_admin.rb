require 'erb'
Trestle.resource(:weeks) do
  menu do
    item :control_projects, icon: "fas fa-clipboard-check", label: 'Controle productie', priority: 4
  end
  routes do
    get :check_specification_code, on: :collection
    get :get_specification_code, on: :collection
    get :check_purchase_orders_data, on: :collection
    get :get_weeks, on: :collection
    get :get_weeks_for_total_overview, on: :collection
    post :create_pdf_generator, on: :member
    post :update_statuses, on: :collection
  end
  table do
    column :start_date
    column :end_date
    column :year
    column :week_number
    column :project, ->(week) { week.project.projectnumber }
    actions
  end

  form do |week|
    tab :Week_Details do
      row do
        col(sm: 4) { text_field :project_number, value: week.project.projectnumber, disabled: true, id: "project-number-field", data: { project_id: week.project } }
        col(sm: 4) { text_field :project_performer, value: week.project.projectperformer, disabled: true }
        col(sm: 4) { text_field :project_place, value: week.project.place, disabled: true }
      end
      row do
        col(sm: 4) { number_field :week_number, { id: "week-number-field", disabled: true, data: { week_id: week.id } } }
        col(sm: 4) { text_field :start_date, { value: week.start_date.strftime('%d/%m/%Y'), disabled: true } }
        col(sm: 4) { text_field :end_date, { value: week.end_date.strftime('%d/%m/%Y'), disabled: true } }
      end
      row do
        col(sm: 4) { text_field :year, { disabled: true } }
        col(sm: 4) { text_field :note } if week.note.present?
      end
      label :description, t("activerecord.attributes.week.description"), class: "control-label"
      rich_text_area :description
    end

    if week.project.contract_sum == true && week.purchase_orders.blank?
      total_cumulatief = week.get_comulatief_project_contract_type(week)
      cumulative_week = total_cumulatief - week.project.contract_sum_amount
      render partial: "trestle/purchase_orders/purchase_order_table_for_contract_sum_project",
             locals: { total_budget: week.project.contract_sum_amount, project_type: "contract", total_cumulatief: total_cumulatief, cumulative_week: cumulative_week }
    elsif week.project.contract_sum == true
      table week.purchase_orders.order(id: :asc), admin: PurchaseOrdersAdmin, class: "purchase-orders-table", id: "purchase-orders-table" do |t|
        t.column :description, sort: false do |purchase_order|
          text_field_tag "purchase_order_amount[#{purchase_order.id}][description]", purchase_order.description, id: "description-field-#{purchase_order.id}",
                                                                                                                 class: "specification-code-field form-control text-field-description",
                                                                                                                 data: { total_budget: purchase_order.total_budget.present? && purchase_order.total_budget > 0 ? purchase_order.total_budget : week.project.contract_sum_amount, project_type: "contract" }
        end

        t.column :amount_for_project_contract_type, sort: false do |purchase_order|
          number_field_tag "purchase_order_amount[#{purchase_order.id}][amount]", purchase_order.amount, class: "amount-field"
        end
        t.column :total_budget, ->(purchase_order) { week.project.euro_format(week.project.format_number(purchase_order.total_budget&.ceil(2))) }, class: "total-budget"
        t.column :cumulative_total, sort: false, class: "cumulatief-total" do |purchase_order|
          if week.project.contract_sum == true && week.project
            week.project.euro_format(week.project.format_number(week.show_comulatief_project_contract_type(week.project.id, week.week_number, purchase_order.amount)))
          else
            "N/A"
          end
        end
        t.column :cumulative_week, sort: false, class: "cumulatief-week" do |purchase_order|
          if week.project.contract_sum == true && week.project
            week.project.euro_format(week.project.format_number(week.show_comulatief_project_contract_type(week.project.id, week.week_number,
                                                                                                           purchase_order.amount) - purchase_order.total_budget))
          else
            "N/A"
          end
        end
      end
    else
      table week.purchase_orders.order(id: :asc), admin: PurchaseOrdersAdmin, class: "purchase-orders-table", id: "purchase-orders-table" do |t|
        t.column :specification_code, sort: false do |purchase_order|
          spec_code = purchase_order.specification_code
          description = spec_code.description.present? ? " - #{spec_code.description}" : ""
          specification_display = "#{spec_code.specification_code}#{description}"
          text_field_tag "purchase_order_code[#{purchase_order.id}][specification_code]", specification_display, id: "specification-code-field-#{purchase_order.id}",
                                                                                                                 class: "specification-code-field form-control text-field-specificaiton-code", readonly: true,
                                                                                                                 data: { code_id: spec_code.id, price: purchase_order.price }
        end
        t.column :measurement, sort: false do |purchase_order|
          spec_code = purchase_order.specification_code
          hidden_field_html = hidden_field_tag "purchase_order_code[#{purchase_order.id}][specification_code_id]",
                                               spec_code.id,
                                               id: "specification-code-id-field-#{purchase_order.id}"

          "#{hidden_field_html}#{spec_code.measurement}".html_safe
        end
        t.column :price, ->(purchase_order) { week.project.euro_format(week.project.format_number(purchase_order.price&.ceil(2))) }, class: "price-column table-font-code"
        t.column :amount, sort: false do |purchase_order|
          number_field_tag "purchase_order_amount[#{purchase_order.id}][amount]", purchase_order.amount, class: "amount-field"
        end
        t.column :total_budget, ->(purchase_order) { week.project.euro_format(week.project.format_number(purchase_order.total_budget&.ceil(2))) }, class: "total-budget"
        t.column :cumulative_total, sort: false, class: "cumulatief-total" do |purchase_order|
          if purchase_order.specification_code && week.project
            week.project.euro_format(week.project.format_number(week.show_comulatief(week.project.id, week.week_number, purchase_order.specification_code, purchase_order.amount)))
          else
            "N/A"
          end
        end
        t.column :cumulative_week, sort: false, class: "cumulatief-week" do |purchase_order|
          if purchase_order.specification_code && week.project
            week.project.euro_format(week.project.format_number(week.show_comulatief(week.project.id, week.week_number, purchase_order.specification_code,
                                                                                     purchase_order.amount) - purchase_order.total_budget))
          else
            "N/A"
          end
        end
        t.column :total, ->(purchase_order) { week.project.euro_format(week.project.format_number(purchase_order.total_amount&.ceil(2))) }, class: "total-column table-font-code"
      end

    end
  end

  controller do
    before_action :validate_purchase_orders, only: [:update]

    def create_pdf_generator
      week = Week.find(params[:id])
      schedulings = EmployeeScheduling.where(week_id: week.id).order(id: :desc)
      extra_costs = ExtraCost.where(week_id: week.id).order(id: :desc)
      aka_cost = ProjectSetting.first&.ak_cost.present? ? ProjectSetting.first&.ak_cost : 15
      project = week.project
      discipline = Discipline.find(params[:discipline_id]) if params[:discipline_id]
      template = params[:template]
      pdf_filename =
        if %w[tkc_cost_pdf totaloverview].include?(template)
          "#{week.project.projectnumber} W #{week.week_number} TKC #{week.project.address}.pdf"
        elsif project.tbs?
          "#{week.project.projectnumber}_#{week.week_number}_#{week.project.place}.pdf"
        else
          "#{week.project.projectnumber}_#{week.week_number}_#{week.project.address}.pdf"
        end
      template_path = "#{Rails.root}/app/views/trestle/weeks/#{template}.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      image_path_crop = "#{Rails.root}/app/assets/images/sidelogo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))
      base64_encoded_image_crop = Base64.strict_encode64(File.read(image_path_crop))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)
      if params[:preview].present?
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'inline')
      else
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'attachment')
      end

      # redirect_to "/admin/projects/8?tab=weeks#!tab-weeks"
    end

    def validate_purchase_orders
      week = Week.find(params[:id])
      if week.project.contract_sum == true
        purchase_order_amounts = params[:purchase_order_amount]
        purchase_order_amounts&.each do |purchase_order_id, amount_params|
          purchase_order = week.purchase_orders.find_by(id: purchase_order_id)
          amount = amount_params[:amount]
          description = amount_params[:description]
          if purchase_order && amount.present?
            total_budget = if purchase_order.total_budget.present? && purchase_order.total_budget > 0
                             purchase_order.total_budget
                           else
                             week.project.contract_sum_amount
                           end
            purchase_order.update(amount: amount, description: description, total_budget: total_budget, total_amount: amount)
          else
            PurchaseOrder.create(
              week: week,
              project: week.project,
              amount: amount,
              description: description,
              total_budget: week.project.contract_sum_amount,
              total_amount: amount
            )
          end
        end
      else
        purchase_order_amounts = params[:purchase_order_amount]
        specification_codes = params[:purchase_order_code]
        specification_codes&.each do |purchase_order_id, code_params|
          purchase_order = week.purchase_orders.find_by(id: purchase_order_id)
          specification_code_id = code_params[:specification_code_id].to_i
          specification_code = week.project.client.specification_codes.find_by(id: specification_code_id, client: week.project.client)
          if purchase_order && specification_code
            purchase_order.update(specification_code: specification_code)
            purchase_order.update(total_amount: BigDecimal(purchase_order.amount.to_s) * BigDecimal(specification_code.price.to_s))
          end
        end

        purchase_order_amounts&.each do |purchase_order_id, amount_params|
          purchase_order = week.purchase_orders.find_by(id: purchase_order_id)
          amount = amount_params[:amount]
          if purchase_order && amount.present?
            purchase_order.update(amount: amount)
            purchase_order.update(total_amount: BigDecimal(amount.to_s) * BigDecimal(purchase_order.specification_code.price.to_s))
          end
        end
      end

      week.update(description: params[:week][:description])
      # redirect_to "/admin/projects/#{week.project.id}?tab=weeks#!tab-weeks"
    end

    def check_specification_code
      project_id = params[:project_id]
      week_id = params[:week_id]
      price = params[:price]
      specification_code_id = params[:code_id].to_i
      week = Week.find(week_id)
      total_comulatief_amount = 0

      code = week.project.client.specification_codes.find_by(id: specification_code_id, client: week.project.client)
      purchase_order = PurchaseOrder.find_by(
        project_id: week.project.id,
        specification_code_id: code.id,
        week_id: week.id,
        price: price
      )
      if code
        price = purchase_order.price
        measurement = code.measurement

        total_comulatief_amount = calculate_total_sum_amount(project_id, week_id, code)

        render json: { price: price, measurement: measurement, total_comulatief_amount: total_comulatief_amount }
      else
        render json: { error: "Specification code not found" }, status: :not_found
      end
    end

    def calculate_total_sum_amount(project_id, week_id, code)
      project = Project.find(project_id)
      week = Week.find(week_id)
      week_number = week.week_number
      previous_weeks = project.weeks.where("week_number < ?", week_number)

      if previous_weeks.present?
        purchase_orders = PurchaseOrder.joins(:week).where(specification_code: code, weeks: { id: previous_weeks })
        total_sum_amount = purchase_orders.sum(:amount)
      else
        total_sum_amount = 0
      end

      total_sum_amount
    end

    def get_specification_code
      project_id = params[:project_id]
      project = Project.find(project_id)

      specification_codes = SpecificationCode.joins(:discipline).where(disciplines: { id: project.disciplines.pluck(:id) })

      if specification_codes
        render json: { specification_codes: specification_codes }
      else
        render json: { error: "Specification code not found" }, status: :not_found
      end
    end

    def check_purchase_orders_data
      project_id = params[:project_id]
      week_id = params[:week_id]
      week = Week.find(week_id)
      project = week.project
      total_comulatief_amount = 0

      if project.purchase_orders.any?
        week_number = week.week_number
        previous_weeks = project.weeks.where("week_number < ?", week_number)
        if previous_weeks.present?
          purchase_orders = PurchaseOrder.joins(:week).where(project_id: project_id, weeks: { id: previous_weeks })
          total_comulatief_amount = purchase_orders.sum(:amount)
        else
          total_comulatief_amount = 0
        end
      end

      render json: { total_comulatief_amount: total_comulatief_amount }
    end

    def get_weeks
      status = params[:status]
      weeks = if status == "all"
                Week.includes(:project).order('projects.projectnumber ASC, weeks.week_number ASC').kaminari_page(params[:page]).per(10)
              else
                Week.where(status: status).includes(:project).order('projects.projectnumber ASC, weeks.week_number ASC').kaminari_page(params[:page]).per(10)
              end
      count = if status == "all"
                Week.all.count
              else
                Week.where(status: status).includes(:project).order('projects.projectnumber ASC, weeks.week_number ASC').count
              end
      response = weeks.as_json(
        include: {
          project: {
            include: {
              project_disciplines: {
                include: :discipline
              }
            }
          }
        },
        methods: [:turnover_week, :total_overview_turn_over]
      )

      render json: { weeks: response, count: count }
    end

    def update_statuses
      status = params[:status]
      week_id = params[:week_id]
      note = params[:note]

      if week_id.present? && note.present?
        week = Week.find(week_id)
        week.update(status: 'pending', note: note)
      end

      status&.each do |week_id, status|
        if status.present? && status != "pending"
          week = Week.find(week_id)
          week.update(status: status, note: nil)
        end
      end
    end

    def get_weeks_for_total_overview
      project = Project.find(params[:project_id])
      project_settings = ProjectSetting.first
      weeks = Week.where(project_id: project.id).order('year ASC, week_number ASC')

      all_weeks_data = weeks.map { |week| week_data(week, project) }
      zero_weeks = all_weeks_data.select { |week| all_values_zero?(week) }
      non_zero_weeks = all_weeks_data.reject { |week| all_values_zero?(week) }

      render json: {
        zero_weeks: zero_weeks,
        non_zero_weeks: non_zero_weeks,
        project: project,
        project_settings: project_settings
      }
    end

    def week_data(week, project)
      {
        id: week.id,
        weekNumber: week.week_number,
        turnOverWeek: week.calculate_turn_over_week(week, project),
        totalTkcCostWeek: week.calculate_total_tkc_cost_week(week, project),
        totalRevenue: week.calculate_total_revenue(week, project),
        otherCost: week.calculate_other_cost(week, project),
        totalCostWeekEmployee: week.calculate_total_cost_week_employee(week, project),
        totalExtraCostWeek: week.calculate_total_extra_cost_week(week, project),
        totalCost: week.calculate_total_cost(week, project),
        profit: week.calculate_profit(week, project)
      }
    end

    def all_values_zero?(week)
        week[:turnOverWeek].zero? &&
        week[:totalTkcCostWeek].zero? &&
        week[:totalRevenue].zero? &&
        week[:otherCost].zero? &&
        week[:totalCostWeekEmployee].zero? &&
        week[:totalExtraCostWeek].zero? &&
        week[:totalCost].zero? &&
        week[:profit].zero?
    end

    # def get_weeks_for_total_overview
    #   project = Project.find(params[:project_id])
    #   project_settings = ProjectSetting.first
    #   weeks = Week.where(project_id: project.id).order('year ASC, week_number ASC')
    #   render json: { weeks: weeks.map { |week| week_data(week, project) }, project: project, project_settings: project_settings }
    # end

    # def week_data(week, project)
    #   {
    #     id: week.id,
    #     weekNumber: week.week_number,
    #     turnOverWeek: week.calculate_turn_over_week(week, project),
    #     totalTkcCostWeek: week.calculate_total_tkc_cost_week(week, project),
    #     totalRevenue: week.calculate_total_revenue(week, project),
    #     otherCost: week.calculate_other_cost(week, project),
    #     totalCostWeekEmployee: week.calculate_total_cost_week_employee(week, project),
    #     totalExtraCostWeek: week.calculate_total_extra_cost_week(week, project),
    #     totalCost: week.calculate_total_cost(week, project),
    #     profit: week.calculate_profit(week, project),
    #   }
    # end

    def destroy
      @week = Week.find(params[:id])
      @week.destroy
      redirect_to projects_admin_path(@week.project)
    end
  end
end
