Trestle.resource(:contractor_finances) do
  collection do
    ContractorFinance.order(id: :asc)
  end

  table do
    column :vat_number
    column :kvk_number
    column :c_account_percentage
    column :g_account_percentage
    column :vat
    column :contractor do |c|
      c.contractor.contractor_name
    end
    actions
  end

  form do |finance|
    flash.now[:error] = finance.errors.full_messages.join(', ') if finance.errors.any?
    if params[:contractor]
      contractor_id = params[:contractor].to_i
      contractor = Contractor.find(contractor_id)
    elsif finance&.contractor_id
      contractor_id = finance.contractor_id.to_i
      contractor = Contractor.find(contractor_id)
    end

    hidden_field :contractor_id, value: contractor.id

    row do
      col(sm: 4) { text_field :vat_number }
      col(sm: 4) { number_field :kvk_number, min: 0 }
      col(sm: 4) { number_field :vat, min: 0 }
    end

    row do
      col(sm: 4) { number_field :c_account_percentage, min: 0, step: '0.01' }
      col(sm: 4) { number_field :g_account_percentage, min: 0, disabled: true }
      col(sm: 4) { number_field :payment_term_value, min: 0 }
      col(sm: 4) { text_field :iban, label: "IBAN" }
      hidden_field :g_account_percentage, id: "g_account_percentage_hidden"
    end
    row do
      col(sm: 12) do
        "<div><strong>BTW verlegd</strong> <i class='fas fa-question-circle' style='color:blue;'></i></div>".html_safe
      end
    end
    row do
      col(sm: 4) { check_box :vat_reversed, label: "Ja" }
    end
  end

  controller do
    def create
      finance = ContractorFinance.new(finance_params)
      contractor = finance.contractor

      if finance.save
        redirect_to "/admin/contractors/#{contractor.id}?tab=Finance#!tab-Finance"
      else
        flash[:error] = finance.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def update
      finance = ContractorFinance.find(params[:id])
      finance.assign_attributes(finance_params)
      contractor = finance.contractor

      if finance.save
        redirect_to "/admin/contractors/#{contractor.id}?tab=Finance#!tab-Finance"
      else
        flash[:error] = finance.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def destroy
      @finance = ContractorFinance.find(params[:id])
      contractor = @finance.contractor
      @finance.destroy
      redirect_to "/admin/contractors/#{contractor.id}?tab=Finance#!tab-Finance"
    end

    private

    def finance_params
      params.require(:contractor_finance).permit(:contractor_id, :vat_number, :kvk_number, :c_account_percentage, :g_account_percentage, :vat, :vat_reversed, :payment_term_value, :iban)
    end
  end
end
