Trestle.resource(:roles) do
  table do
    column :role_title
    actions
  end

  form do |_role|
    text_field :role_title
  end

  controller do
    def create
      @role = Role.new(params.require(:role).permit(:role_title))
      if @role.save
        flash[:message] = "Rol is succesvol aangemaakt"
      else
        flash[:error] = @role.errors.full_messages.to_sentence
      end
      respond_to do |format|
        format.js { render js: "location.reload();" }
      end
    end

    def destroy
      @role = Role.find(params[:id])
      @role.destroy
      redirect_to "/admin/invoice_settings?type=roles"
    end
  end
end
