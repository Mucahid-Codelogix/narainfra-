Trestle.resource(:debit_invoice_quotes) do
  menu do
    group :Facturen, priority: 3 do
      item :debit, icon: "fa fa-money-bill-wave", label: "Offerte", priority: 3
    end
  end
  routes do
    post :pdf_download, on: :member
    get :fetch_invoices_client, on: :collection
    get :fetch_invoices, on: :collection
  end
  table do
    column :quote_number
    column :description
    column :invoice_date do |invoice|
      invoice.invoice_date&.strftime("%d/%m/%Y")
    end
    column :expiration_date do |invoice|
      invoice.expiration_date&.strftime("%d/%m/%Y")
    end
    column :totaal do |invoice|
      vat = 21
      vat_reversed = false
      if invoice&.client&.finance.present?
        vat = invoice.client.finance.vat
        vat_reversed = invoice.client.finance.vat_reversed
      end
      vat = (vat * invoice&.total) / 100
      total_amount = if vat_reversed == false
                       vat + invoice&.total
                     else
                        invoice&.total
                     end
      invoice.euro_format(invoice.format_number(total_amount.ceil(2)))
    end
    # pji
    # actions do |toolbar, instance, admin|
    #   link_to "Exporteer PDF", admin.path(:pdf_download, id: instance.id), method: :post, class: "btn btn-primary"
    # end
    actions do |_toolbar, instance, admin|
      "<div>
          <a href='#{admin.path(:pdf_download, id: instance.id, preview: true)}' data-method='post' class='btn btn-primary' target='_blank' rel='nofollow'>
            <i class='fas fa-eye mr-1'></i>
          </a>
          <a href='#{admin.path(:pdf_download, id: instance.id)}' data-method='post' class='btn btn-primary' rel='nofollow'>
            #{t('buttons.weeks.export_pdf')}
          </a>
        </div>".html_safe
    end
  end

  form do |invoice|
    flash.now[:error] = invoice.errors.full_messages.join(', ') if invoice.errors.any?
    hidden_field :payment_term, value: invoice.payment_term, id: 'payment_term_value_display_invoice'
    disabled_fields = true unless invoice.new_record?
    if invoice.new_record?
      invoice_setting = InvoiceSetting.first

      last_invoice = DebitInvoiceQuote.where(invoice_number_digits: 3, year: Date.current.year, invoice_number_character: "").last
      if last_invoice.present?
        new_invoice_number = last_invoice.digits.to_i + 1
        new_invoice_number = new_invoice_number.to_s.rjust(3, '0')
        invoice_number = "#{Date.current.year}#{new_invoice_number}"
      else
        invoice_number = "#{Date.current.year}001"
      end

      if invoice_setting.present?
        last_invoice = if invoice_setting.characters.present?
                         DebitInvoiceQuote.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year,
                                                 invoice_number_character: invoice_setting.characters).last
                       elsif invoice_setting.characters.nil?
                         DebitInvoiceQuote.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year, invoice_number_character: nil).last
                       else
                         DebitInvoiceQuote.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year, invoice_number_character: "").last
                       end
        if last_invoice.present?
          new_invoice_number = last_invoice.digits.to_i + 1
          new_invoice_number = new_invoice_number.to_s.rjust(invoice_setting.digits_length_before_type_cast, '0')
          invoice_number = "#{invoice_setting.characters}#{invoice_setting.characters.present? ? '-' : invoice_setting.characters}#{invoice_setting.year}#{new_invoice_number}"
        else
          new_invoice_number = 1
          new_invoice_number = new_invoice_number.to_s.rjust(invoice_setting.digits_length_before_type_cast, '0')
          invoice_number = "#{invoice_setting.characters}#{invoice_setting.characters.present? ? '-' : invoice_setting.characters}#{invoice_setting.year}#{new_invoice_number}"
        end
        hidden_field :invoice_number_character, value: invoice_setting.characters.present? ? invoice_setting.characters : ""
        hidden_field :year, value: invoice_setting.year
      else
        hidden_field :year, value: Date.current.year
        hidden_field :invoice_number_character, value: ""
      end
    end

    row do
      col(sm: 3) do
        select :client_id, Client.where(active: true).map { |c|
                             [c.client_name, c.id]
                           }, label: t("activerecord.attributes.debit_invoice.client"), prompt: t("prompt.invoice.select_client"), disabled: disabled_fields
      end
      render partial: "admin/shared/create_client_button", locals: { source: "invoices", css_class: "create-client-button-invoice" }
      col(sm: 4) { text_field :quote_number, value: invoice.quote_number.present? ? invoice.quote_number : invoice_number, disabled: invoice.id.present? }
      col(sm: 4) { text_field :description }
    end
    row do
      col(sm: 4) do
        render partial: "admin/shared/date_field", locals: {
          label: t("activerecord.attributes.debit_invoice.invoice_date"),
          field_name: "debit_invoice_quote[invoice_date]",
          field_id: "invoice_invoice_date",
          formatted_value: invoice.invoice_date&.present? ? invoice.invoice_date&.strftime('%d/%m/%Y') : Time.now.in_time_zone('Amsterdam').strftime('%d/%m/%Y')
        }
      end
      col(sm: 4) do
        render partial: "admin/shared/date_field", locals: {
          label: t("activerecord.attributes.debit_invoice.expiration_date"),
          field_name: "debit_invoice_quote[expiration_date]",
          field_id: "invoice_expiration_date",
          formatted_value: invoice.expiration_date&.present? ? invoice.expiration_date&.strftime('%d/%m/%Y') : Time.now.in_time_zone('Amsterdam').strftime('%d/%m/%Y'),
          disabled: true
        }
      end
    end

    table invoice.debit_invoice_quote_details.order(id: :asc), admin: DebitInvoiceQuoteDetailsAdmin, class: "invoice-details-table", id: "invoice-details-table" do |t|
      t.column :amount, sort: false do |invoice_detail|
        "<div>
            #{number_field_tag "invoice_details[#{invoice_detail.id}][amount]", invoice_detail.amount, class: 'amount-field-invoice-detail form-control text-currency'}
          </div>".html_safe
      end
      t.column :description, sort: false do |invoice_detail|
        text_field_tag "invoice_details[#{invoice_detail.id}][description]", invoice_detail.description, id: "description-#{invoice_detail.id}", class: "invoice-detail-description form-control"
      end
      t.column :unit, sort: false do |invoice_detail|
        text_field_tag "invoice_details[#{invoice_detail.id}][unit]", invoice_detail.unit, id: "unit-#{invoice_detail.id}", class: "invoice-detail-unit form-control"
      end
      t.column :price_excluding_vat, sort: false do |invoice_detail|
        "<div class='currency-wrap'>
            <span class='currency-code'>€</span>
            #{number_field_tag "invoice_details[#{invoice_detail.id}][price]", invoice_detail.price, class: 'price-field-invoice-detail form-control text-currency', step: 'any'}
          </div>".html_safe
      end

      t.column :vat, lambda { |_invoice_detail|
        "#{invoice&.client&.finance.present? ? invoice&.client&.finance&.vat : 0}% "
      }, class: "vat-column-invoice-detail table-font-code"
      t.column :price_including_vat, lambda { |invoice_detail|
                                       vat = 21
                                       vat_reversed = false
                                       if invoice&.client&.finance.present?
                                         vat = invoice.client.finance.vat
                                         vat_reversed = invoice.client.finance.vat_reversed
                                       end
                                       vat = (vat * invoice_detail&.total_amount) / 100
                                       total_amount = if vat_reversed == false
                                                        vat + invoice_detail&.total_amount
                                                      else
                                                        invoice_detail&.total_amount
                                                      end
                                       invoice_detail.debit_invoice_quote.client.euro_format(invoice_detail.debit_invoice_quote.client.format_number(total_amount&.ceil(2)))
                                     }, class: "total-column-invoice-detail table-font-code"

      t.column :action, sort: false do |invoice_detail|
        button_tag "Delete", type: "button", class: "btn btn-danger invoice-delete-button", data: { invoice_detail_id: invoice_detail.id, source: "debit-invoice-quote" }
      end
    end
    render partial: "admin/shared/add_row", locals: { id: "add-invoice" }
  end

  controller do
    before_action :invoice_details_calculation, only: [:update]

    def create
      invoice = DebitInvoiceQuote.new(invoice_params)
      invoice_number = invoice.quote_number
      invoice_setting = InvoiceSetting.first
      pattern = if invoice_setting.present?
                  /\d{2}(\d+)$/
                else
                  /\d{4}(\d+)$/
                end
      match = invoice_number.match(pattern)
      if match
        digits_after_year = match[1]
        digits_after_year_length = digits_after_year.length
        invoice.invoice_number_digits = digits_after_year_length
        invoice.digits = digits_after_year
      end
      if invoice.save
        @invoice_id = invoice.id
        invoice_details_calculation
        redirect_to debit_invoice_quotes_admin_index_path
      else
        render json: { errors: invoice.errors.full_messages }, status: :unprocessable_entity
        # super
      end
    end

    def invoice_details_calculation
      id = params[:id] || @invoice_id
      total = 0
      invoice = DebitInvoiceQuote.find(id)
      invoice_details = params[:invoice_details]

      invoice_details&.each do |invoice_detail_id, detail_params|
        invoice_detail = invoice.debit_invoice_quote_details.find_by(id: invoice_detail_id)
        total += BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
        if invoice_detail.present?
          invoice_detail.update(
            description: detail_params[:description],
            unit: detail_params[:unit],
            amount: detail_params[:amount],
            price: detail_params[:price],
            total_amount: BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
          )
        else
          DebitInvoiceQuoteDetail.create(
            debit_invoice_quote: invoice,
            description: detail_params[:description],
            unit: detail_params[:unit],
            amount: detail_params[:amount],
            price: detail_params[:price],
            total_amount: BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
          )
        end
      end
      invoice.update(total: total)
      invoice_pdf_creater(id)
    end

    # def fetch_weeks_and_codes
    #   project = Project.find(params[:id])
    #   weeks = project.weeks
    #   specification_codes = project.specification_codes
    #   render json: { weeks: weeks, specification_codes: specification_codes }
    # end

    def invoice_pdf_creater(id)
      invoice = DebitInvoiceQuote.find(id)
      invoice_details = invoice&.debit_invoice_quote_details
      client = invoice.client
      template = params[:template]
      pdf_filename = "#{invoice.quote_number}-#{invoice.client.client_name}.pdf"
      template_path = "#{Rails.root}/app/views/trestle/invoice/debit_invoice_quote_pdf.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)

      invoice.invoice_pdf.attach(io: StringIO.new(pdf), filename: pdf_filename, content_type: 'application/pdf')
    end

    def pdf_download
      invoice = DebitInvoiceQuote.find(params[:id])
      invoice_details = invoice&.debit_invoice_quote_details
      client = invoice.client
      template = params[:template]
      pdf_filename = "#{invoice.quote_number}-#{invoice.client.client_name}.pdf"
      template_path = "#{Rails.root}/app/views/trestle/invoice/debit_invoice_quote_pdf.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)

      if params[:preview].present?
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'inline')
      else
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'attachment')
      end
      # redirect_to "/admin/projects/8?tab=weeks#!tab-weeks"
    end

    def fetch_finances
      client = Client.find(params[:id])
      finance = client.finance
      render json: { finance: finance }
    end

    def fetch_invoices_client
      client_id = params[:client_id]
      invoices = DebitInvoiceQuote.where(client_id: client_id)
      count = invoices.count
      invoices = invoices.order(id: :desc).kaminari_page(params[:page]).per(100)
      render json: { invoices: invoices.as_json(include: { client: { include: :finance }, debit_invoice_quote_details: {} }), count: count }
    end

    def fetch_invoices
      invoices = DebitInvoiceQuote.includes(client: :finance, debit_invoice_quote_details: {})
      count = invoices.count
      invoices = invoices.order(id: :desc).kaminari_page(params[:page]).per(100)
      clients_with_invoices = Client.joins(:debit_invoice_quotes).distinct
      render json: { invoices: invoices.as_json(include: { client: { include: :finance }, debit_invoice_quote_details: {} }), count: count, clients: clients_with_invoices }
    end

    private

    def invoice_params
      params.require(:debit_invoice_quote).permit(:client_id, :quote_number, :description, :invoice_date, :expiration_date, :payment_term, :vat, :invoice_number_character, :year)
    end
  end
end
