Trestle.resource(:projects) do
  menu do
    item :projects, icon: "fa fa-project-diagram", label: t("menu.projects"), priority: 3
  end

  collection do
    Project.order(id: :desc)
  end

  scopes do
    scope :all, default: true, label: t('scopes.projects.all')
    scope :archived, -> { Project.where(archived: true) }, label: t('scopes.projects.archived')
    scope :active, -> { Project.where("end_date >= ?", Date.today) }, label: t('scopes.projects.active')
    scope :inactive, -> { Project.where("end_date < ?", Date.today) }, label: t('scopes.projects.inactive')
    scope :tbs, -> { Project.where(tbs: true) }
    scope :contract_sum, -> { Project.where(contract_sum: true) }, label: "Aanneemsom"
  end

  search do |query|
    if query
      collection.where("LOWER(projectnumber) LIKE ?", "%#{query.downcase}%")
    else
      collection
    end
  end

  authorize do
    actions :new, :show, :create, :index, :edit, :update, :destroy, :create_employee_schedule, :create_tkc_cost, :create_extra_cost, :create_plans, :update_pending_status, :create_spec_codes,
            :fetch_disciplines, :get_specification_codes, :get_specification_code do
      current_user.role == "admin"
    end
  end

  routes do
    post :create_employee_schedule, on: :member
    post :create_tkc_cost, on: :member
    post :create_extra_cost, on: :member
    post :create_plans, on: :member
    post :update_pending_status, on: :collection
    post :create_spec_codes, on: :member
    get :fetch_disciplines, on: :collection
    get :get_specification_codes, on: :collection
    get :get_specification_code, on: :collection
  end

  table do
    column :projectnumber, align: :center
    column :supervisor
    column :address
    column :place
    column :start_date do |project|
      project.start_date.strftime("%d/%m/%Y")
    end
    column :end_date do |project|
      project.end_date.strftime("%d/%m/%Y")
    end
    column :client, ->(project) { project.client.client_name }
  end

  form do |project|
    flash.now[:error] = project.errors.full_messages.join(', ') if project.errors.any?
    @active_tab = if project.new_record?
                    params[:tab] ? params[:tab].to_sym : :project_details
                  else
                    params[:tab] ? params[:tab].to_sym : :weeks
                  end
    # @active_tab = params[:tab] ? params[:tab].to_sym : :weeks
    @code = params[:code] ? params[:code].to_sym : :active
    @page = params[:page] ? params[:page].to_i : 1
    @search = params[:search] || ''
    @discipline = params[:discipline] || "all"

    unless project.new_record?

      tab :weeks, label: t("tabs.project_tabs.weeks") do
        current_date = Date.current
        if @active_tab == :weeks
          render partial: "admin/shared/search_field", locals: { field_id: "search-field-weeks", placeholder: t('prompt.project.search_by_week_number') }
          render partial: "admin/shared/filter_button", locals: { code: "open", name: t('buttons.project_buttons.status_open') }
          render partial: "admin/shared/filter_button", locals: { code: "all", name: t('buttons.project_buttons.all_codes') }
          render partial: "admin/shared/filter_button", locals: { code: "pdfsend", name: t('buttons.project_buttons.pdf_send') }
          render partial: "admin/shared/filter_button", locals: { code: "pdfapproved", name: t('buttons.project_buttons.pdf_approved') }
          render partial: "admin/shared/filter_button", locals: { code: "pending", name: t('buttons.project_buttons.status_pending') }
          render partial: "trestle/projects/discipline_selector_for_pdf", locals: { disciplines: project.disciplines }
          weeks = if @code == :pdfsend
                    Week.where(project_id: project.id, status: "send")
                  elsif @code == :pdfapproved
                    Week.where(project_id: project.id, status: "approved")
                  elsif @code == :all
                    Week.where(project_id: project.id)
                  elsif @code == :pending
                    Week.where(project_id: project.id, status: "pending")
                  else
                    Week.where(project_id: project.id, start_date: current_date.beginning_of_week..current_date.end_of_week)
                  end
          if @search.present?
            query_as_integer = @search.to_i
            weeks = weeks.where("week_number = ?", query_as_integer)
          end
          table weeks.order('year ASC, week_number ASC'), admin: WeeksAdmin, id: "project-weeks-table", row_clickable: false do |t|
            t.column :week_number, align: :center
            t.column :project_number, ->(week) { week.project.projectnumber }, align: :center
            t.column :place, ->(week) { week.project.place }, align: :center
            t.column :project_performer, ->(week) { week.project.projectperformer }
            t.column :turnover_week, ->(week) { project.euro_format(project.format_number(week.calculate_turn_over_week(week, project))) }
            t.column :status, align: :center do |week|
              select_tag "status[#{week.id}]", options_for_select(Week.statuses.keys.map do |status|
                                                                    [t("activerecord.attributes.week.status_#{status}"), status]
                                                                  end, selected: week.status), class: "form-control", id: "week-status-select-#{week.id}", onclick: "event.stopPropagation();"
            end
            t.column :invisible_partial, header: '', visible: false do |week|
              render partial: "trestle/projects/week_status_note_modal", locals: { week: week }
            end
            actions do |_toolbar, instance, admin|
              "<div>
                <a href='#{admin.path(:create_pdf_generator, id: instance.id, template: 'pdf', preview: true)}' data-method='post' class='btn btn-primary' target='_blank' rel='nofollow'>
                  <i class='fas fa-eye mr-1'></i>
                </a>
                <a href='#{admin.path(:create_pdf_generator, id: instance.id, template: 'pdf')}' data-method='post' class='btn btn-primary' rel='nofollow'>
                  #{t('buttons.weeks.export_pdf')}
                </a>
              </div>".html_safe
            end

            actions do |_toolbar, instance, _admin|
              render partial: "trestle/projects/export_pdf_button", locals: { week: instance }
            end
            actions do |toolbar, _instance, _admin|
              toolbar.delete
            end
          end
        end
      end

      if project.tbs == false
        tab :Tkc, label: t("tabs.project_tabs.Tkc") do
          if @active_tab == :Tkc
            render partial: "trestle/projects/add_tkc_cost_button", locals: { project: project }
            render partial: "admin/shared/filter_button", locals: { code: "all", name: t('buttons.project_buttons.all_codes') }
            render partial: "admin/shared/filter_button", locals: { code: "tkcsend", name: t('buttons.project_buttons.tkc_send') }
            render partial: "admin/shared/filter_button", locals: { code: "tkcapproved", name: t('buttons.project_buttons.tkc_approved') }
            tkc = if @code == :tkcsend
                    TkcCost.joins(:week).where(project_id: project.id, weeks: { tkc_status: 'send' })
                  elsif @code == :tkcapproved
                    TkcCost.joins(:week).where(project_id: project.id, weeks: { tkc_status: 'approved' })
                  else
                    TkcCost.joins(:week).where(project_id: project.id)
                  end
            table tkc.order('weeks.week_number ASC'), admin: TkcCostsAdmin, row_clickable: false do |t|
              t.column :week, ->(tkc_cost) { tkc_cost.week.week_number }
              t.column :tkc_total, class: 'table-font-code' do |tkc_cost|
                project.euro_format(project.format_number(tkc_cost.week.calculate_total_tkc_cost_week(tkc_cost.week, project)))
              end
              t.column :tkc_status, align: :center do |tkc_cost|
                select_tag "tkc_status[#{tkc_cost.week.id}]", options_for_select(Week.tkc_statuses.keys.map do |status|
                                                                                   [t("activerecord.attributes.week.status_#{status}"), status]
                                                                                 end, selected: tkc_cost.week.tkc_status), include_blank: true, class: "form-control", onclick: "event.stopPropagation();"
              end
              actions do |_toolbar, instance, _admin|
                "<div>
                  <a href='/admin/weeks/#{instance.week.id}/create_pdf_generator?template=tkc_cost_pdf&preview=true' data-method='post' class='btn btn-primary' target='_blank' rel='nofollow'>
                    <i class='fas fa-eye mr-1'></i>
                  </a>
                  <a href='/admin/weeks/#{instance.week.id}/create_pdf_generator?template=tkc_cost_pdf' data-method='post' class='btn btn-primary' rel='nofollow'>
                    #{t('buttons.weeks.export_TKC')}
                  </a>
                </div>".html_safe
              end
              actions
            end
          end
        end
      end

      tab :employees, label: t("tabs.project_tabs.employees") do
        if @active_tab == :employees
          render partial: "admin/employee/employee_details"
        end
      end

      tab :SpecificationCode, label: t("tabs.project_tabs.SpecificationCode") do
        render partial: "admin/shared/search_field", locals: { field_id: "search-field-code", placeholder: t('prompt.project.search_by_description_measurement_or_specification_code') }
        render partial: "trestle/projects/active_specification_code", locals: { project: project }
        render partial: "trestle/projects/discipline_filters", locals: { project: project } if project.disciplines.present?
        specification_codes = ''
        if @active_tab == :SpecificationCode
          if @code == :active
            codes = params[:codes].split(',').map(&:to_i) if params[:codes].present?
            if codes.present?
              project_specification_codes = project.specification_codes.order(id: :asc)
              project_specification_codes = project.filter_specification_codes(project_specification_codes, project, @discipline)
              project_specification_codes = project_specification_codes.where("LOWER(specification_code) LIKE ? OR LOWER(measurement) LIKE ? OR LOWER(description) LIKE ?", "%#{@search}%",
                                                                              "%#{@search}%", "%#{@search}%")
              puts "project specification codes #{project_specification_codes.inspect}"
              # Get the specification codes that are not part of the project
              other_codes = if @discipline == "all"
                              SpecificationCode.where(id: codes, client_id: project.client.id) - project_specification_codes
                            else
                              SpecificationCode.where(id: codes, discipline_id: @discipline) - project_specification_codes
                            end
              # Merge the two sets of codes
              specification_codes = project_specification_codes + other_codes
              specification_codes = Kaminari.paginate_array(specification_codes).page(params[:page])
            else
              specification_codes = project.specification_codes.order(id: :asc)
              specification_codes = project.filter_specification_codes(specification_codes, project, @discipline)
              specification_codes = specification_codes.where("LOWER(specification_code) LIKE ? OR LOWER(measurement) LIKE ? OR LOWER(description) LIKE ?", "%#{@search}%", "%#{@search}%",
                                                              "%#{@search}%").kaminari_page(@page)
            end
          end
          table specification_codes, admin: SpecificationCodesAdmin, id: "project-specification-code-table" do |t|
            t.column :specification_code, class: 'table-codes'
            t.column :description, class: 'table-font-description', &:description
            t.column :measurement
            t.column :price, class: "table-font-code" do |spec_code|
              project.euro_format(project.format_number(spec_code.price))
            end
            t.column :total_budget, sort: false do |specification_code|
              number_field_tag "selected_specification_code[#{specification_code.id}][total_budget]", project.selected_budget(specification_code, project), class: "total-budget-field", step: 0.01,
                                                                                                                                                            data: { project_id: project.id, code_id: specification_code.id }
            end
          end
          render partial: "trestle/projects/add_row_code", locals: { project_id: project.id }
          render "admin/shared/specification_codes", specification_codes: specification_codes
        end
      end

      if project.tbs == false
        tab :plans, label: t("tabs.project_tabs.plans") do
          if @active_tab == :plans
            render partial: "trestle/projects/add_plan_button", locals: { project: project }
            table Plan.where(project_id: project.id), admin: PlansAdmin, class: "plans-table" do |t|
              t.column :start_week, ->(plan) { plan.start_week.week_number }
              t.column :end_week, ->(plan) { plan.end_week.week_number }
              t.column :teams do |plan|
                plan.teams.map(&:team_name).join(', ')
              end
              t.column :activity, ->(plan) { plan.activity.activity_name }
              actions
            end
          end
        end
      end

      if project.tbs == false
        tab :Extra_cost, label: t("tabs.project_tabs.Extra_cost") do
          if @active_tab == :Extra_cost
            render partial: "trestle/projects/add_extra_cost_button", locals: { project: project }
            table ExtraCost.joins(:week).where(project_id: project.id).order('weeks.week_number ASC'), admin: ExtraCostsAdmin, row_clickable: false do |t|
              t.column :week, ->(extra_cost) { extra_cost.week.week_number }
              t.column :item_type do |extra_cost|
                t("activerecord.attributes.extra_cost.item_type_#{extra_cost.item_type}")
              end
              t.column :description
              t.column :cost do |extra_cost|
                project.euro_format(project.format_number(extra_cost.cost))
              end
              actions
            end
          end
        end
      end

      tab :total_overview, label: t("tabs.project_tabs.total_overview") do
        if @active_tab == :total_overview
          # active_tab_header = @active_tab == :total_overview ? (ProjectSetting.first&.ak_cost || 15).to_i : '15% AKA'
          # @weeks = Week.where(project_id: project.id).order('year ASC, week_number ASC')
          render partial: "trestle/projects/total_overview_table"
        end
      end

      # tab :totals, label: t("tabs.project_tabs.total_overview") do
      #   if @active_tab == :totals
      #     active_tab_header = @active_tab == :total_overview ? (ProjectSetting.first&.ak_cost || 15).to_i : '15% AKA'
      #     @weeks = Week.where(project_id: project.id).order('year ASC, week_number ASC')
      #     render partial: "trestle/projects/test", locals: { weeks: @weeks, project: project, active_tab_header: active_tab_header }
      #   end
      # end

      if project.tbs == false
        tab :Activities, label: t("tabs.project_tabs.activities") do
          if @active_tab == :Activities
            table project.activities.order(id: :asc), admin: ActivitiesAdmin, class: "activities-table", id: "activities-table" do |t|
              t.column :activities, sort: false do |activity|
                text_field_tag "activity_name[#{activity.id}][activity_name]", activity.activity_name, class: "activity-name-field form-control"
              end
              t.column :color, sort: false do |activity|
                color_field_tag "activity_color[#{activity.id}][color]", activity.color, class: "activity-color-field form-control"
              end
              actions
            end
            render partial: "trestle/projects/add_activity_button", locals: { project: project }
          end
        end
      end

      render partial: "trestle/projects/project_number_show_on_top", locals: {
        text: t("activerecord.attributes.project.projectnumber"),
        value: project.projectnumber
      }
      render partial: "admin/shared/loader"
    end

    tab :project_details, label: t("tabs.project_tabs.project_details") do
      next unless @active_tab == :project_details

      row do
        col(sm: 1.8) { check_box :tbs if project.id.blank? }
        col(sm: 2) { check_box :contract_sum if project.id.blank? }
      end

      row(class: "form-row-project") do
        col(sm: 3) { text_field :projectnumber, link: true }
        col(sm: 3) { text_field :place }
        if project.new_record?
          col(sm: 3) { select :client_id, Client.all.map { |client| [client.client_name, client.id] }, prompt: 'Select Opdrachgever', label: t("activerecord.attributes.project.client") }
        else
          col(sm: 3) { text_field :client, value: project.client.client_name, disabled: true }
        end
        col(sm: 3) { text_field :projectperformer }
      end
      row do
        if project.new_record?
          col(sm: 4) { select :discipline_ids, [], { label: "Selecteer discipline", prompt: "Selecteer discipline" }, { multiple: true, selected: @discipline_ids } }
        else
          col(sm: 4) do
            select :discipline_ids, project.client.disciplines.all.map { |d|
                                      [d.name.titleize, d.id]
                                    }, { label: "Selecteer discipline", prompt: "Selecteer discipline" }, { multiple: true, selected: @discipline_ids }
          end
        end
        col(sm: 4) do
          render partial: "trestle/projects/custom_date_field", locals: {
            label: t("activerecord.attributes.project.start_date"),
            field_name: "project[start_date]",
            field_id: "project_start_date",
            formatted_value: project.start_date&.strftime('%d/%m/%Y')
          }
        end
        col(sm: 4) do
          render partial: "trestle/projects/custom_date_field", locals: {
            label: t("activerecord.attributes.project.end_date"),
            field_name: "project[end_date]",
            field_id: "project_end_date",
            formatted_value: project.end_date&.strftime('%d/%m/%Y')
          }
        end
      end
      if project.blank? || (project && project.tbs == false)
        row(class: "project-field-hide") do
          col(sm: 4) { text_field :supervisor }
          col(sm: 4) { text_field :projectleader }
          col(sm: 4) { text_field :contactpersoon }
          # col(sm: 4) { text_field :projectperformer }
        end
      end

      row(class: "project-field-hide") do
        if project.blank? || (project && project.tbs == false)
          col(sm: 4) { text_field :address }
          col(sm: 4) { text_field :zip_code }
        end
        col(sm: 4, class: "#{'project-contract-sum-hide' unless project.contract_sum}") { number_field :contract_sum_amount }
      end

      check_box :archived
      hidden_field :user_id, value: current_user.id
    end
  end

  controller do
    before_action :validate_activites, only: [:update]
    before_action :update_week_statuses, only: [:update]

    def create
      project = Project.new(project_params)
      if project.tbs == true
        project.supervisor = nil
        project.projectleader = nil
        project.contactpersoon = nil
        project.address = nil
        project.zip_code = nil
        project.contract_sum_amount = nil
      elsif project.contract_sum == false && project.tbs == false
        project.contract_sum_amount = nil
      end
      if project.save
        flash[:message] = "De Project succesvol toegevoegd"
        redirect_to projects_admin_index_path
      else
        render json: { errors: project.errors.full_messages }, status: :unprocessable_entity
      end
    end

    def update
      if params[:project].present?
        project = Project.find(params[:id])
        if project.update(project_params)
          super
        else
          render json: { errors: project.errors.full_messages }, status: :unprocessable_entity
        end
      else
        super
      end
    end

    def update_pending_status
      week = Week.find(params[:id])
      note = params[:note]
      if week.update(status: "pending", note: note)
        render json: { status: 'success', message: 'Week status updated successfully' }
      else
        render json: { status: 'error', message: 'Failed to update week status' }, status: :unprocessable_entity
      end
    end

    def create_employee_schedule
      project = Project.find(params[:id])

      redirect_to new_employee_schedulings_admin_path(project: project)
    end

    def create_tkc_cost
      project = Project.find(params[:id])

      redirect_to new_tkc_costs_admin_path(project: project)
    end

    def create_extra_cost
      project = Project.find(params[:id])

      redirect_to new_extra_costs_admin_path(project: project)
    end

    def create_plans
      project = Project.find(params[:id])

      redirect_to new_plans_admin_path(project: project)
    end

    def create_spec_codes
      project = Project.find(params[:id].to_i)
      specification_codes = JSON.parse(params[:specification_codes])
      return unless specification_codes.is_a?(Array)

      specification_codes&.each do |element|
        specification_code_id = element["code_id"].to_i
        total_budget = element["total_budget"].to_f
        project_id = element["project_id"].to_i
        next unless project_id == project.id

        code = SpecificationCode.find(specification_code_id)
        price = code.price
        if total_budget.blank? || total_budget <= 0.0
          project.selected_specification_codes.where(specification_code_id: specification_code_id).destroy_all
          purchase_orders_to_delete = code.purchase_orders.where(amount: 0, project_id: project.id)
          purchase_orders_to_delete.destroy_all unless purchase_orders_to_delete.empty?
          tkc_cost_amounts_to_delete = code.tkc_cost_amounts.where(amount: 0, project_id: project.id)
          tkc_cost_amounts_to_delete.destroy_all unless tkc_cost_amounts_to_delete.empty?
        else
          selected_specification_code = project.selected_specification_codes.find_or_initialize_by(specification_code_id: specification_code_id)
          selected_specification_code.total_budget = total_budget
          selected_specification_code.save
          if project.contract_sum == false
            project.weeks.each do |week|
              existing_purchase_order = PurchaseOrder.find_by(
                project_id: project.id,
                specification_code_id: specification_code_id,
                week_id: week.id
              )
              if existing_purchase_order.nil?
                purchase_order = PurchaseOrder.create(
                  project_id: project.id,
                  specification_code_id: specification_code_id,
                  week_id: week.id,
                  price: price,
                  total_budget: total_budget
                )
              elsif existing_purchase_order.amount.nil? || existing_purchase_order.amount == 0.0
                existing_purchase_order.update(total_budget: total_budget, price: price)
              end
            
            end
          end
        end
      end
    end

    def fetch_disciplines
      client = Client.find(params[:id])
      disciplines = client.disciplines
      render json: { disciplines: disciplines }
    end

    def get_specification_codes
      id = params[:project_id]
      project = Project.find(id)
      discipline_id = params[:discipline_id]
      specification_codes = SpecificationCode.joins(:discipline).where(disciplines: { id: project.disciplines.pluck(:id) })
      specification_codes = specification_codes.where.not(id: project.specification_codes.pluck(:id))
      specification_codes = project.filter_specification_codes(specification_codes, project, discipline_id)
      render json: { specification_codes: specification_codes }
    end

    def get_specification_code
      specification_code = SpecificationCode.find(params[:id])
      render json: { specification_code: specification_code }
    end

    protected

    def validate_activites
      project = Project.find(params[:id])
      activities_names = params[:activity_name]
      activities_colors = params[:activity_color]
      new_activities = []

      activities_names&.each do |activity_name_id, acitivity_name_params|
        activity = project.activities.find_by(id: activity_name_id)
        activity_name = acitivity_name_params[:activity_name]
        if activity && activity_name
          activity.update(activity_name: activity_name)
        else
          new_activities << {
            activity_id: activity_name_id,
            activity_name: acitivity_name_params[:activity_name],
            color: "#0000"
          }
        end
      end

      activities_colors&.each do |activity_color_id, activity_color_params|
        if new_activities.any? { |po| po[:activity_id] == activity_color_id }
          color = activity_color_params[:color]
          new_activity = new_activities.find { |po| po[:activity_id] == activity_color_id }
          new_activity[:color] = color if color
        else
          activity_color = project.activities.find_by(id: activity_color_id)
          color = activity_color_params[:color]
          activity_color.update(color: color) if activity_color && color.present?
        end
      end

      new_activities&.each do |activity|
        activity_name = activity[:activity_name]
        next unless activity_name

        Activity.create(
          project: project,
          plan: nil,
          activity_name: activity_name,
          color: activity[:color]
        )
      end
    end

    def update_week_statuses
      status = params[:status]
      tkc_status = params[:tkc_status]

      status&.each do |week_id, status|
        if status.present? && status != "pending"
          week = Week.find(week_id)
          week.update(status: status, note: nil)
        end
      end
      tkc_status&.each do |week_id, status|
        week = Week.find(week_id)
        week.update(tkc_status: status)
      end
    end

    private

    def project_params
      params.require(:project).permit(
        :projectnumber,
        :supervisor,
        :address,
        :zip_code,
        :projectleader,
        :projectperformer,
        :contactpersoon,
        :place,
        :client_id,
        :start_date,
        :end_date,
        :archived,
        :tbs,
        :user_id,
        :contract_sum,
        :contract_sum_amount,
        discipline_ids: []
      )
    end
  end
end
