Trestle.resource(:insurances) do
  form do |insurance|
    flash.now[:error] = insurance.errors.full_messages.join(', ') if insurance.errors.any?
    if params[:material]
      material_id = params[:material]&.to_i || nil
    elsif params[:equipment_material]
      equipment_material_id = params[:equipment_material]&.to_i || nil
    elsif insurance&.material_id
      material_id = insurance.material_id.to_i
    elsif insurance&.equipment_material_id
      equipment_material_id = insurance.equipment_material_id.to_i
    end

    hidden_field :material_id, value: material_id
    hidden_field :equipment_material_id, value: equipment_material_id

    row do
      col(sm: 4) { text_field :insurer }
      col(sm: 4) { text_field :policy_number }
      col(sm: 4) { text_field :premium_period }
    end
    row do
      col(sm: 4) { number_field :premium_per_period, step: '0.01' }
      col(sm: 4) do
        render partial: "admin/shared/date_field", locals: {
          label: t("activerecord.attributes.insurance.commencement_date"),
          field_name: "insurance[commencement_date]",
          field_id: "insurance_commencement_date",
          formatted_value: insurance.commencement_date&.strftime('%d/%m/%Y')
        }
      end
    end
  end

  controller do
    def create
      insurance = Insurance.new(insurance_params)
      material = insurance.material
      equipment_material = insurance.equipment_material

      if insurance.save
        if insurance.material.present?
          redirect_to "/admin/materials/#{material.id}?tab=insurance#!tab-insurance"
        else
          redirect_to "/admin/equipment_materials/#{equipment_material.id}?tab=insurance#!tab-insurance"
        end
      else
        super
      end
    end

    def update
      insurance = Insurance.find(params[:id])
      insurance.assign_attributes(insurance_params)
      material = insurance.material
      equipment_material = insurance.equipment_material

      if insurance.save
        if insurance.material.present?
          redirect_to "/admin/materials/#{material.id}?tab=insurance#!tab-insurance"
        else
          redirect_to "/admin/equipment_materials/#{equipment_material.id}?tab=insurance#!tab-insurance"
        end
      else
        super
      end
    end

    private

    def insurance_params
      params.require(:insurance).permit(:material_id, :insurer, :policy_number, :premium_period, :premium_per_period, :equipment_material_id)
    end
  end
end
