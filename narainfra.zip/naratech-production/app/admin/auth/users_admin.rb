Trestle.resource(:users, model: User, scope: Auth) do
  menu do
    item :users, icon: "fas fa-users", label: t("menu.users"), priority: 1
  end

  authorize do
    actions :new, :show, :create, :index, :edit, :update, :destroy do
      current_user.role == "admin"
    end
  end

  table do
    column :first_name, link: true
    column :last_name
    column :role do |user|
      t("activerecord.attributes.user.role_#{user.role}")
    end
    column :email
    actions do |a|
      a.delete unless a.instance == current_user
    end
  end

  form do |user|
    text_field :email

    row do
      col(sm: 6) { text_field :first_name }
      col(sm: 6) { text_field :last_name }
    end

    row do
      col(sm: 6) { password_field :password }
      col(sm: 6) { password_field :password_confirmation }
    end

    row do
      col(sm: 6) { select(:role, User.roles.keys.map { |type| [t("activerecord.attributes.user.role_#{type}"), type] }) }
    end
  end
end
