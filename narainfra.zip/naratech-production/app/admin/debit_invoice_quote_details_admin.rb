Trestle.resource(:debit_invoice_quote_details) do
  #   form do |selected_specification_code|
  #     text_field :total_budget
  #     hidden_field :project_id, value: params[:project_id] if params[:project_id].present?
  #   end
  routes do
    post :delete_invoice_detail, on: :collection
  end
  controller do
    def delete_invoice_detail
      invoice_detail_id = params[:invoice_id]
      source = params[:source]
      invoice_detail = DebitInvoiceQuoteDetail.find(invoice_detail_id)

      invoice = invoice_detail.debit_invoice_quote
      invoice.update(total: invoice.total - invoice_detail.total_amount)

      invoice_detail.destroy
      if invoice_detail.destroyed?
        render json: { reponse: "success" }, status: :ok
      else
        render json: { error: 'Invoice detail not found' }, status: :not_found
      end
    end
  end
end
