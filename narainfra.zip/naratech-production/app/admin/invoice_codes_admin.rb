Trestle.resource(:invoice_codes) do
#   form do |selected_specification_code|
#     text_field :total_budget
#     hidden_field :project_id, value: params[:project_id] if params[:project_id].present?
#   end
end
