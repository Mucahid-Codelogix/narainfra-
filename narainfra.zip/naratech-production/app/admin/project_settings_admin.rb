Trestle.resource(:project_settings) do
  authorize do
    actions :index, :edit, :update, :show, :destroy do
      true if current_user.role == "admin"
    end
    actions :new, :create do
      ProjectSetting.first.nil? && current_user.role == "admin"
    end
  end

  table do
    column :ak_cost
    actions
  end

  form do |project_setting|
    number_field :ak_cost, min: 0
  end

  controller do
    def create
      @project_setting = ProjectSetting.new(params.require(:project_setting).permit(:ak_cost))

      if @project_setting.save
        flash[:message] = "Projectinstelling is succesvol aangemaakt"
        redirect_to project_settings_admin_path(@project_setting)
      else
        flash[:error] = @project_setting.errors.full_messages.to_sentence
        render :new
      end
    end

    def destroy
      @project_setting = ProjectSetting.find(params[:id])
      @project_setting.destroy
      redirect_to "/admin/invoice_settings?type=project_setting"
    end
  end
end
