require 'zip'
Trestle.resource(:invoices) do
  # menu do
  #   item :invoices, icon: "fa fa-file-invoice", label: "Invoice", priority: 9
  # end

  menu do
    group :Facturen, priority: 3 do
      item :credit, icon: "fa fa-money-bill-wave-alt", label: t("menu.invoice_credit")
    end
  end
  routes do
    get :fetch_finances, on: :collection
    get :fetch_invoices, on: :collection
    get :fetch_invoices_client, on: :collection
    get :create_finance, on: :collection
    get :create_contractor_finance, on: :collection
    # get :fetch_weeks_and_codes, on: :collection
    post :invoice_pdf_creater, on: :member
    post :pdf_download, on: :member
    post :update_payment, on: :collection
    post :create_invoices, on: :collection
    post :download_file, on: :member
    post :download_pdf_zip, on: :collection
  end
  table do
    column :invoice_number
    column :description
    column :invoice_date do |invoice|
      invoice.invoice_date&.strftime("%d/%m/%Y")
    end
    column :expiration_date do |invoice|
      invoice.expiration_date&.strftime("%d/%m/%Y")
    end
    column :paid_date do |invoice|
      invoice.paid_date&.strftime("%d/%m/%Y")
    end
    column :payment_term
    column :status, ->(invoice) { t("activerecord.attributes.invoice.status_#{invoice.status}") }
    column :pdf, link: true do |invoice|
      if invoice&.invoice_pdf.present?
        "<div>
          #{link_to 'Pdf', Rails.application&.routes&.url_helpers&.rails_blob_path(invoice&.invoice_pdf, only_path: true), target: '_blank', class: 'btn btn-primary'}
        </div>".html_safe
      end
    end
    actions
  end

  form do |invoice|
    flash.now[:error] = invoice.errors.full_messages.join(', ') if invoice.errors.any?
    hidden_field :payment_term, value: invoice.payment_term, id: 'payment_term_value_display_invoice'
    disabled_fields = true unless invoice.new_record?
    disabled = invoice&.status == "partially_paid" || invoice&.status == "paid"
    if invoice.new_record?
      row(class: 'radio-buttons-invoice') do
        render partial: "trestle/invoice/radio_button"
      end
    end
    if invoice.new_record?
      row do
        col(sm: 3, class: 'client-select') do
          select :client_id, Client.where(active: true).map { |c|
                               [c.client_name, c.id]
                             }, label: t("activerecord.attributes.invoice.client"), prompt: t("prompt.invoice.select_client"), disabled: disabled_fields
        end
        render partial: "admin/shared/create_client_button", locals: { source: "invoices", css_class: "create-client-button-invoice-display-none" }

        col(sm: 3, class: 'contractor-select') do
          select :contractor_id, Contractor.where(active: true).map { |c|
                                   [c.contractor_name, c.id]
                                 }, label: t("activerecord.attributes.invoice.client"), prompt: "Opdrachtnemer selecteren", disabled: disabled_fields
        end
        render partial: "admin/shared/create_contractor_button", locals: { source: "invoices", css_class: "create-contractor-button-invoice-display-none" }
        col(sm: 4, class: 'other-select') { text_field :company_name }
        col(sm: 4) { text_field :invoice_number, disabled: invoice.id.present? }
        col(sm: 4, class: 'invoice-description') { text_field :description }
      end
    end
    if invoice.id.present?
      row do
        if invoice.client_id.present?
          col(sm: 3) do
            select :client_id, Client.where(active: true).map { |c|
                                 [c.client_name, c.id]
                               }, label: t("activerecord.attributes.invoice.client"), prompt: t("prompt.invoice.select_client"), disabled: disabled_fields
          end
        end
        render partial: "admin/shared/create_client_button", locals: { source: "invoices", css_class: "create-client-button-invoice" } if invoice.client_id.present?

        if invoice.contractor_id.present?
          col(sm: 3) do
            select :contractor_id, Contractor.where(active: true).map { |c|
                                     [c.contractor_name, c.id]
                                   }, label: t("activerecord.attributes.invoice.contractor"), prompt: "Opdrachtnemer selecteren", disabled: disabled_fields
          end
        end
        col(sm: 4) { text_field :company_name } if invoice.client.blank? && invoice.contractor.blank?
        col(sm: 4) { text_field :invoice_number, disabled: invoice.id.present? }
        col(sm: 4) { text_field :description } if invoice.client.present? || invoice.contractor.present?
      end
    end
    row do
      col(sm: 4) do
        render partial: "admin/shared/date_field", locals: {
          label: t("activerecord.attributes.invoice.invoice_date"),
          field_name: "invoice[invoice_date]",
          field_id: "invoice_invoice_date",
          formatted_value: invoice.invoice_date&.present? ? invoice.invoice_date&.strftime('%d/%m/%Y') : Time.now.in_time_zone('Amsterdam').strftime('%d/%m/%Y')
        }
      end
      col(sm: 4) do
        render partial: "admin/shared/date_field", locals: {
          label: t("activerecord.attributes.invoice.expiration_date"),
          field_name: "invoice[expiration_date]",
          field_id: "invoice_expiration_date",
          formatted_value: invoice.expiration_date&.present? ? invoice.expiration_date&.strftime('%d/%m/%Y') : Time.now.in_time_zone('Amsterdam').strftime('%d/%m/%Y'),
          disabled: true
        }
      end
      if invoice&.status == "paid"
        col(sm: 4) do
          render partial: "admin/shared/date_field", locals: {
            label: t("activerecord.attributes.invoice.paid_date"),
            field_name: "invoice[paid_date]",
            field_id: "invoice_paid_date",
            formatted_value: invoice.paid_date&.present? ? invoice.paid_date&.strftime('%d/%m/%Y') : Time.now.in_time_zone('Amsterdam').strftime('%d/%m/%Y'),
            disabled: true
          }
        end
      end
      col(sm: 4) { file_field :attachment }
    end

    table invoice.invoice_details.order(id: :asc), admin: InvoiceDetailsAdmin, class: "invoice-details-table", id: "invoice-details-table" do |t|
      t.column :amount, sort: false do |invoice_detail|
        vat = if invoice.client&.finance.present?
                invoice.client.finance.vat
              elsif invoice.contractor&.contractor_finance.present?
                invoice.contractor.contractor_finance.vat
              else
                21
              end

        vat_reversed = if invoice.client&.finance.present?
                         invoice.client.finance.vat_reversed
                       elsif invoice.contractor&.contractor_finance.present?
                         invoice.contractor.contractor_finance.vat_reversed
                       else
                         false
                       end
        "<div>
          #{number_field_tag "invoice_details[#{invoice_detail.id}][amount]", invoice_detail.amount, class: 'amount-field-invoice-detail form-control text-currency', disabled: disabled,
                                                                                                     data: { vat: vat, vat_reversed: vat_reversed }}
      </div>".html_safe
      end
      t.column :description, sort: false do |invoice_detail|
        text_field_tag "invoice_details[#{invoice_detail.id}][description]", invoice_detail.description, id: "description-#{invoice_detail.id}", class: "invoice-detail-description form-control",
                                                                                                         disabled: disabled
      end
      t.column :unit, sort: false do |invoice_detail|
        text_field_tag "invoice_details[#{invoice_detail.id}][unit]", invoice_detail.unit, id: "unit-#{invoice_detail.id}", class: "invoice-detail-unit form-control", disabled: disabled
      end
      t.column :price_excluding_vat, sort: false do |invoice_detail|
        "<div class='currency-wrap'>
          <span class='currency-code'>€</span>
          #{number_field_tag "invoice_details[#{invoice_detail.id}][price]", invoice_detail.price, class: 'price-field-invoice-detail form-control text-currency', disabled: disabled, step: 'any'}
        </div>".html_safe
      end

      t.column :vat, lambda { |_invoice_detail|
                       if (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?)
                         selected_value = _invoice_detail.vat_percentage.present? ? _invoice_detail.vat_percentage.to_i : 21
                         select_box_html = "<select class='vat-column-invoice-detail-select form-control' name='invoice_details[#{_invoice_detail.id}][vat_percentage]' data-total-amount='#{_invoice_detail.total_amount}' #{disabled ? 'disabled' : ''}>
                            <option value='0' #{'selected' if selected_value == 0}>0%</option>
                            <option value='9' #{'selected' if selected_value == 9}>9%</option>
                            <option value='21' #{'selected' if selected_value == 21}>21%</option>
                          </select>".html_safe
                       elsif invoice&.client&.finance.present?
                         "#{invoice.client.finance.vat}%"
                       elsif invoice&.contractor&.contractor_finance.present?
                         "#{invoice.contractor.contractor_finance.vat}%"
                       else
                         "21%"
                       end
                     }, class: "vat-column-invoice-detail table-font-code"

      t.column :price_including_vat, lambda { |invoice_detail|
                                       vat = 21
                                       vat_reversed = false
                                       if invoice&.client&.finance.present?
                                         vat = invoice.client.finance.vat
                                         vat_reversed = invoice.client.finance.vat_reversed
                                       elsif invoice&.contractor&.contractor_finance.present?
                                         vat = invoice.contractor.contractor_finance.vat
                                         vat_reversed = invoice.contractor.contractor_finance.vat_reversed
                                       end
                                       vat = (vat * invoice_detail&.total_amount) / 100
                                       total_amount = if vat_reversed == false
                                                        vat + invoice_detail&.total_amount
                                                      else
                                                        invoice_detail&.total_amount
                                                      end
                                       if (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?) && invoice_detail.total_amount_included_vat.present?
                                         invoice_detail.invoice.euro_format(invoice_detail.invoice.format_number(invoice_detail.total_amount_included_vat&.ceil(2)))
                                       else
                                         invoice_detail.invoice.euro_format(invoice_detail.invoice.format_number(total_amount&.ceil(2)))
                                       end
                                     }, class: "total-column-invoice-detail table-font-code"
      if disabled == false
        t.column :action, sort: false do |invoice_detail|
          button_tag "Delete", type: "button", class: "btn btn-danger invoice-delete-button", data: { invoice_detail_id: invoice_detail.id, source: "credit-invoices" }
        end
      end
    end
    render partial: "admin/shared/add_row", locals: { id: "add-invoice" } if disabled == false
  end

  controller do
    before_action :invoice_details_calculation, only: [:update]

    def create_invoices
      # Assuming the client_id is 1
      client_id = Client.first.id

      (1..150).each do |index|
        invoice_number = "contracter#{index.to_s.rjust(3, '0')}" # Generates invoice numbers like INV001, INV002, ...
        description = "Description for Invoice #{index}"
        invoice_type = "debit"

        Invoice.create!(
          contractor_id: 1,
          invoice_number: invoice_number,
          description: description,
          status: "paid",

          invoice_type: invoice_type
        )
      end
    end

    def create
      invoice = Invoice.new(invoice_params)
      if invoice.save
        @invoice_id = invoice.id
        invoice_details_calculation
        redirect_to invoices_admin_index_path
      else
        render json: { errors: invoice.errors.full_messages }, status: :unprocessable_entity
      end
    end

    def invoice_details_calculation
      id = params[:id] || @invoice_id
      invoice = Invoice.find(id)
      invoice_details = params[:invoice_details]

      if (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?)
        calculation_for_invoices_other(invoice, invoice_details)
      else
        calculation_for_invoices_client_contractor(invoice, invoice_details)
      end

      invoice_pdf_creater(id)
    end

    def calculation_for_invoices_client_contractor(invoice, invoice_details)
      total = 0
      return unless invoice&.status == "sent" || invoice&.status == "open"

      invoice_details&.each do |invoice_detail_id, detail_params|
        invoice_detail = invoice.invoice_details.find_by(id: invoice_detail_id)
        total += BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
        if invoice_detail.present?
          invoice_detail.update(
            description: detail_params[:description],
            unit: detail_params[:unit],
            amount: detail_params[:amount],
            price: detail_params[:price],
            total_amount: BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
          )
        else
          InvoiceDetail.create(
            invoice: invoice,
            description: detail_params[:description],
            unit: detail_params[:unit],
            amount: detail_params[:amount],
            price: detail_params[:price],
            total_amount: BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
          )
        end
      end
      if total.negative?
        if invoice&.client&.finance.present?
          vat = invoice.client.finance.vat
          vat_reversed = invoice.client.finance.vat_reversed
        elsif invoice&.contractor&.contractor_finance.present?
          vat = invoice.contractor.contractor_finance.vat
          vat_reversed = invoice.contractor.contractor_finance.vat_reversed
        else
          vat = 21
          vat_reversed = false
        end
        vat = (vat * total) / 100
        total = vat + total if vat_reversed == false
        invoice.update(status: "paid", total: total)
      else
        invoice.update(total: total)
      end
    end

    def calculation_for_invoices_other(invoice, invoice_details)
      total = 0
      return unless invoice&.status == "sent" || invoice&.status == "open"

      invoice_details&.each do |invoice_detail_id, detail_params|
        total_amount = BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
        total_amount_included_vat = total_amount + (total_amount * (BigDecimal(detail_params[:vat_percentage]&.to_s) / 100))
        invoice_detail = invoice.invoice_details.find_by(id: invoice_detail_id)
        vat_percentage = detail_params[:vat_percentage]
        total += total_amount + (total_amount * (BigDecimal(detail_params[:vat_percentage].to_s) / 100))
        if invoice_detail.present?
          invoice_detail.update(
            description: detail_params[:description],
            unit: detail_params[:unit],
            amount: detail_params[:amount],
            price: detail_params[:price],
            vat_percentage: vat_percentage,
            total_amount: total_amount,
            total_amount_included_vat: total_amount_included_vat
          )
        else
          InvoiceDetail.create(
            invoice: invoice,
            description: detail_params[:description],
            unit: detail_params[:unit],
            amount: detail_params[:amount],
            price: detail_params[:price],
            vat_percentage: vat_percentage,
            total_amount: total_amount,
            total_amount_included_vat: total_amount_included_vat
          )
        end
      end
      if total.negative?
        invoice.update(status: "paid", total: total, total_included_vat: total)
      else
        invoice.update(total: total, total_included_vat: total)
      end
    end

    def fetch_finances
      if params[:contractor_id].present?
        contractor = Contractor.find(params[:contractor_id])
        finance = contractor.contractor_finance
      else
        client = Client.find(params[:id])
        finance = client.finance
      end
      render json: { finance: finance }
    end

    def update_payment
      amsterdam_time_zone = ActiveSupport::TimeZone.new('Amsterdam')
      current_datetime_amsterdam = Time.now.in_time_zone(amsterdam_time_zone)
      current_date_amsterdam = if params[:payment_date].present?
                                 Date.parse(params[:payment_date])
                               else
                                 current_datetime_amsterdam.to_date
                               end
      included_vat_value = nil
      invoices = params[:invoices]
      paid_amount = params[:paidAmount].to_f
      if invoices.is_a?(Array)
        invoices.each do |invoice_id|
          invoice = Invoice.find(invoice_id)
          invoice_total_remain = invoice.total
          if (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?) && invoice.total_included_vat.present? && invoice.total_included_vat == invoice.total
            invoice_total_remain = 0
          end

          if paid_amount.positive?
            if invoice.status == "partially_paid" || invoice.status == "paid"
              total = invoice.total - paid_amount
            elsif invoice&.client&.finance.present? && invoice&.client&.finance&.vat_reversed == false
              vat = (invoice.client.finance.vat * invoice.total) / 100
              total = invoice.total + vat - paid_amount
              included_vat_value = invoice.client.finance.vat
            elsif invoice&.contractor&.contractor_finance.present? && invoice&.contractor&.contractor_finance&.vat_reversed == false
              vat = (invoice.contractor.contractor_finance.vat * invoice.total) / 100
              total = invoice.total + vat - paid_amount
              included_vat_value = invoice.contractor.contractor_finance.vat
            elsif (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?) && invoice.total_included_vat.present?
              total = invoice.total - paid_amount
            elsif invoice&.client&.finance.blank? && invoice&.contractor&.contractor_finance.blank?
              vat = (21.0 * invoice.total) / 100
              total = invoice.total + vat - paid_amount
              included_vat_value = 21.0
            else
              total = invoice.total - paid_amount
            end
            if total.positive?
              status = "partially_paid"
            elsif total.zero? || total.negative?
              status = "paid"
            end
            paid_value = invoice.paid_value + paid_amount
            paid_value = total + invoice.paid_value if paid_amount > total
            total = [total, 0].max
            invoice.update(status: status, total: total, payment_date: current_date_amsterdam, paid_value: paid_value, paid_date: current_date_amsterdam, included_vat_value: included_vat_value)
          elsif paid_amount.negative? && (invoice.status == "paid" || invoice.status == "partially_paid")
            total = invoice.total
            total_amount = 0
            total_amount_include_tax = 0
            amount_paid = invoice.paid_value
            status = invoice.status
            converted_paid_amount_sign = paid_amount.abs
            invoice&.invoice_details&.each do |i|
              total_amount += i.total_amount
            end
            total_amount_include_tax = include_tax_value(invoice, total_amount)
            if converted_paid_amount_sign == total_amount_include_tax || (total_amount_include_tax == invoice_total_remain + converted_paid_amount_sign)
              total = total_amount
              if (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?) && invoice.total_included_vat.present?
                total = invoice.total_included_vat
              end
              amount_paid = 0
              status = "open"
              included_vat_value = nil
            elsif total_amount_include_tax > invoice_total_remain + converted_paid_amount_sign
              total = invoice_total_remain + converted_paid_amount_sign
              amount_paid = total_amount_include_tax - (invoice_total_remain + converted_paid_amount_sign)
              status = "partially_paid"
              included_vat_value = if invoice&.client&.finance.present?
                                     invoice.client.finance.vat
                                   elsif invoice&.contractor&.contractor_finance.present?
                                     invoice.contractor.contractor_finance.vat
                                   else
                                     21.0
                                   end
            end
            invoice.update(status: status, total: total, payment_date: current_date_amsterdam, paid_value: amount_paid, paid_date: current_date_amsterdam, included_vat_value: included_vat_value)
          end
        end
      else
        invoice = Invoice.find(invoices)
        invoice_total_remain = invoice.total
        if (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?) && invoice.total_included_vat.present? && invoice.total_included_vat == invoice.total
          invoice_total_remain = 0
        end
        if paid_amount.positive?
          if invoice.status == "partially_paid" || invoice.status == "paid"
            total = invoice.total - paid_amount
          elsif invoice&.client&.finance.present? && invoice&.client&.finance&.vat_reversed == false
            vat = (invoice.client.finance.vat * invoice.total) / 100
            total = invoice.total + vat - paid_amount
            included_vat_value = invoice.client.finance.vat
          elsif invoice&.contractor&.contractor_finance.present? && invoice&.contractor&.contractor_finance&.vat_reversed == false
            vat = (invoice.contractor.contractor_finance.vat * invoice.total) / 100
            total = invoice.total + vat - paid_amount
            included_vat_value = invoice.contractor.contractor_finance.vat
          elsif (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?) && invoice.total_included_vat.present?
            total = invoice.total - paid_amount
          elsif invoice&.client&.finance.blank? && invoice&.contractor&.contractor_finance.blank?
            vat = (21.0 * invoice.total) / 100
            total = invoice.total + vat - paid_amount
            included_vat_value = 21.0
          else
            total = invoice.total - paid_amount
          end
          if total.positive?
            status = "partially_paid"
          elsif total.zero? || total.negative?
            status = "paid"
          end
          paid_value = invoice.paid_value + paid_amount
          paid_value = invoice.total + invoice.paid_value if paid_amount > total
          total = [total, 0].max
          invoice.update(status: status, total: total, payment_date: current_date_amsterdam, paid_value: paid_value, paid_date: current_date_amsterdam, included_vat_value: included_vat_value)
        elsif paid_amount.negative? && (invoice.status == "paid" || invoice.status == "partially_paid")
          total = invoice.total
          total_amount = 0
          total_amount_include_tax = 0
          amount_paid = invoice.paid_value
          status = invoice.status
          converted_paid_amount_sign = paid_amount.abs
          invoice&.invoice_details&.each do |i|
            total_amount += i.total_amount
          end
          total_amount_include_tax = include_tax_value(invoice, total_amount)
          if converted_paid_amount_sign == total_amount_include_tax || (total_amount_include_tax == invoice_total_remain + converted_paid_amount_sign)
            total = total_amount
            if (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?) && invoice.total_included_vat.present?
              total = invoice.total_included_vat
            end
            amount_paid = 0
            status = "open"
            included_vat_value = nil
          elsif total_amount_include_tax > invoice_total_remain + converted_paid_amount_sign
            total = invoice_total_remain + converted_paid_amount_sign
            amount_paid = total_amount_include_tax - (invoice_total_remain + converted_paid_amount_sign)
            status = "partially_paid"
            included_vat_value = if invoice&.client&.finance.present?
                                   invoice.client.finance.vat
                                 elsif invoice&.contractor&.contractor_finance.present?
                                   invoice.contractor.contractor_finance.vat
                                 else
                                   21.0
                                 end
          else
            return
          end
          invoice.update(status: status, total: total, payment_date: current_date_amsterdam, paid_value: amount_paid, paid_date: current_date_amsterdam, included_vat_value: included_vat_value)
        end
      end

      render json: { status: 'success', message: 'Payment updated successfully' }
    end

    def include_tax_value(invoice, _total_amount)
      return invoice.total_included_vat if (invoice.client_id.nil? || invoice.client_id.blank?) && (invoice.contractor_id.nil? || invoice.contractor_id.blank?) && invoice.total_included_vat.present?

      total_amount = _total_amount
      if invoice&.client&.finance.present? && invoice&.client&.finance&.vat_reversed == false
        vat = (invoice.client.finance.vat * total_amount) / 100
        total_amount += vat
      elsif invoice&.contractor&.contractor_finance.present? && invoice&.contractor&.contractor_finance&.vat_reversed == false
        vat = (invoice.contractor.contractor_finance.vat * total_amount) / 100
        total_amount += vat
      elsif invoice&.client&.finance.blank? && invoice&.contractor&.contractor_finance.blank?
        vat = (21.0 * total_amount) / 100
        total_amount += vat
      end
      total_amount.round(2)
    end

    def return_amount_calculation_for_invoice_other(invoice); end

    def fetch_weeks_and_codes
      project = Project.find(params[:id])
      weeks = project.weeks
      specification_codes = project.specification_codes
      render json: { weeks: weeks, specification_codes: specification_codes }
    end

    def invoice_pdf_creater(id)
      invoice = Invoice.find(id)
      invoice_details = invoice&.invoice_details
      client = invoice.client || invoice.contractor
      template = params[:template]
      pdf_filename = if invoice.client.present?
                       "#{invoice.invoice_number}-#{invoice.client.client_name}.pdf"
                     elsif invoice.contractor.present?
                       "#{invoice.invoice_number}-#{invoice.contractor.contractor_name}.pdf"
                     else
                       "#{invoice.invoice_number}.pdf"
                     end
      template_path = "#{Rails.root}/app/views/trestle/invoice/pdf.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)

      invoice.invoice_pdf.attach(io: StringIO.new(pdf), filename: pdf_filename, content_type: 'application/pdf')
    end

    def pdf_download
      invoice = Invoice.find(params[:id])
      invoice_details = invoice&.invoice_details
      client = invoice.client
      template = params[:template]
      pdf_filename = if invoice.client.present?
                       "#{invoice.invoice_number}-#{invoice.client.client_name}.pdf"
                     elsif invoice.contractor.present?
                       "#{invoice.invoice_number}-#{invoice.contractor.contractor_name}.pdf"
                     else
                       "#{invoice.invoice_number}.pdf"
                     end
      template_path = "#{Rails.root}/app/views/trestle/invoice/pdf.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)

      if params[:preview].present?
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'inline')
      else
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'attachment')
      end
      # redirect_to "/admin/projects/8?tab=weeks#!tab-weeks"
    end

    def fetch_invoices_client
      statuses = params[:status]&.split(',')&.map(&:to_sym) if params[:status]
      sort_field = params[:sort_field] || 'id'
      search_term = params[:search_term]
      sort_direction = params[:sort_direction] || 'asc'
      if params[:client_type] == "client"
        client_id = params[:client_id]
        invoices = Invoice.where(client_id: client_id).order(id: :desc)
      elsif params[:client_type] == "contractor"
        contractor_id = params[:client_id]
        invoices = Invoice.where(contractor_id: contractor_id)
      end

      if search_term.present?
        if search_term.present?
          invoices = invoices.joins('LEFT JOIN clients ON invoices.client_id = clients.id')
                             .joins('LEFT JOIN contractors ON invoices.contractor_id = contractors.id')
                             .where("invoices.description ILIKE :search_term OR invoices.invoice_number ILIKE :search_term OR invoices.company_name ILIKE :search_term OR clients.client_name ILIKE :search_term OR contractors.contractor_name ILIKE :search_term",
                                    search_term: "%#{search_term}%")
        end
      end
      invoices = invoices.where(status: statuses) if statuses && !statuses.empty?
      count = invoices.count
      total_invoices = invoices
      # invoices = invoices.order(id: :desc).kaminari_page(params[:page]).per(10)
      if %w[C-rekening G-rekening].include?(sort_field)
        sorted_invoices = invoices.sort_by do |invoice|
          percentage = calculate_percentage(invoice, sort_field)
          sort_direction == 'asc' ? percentage : -percentage
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal incl'
        sorted_invoices = invoices.sort_by do |invoice|
          total_incl = calculate_sum_of_total_amount(invoice.invoice_details, invoice)
          sort_direction == 'asc' ? total_incl : -total_incl
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal excl'
        sorted_invoices = invoices.sort_by do |invoice|
          total_excl = calculate_total_excluding_vat(invoice.invoice_details)
          sort_direction == 'asc' ? total_excl : -total_excl
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal openstaand'
        sorted_invoices = invoices.sort_by do |invoice|
          total_outstanding = calculate_total_outstanding(invoice)
          sort_direction == 'asc' ? total_outstanding : -total_outstanding
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'client'
        invoices = invoices
                   .left_joins(:client, :contractor)
                   .order(Arel.sql("COALESCE(clients.client_name, contractors.contractor_name, invoices.company_name) #{sort_direction}"))
                   .kaminari_page(params[:page]).per(100)
      else
        invoices = invoices.order("#{sort_field} #{sort_direction}").kaminari_page(params[:page]).per(100)
      end
      render json: { invoices: invoices.as_json(include: { client: { include: :finance }, invoice_details: {}, contractor: { include: :contractor_finance } }, methods: [:attachment_attached]),
                     count: count, total_invoices: total_invoices.as_json(include: { client: { include: :finance }, invoice_details: {}, contractor: { include: :contractor_finance } }) }
    end

    def fetch_invoices
      statuses = params[:status]&.split(',')&.map(&:to_sym) if params[:status]
      sort_field = params[:sort_field] || 'id'
      sort_direction = params[:sort_direction] || 'asc'
      search_term = params[:search_term]

      invoices = Invoice.includes(client: :finance, invoice_details: {}, invoice_codes: {})
      if search_term.present?
        invoices = invoices.joins('LEFT JOIN clients ON invoices.client_id = clients.id')
                           .joins('LEFT JOIN contractors ON invoices.contractor_id = contractors.id')
                           .where("invoices.description ILIKE :search_term OR invoices.invoice_number ILIKE :search_term OR invoices.company_name ILIKE :search_term OR clients.client_name ILIKE :search_term OR contractors.contractor_name ILIKE :search_term",
                                  search_term: "%#{search_term}%")
      end
      invoices = invoices.where(status: statuses) if statuses && !statuses.empty?
      count = invoices.count
      total_invoices = invoices
      if %w[C-rekening G-rekening].include?(sort_field)
        sorted_invoices = invoices.sort_by do |invoice|
          percentage = calculate_percentage(invoice, sort_field)
          sort_direction == 'asc' ? percentage : -percentage
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal incl'
        sorted_invoices = invoices.sort_by do |invoice|
          total_incl = calculate_sum_of_total_amount(invoice.invoice_details, invoice)
          sort_direction == 'asc' ? total_incl : -total_incl
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal excl'
        sorted_invoices = invoices.sort_by do |invoice|
          total_excl = calculate_total_excluding_vat(invoice.invoice_details)
          sort_direction == 'asc' ? total_excl : -total_excl
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal openstaand'
        sorted_invoices = invoices.sort_by do |invoice|
          total_outstanding = calculate_total_outstanding(invoice)
          sort_direction == 'asc' ? total_outstanding : -total_outstanding
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'client'
        invoices = invoices
                   .left_joins(:client, :contractor)
                   .order(Arel.sql("COALESCE(clients.client_name, contractors.contractor_name, invoices.company_name) #{sort_direction}"))
                   .kaminari_page(params[:page]).per(100)
      else
        invoices = invoices.order("#{sort_field} #{sort_direction}").kaminari_page(params[:page]).per(100)
      end

      clients_with_invoices = Client.joins(:invoices).distinct.map do |client|
        client.attributes.merge('type' => 'client')
      end
      contractors_with_invoices = Contractor.joins(:invoices).distinct.map do |contractor|
        contractor.attributes.merge('type' => 'contractor')
      end
      combined_data = clients_with_invoices + contractors_with_invoices
      render json: {
        invoices: invoices.as_json(include: { client: { include: :finance }, invoice_details: {}, contractor: { include: :contractor_finance } }, methods: [:attachment_attached, :attachment_url]),
        count: count,
        total_invoices: total_invoices.as_json(include: { client: { include: :finance }, invoice_details: {}, contractor: { include: :contractor_finance } }),
        clients: combined_data
      }
    end

    def calculate_total_outstanding(invoice)
      total = invoice.total.to_f

      if invoice.status == 'paid' || invoice.status == 'partially_paid'
        total = invoice.total.to_f
      elsif invoice.client&.finance&.vat_reversed == false
        vat = (invoice.client.finance.vat.to_f * total) / 100
        total += vat
      elsif invoice.contractor&.contractor_finance&.vat_reversed == false
        vat = (invoice.contractor.contractor_finance.vat.to_f * total) / 100
        total += vat
      elsif invoice.client_id.nil? && invoice.contractor_id.nil? && invoice.total_included_vat
        total = invoice.total_included_vat.to_f
      elsif invoice.client&.finance.nil? && invoice.contractor&.contractor_finance.nil?
        vat = (21.0 * total) / 100
        total += vat
      end

      total.round(2)
    end

    def calculate_total_excluding_vat(invoice_details)
      total_sum = invoice_details.sum { |detail| detail.total_amount.to_f }
      total_sum.round(2)
    end

    def calculate_percentage(item, field)
      if item.client&.finance
        percentage_field = field == 'C-rekening' ? 'c_account_percentage' : 'g_account_percentage'
        percentage = item.client.finance[percentage_field].to_f
        total_amount = calculate_sum_of_total_amount(item.invoice_details, item)
        (percentage * total_amount / 100).round(2)
      elsif item.contractor&.contractor_finance
        percentage_field = field == 'C-rekening' ? 'c_account_percentage' : 'g_account_percentage'
        percentage = item.contractor.contractor_finance[percentage_field].to_f
        total_amount = calculate_sum_of_total_amount(item.invoice_details, item)
        (percentage * total_amount / 100).round(2)
      else
        0
      end
    end

    def calculate_sum_of_total_amount(invoice_details, invoice)
      total_sum = invoice_details.sum { |detail| detail.total_amount.to_f }
      vat_rate = 0.0

      if invoice.client&.finance && !invoice.client.finance.vat_reversed
        vat_rate = invoice.client.finance.vat.to_f
      elsif invoice.contractor&.contractor_finance && !invoice.contractor.contractor_finance.vat_reversed
        vat_rate = invoice.contractor.contractor_finance.vat.to_f
      elsif invoice.client_id.nil? && invoice.contractor_id.nil? && invoice.total_included_vat
        total_sum = invoice.total_included_vat.to_f
      elsif !invoice.client&.finance && !invoice.contractor&.contractor_finance
        vat_rate = 21.0
      end

      total_sum += (vat_rate * total_sum / 100)
      total_sum.round(2)
    end

    # def fetch_invoices
    #   statuses = params[:status]&.split(',')&.map(&:to_sym) if params[:status]
    #   invoices = Invoice.includes(client: :finance, invoice_details: {}, invoice_codes: {})
    #   invoices = invoices.where(status: statuses) if statuses && !statuses.empty?
    #   count = invoices.count
    #   total_invoices = invoices
    #   invoices = invoices.order(id: :desc).kaminari_page(params[:page]).per(10)
    #   clients_with_invoices = Client.joins(:invoices).distinct.map do |client|
    #     client.attributes.merge('type' => 'client')
    #   end
    #   contractors_with_invoices = Contractor.joins(:invoices).distinct.map do |contractor|
    #     contractor.attributes.merge('type' => 'contractor')
    #   end
    #   combined_data = clients_with_invoices + contractors_with_invoices
    #   render json: { invoices: invoices.as_json(include: { client: { include: :finance }, invoice_details: {}, contractor: { include: :contractor_finance } }, methods: [:attachment_attached, :attachment_url]),
    #                  count: count, total_invoices: total_invoices.as_json(include: { client: { include: :finance }, invoice_details: {}, contractor: { include: :contractor_finance } }),
    #                  clients: combined_data }
    # end

    def create_contractor_finance
      contractor = Contractor.last
      if contractor.contractor_finance.present?
        finance = contractor.contractor_finance
        if finance.update(
          vat_number: params[:vat_number],
          kvk_number: params[:kvk_number],
          vat: params[:finance_vat],
          c_account_percentage: params[:finance_c_account_percentage],
          g_account_percentage: params[:finance_g_account_percentage],
          payment_term_value: params[:finance_payment_term_value],
          vat_reversed: params[:finance_vat_reversed],
          iban: params[:iban]
        )
          render json: { status: 'success', message: 'Finance details updated successfully' }
        else
          render json: { status: 'error', message: 'Failed to update finance details' }
        end
      else
        finance = ContractorFinance.new(
          vat_number: params[:vat_number],
          kvk_number: params[:kvk_number],
          vat: params[:finance_vat],
          c_account_percentage: params[:finance_c_account_percentage],
          g_account_percentage: params[:finance_g_account_percentage],
          payment_term_value: params[:finance_payment_term_value],
          vat_reversed: params[:finance_vat_reversed],
          contractor_id: contractor.id,
          iban: params[:iban]
        )
        if finance.save
          render json: { status: 'success', message: 'Finance details created successfully' }
        else
          render json: { status: 'error', message: finance.errors.full_messages.join(', ') }
        end
      end
    end

    def create_finance
      client = Client.last
      if client.finance.present?
        finance = client.finance
        if finance.update(
          vat_number: params[:vat_number],
          kvk_number: params[:kvk_number],
          vat: params[:finance_vat],
          c_account_percentage: params[:finance_c_account_percentage],
          g_account_percentage: params[:finance_g_account_percentage],
          payment_term_value: params[:finance_payment_term_value],
          vat_reversed: params[:finance_vat_reversed],
          iban: params[:iban]
        )
          render json: { status: 'success', message: 'Finance details updated successfully' }
        else
          render json: { status: 'error', message: 'Failed to update finance details' }
        end
      else
        finance = Finance.new(
          vat_number: params[:vat_number],
          kvk_number: params[:kvk_number],
          vat: params[:finance_vat],
          c_account_percentage: params[:finance_c_account_percentage],
          g_account_percentage: params[:finance_g_account_percentage],
          payment_term_value: params[:finance_payment_term_value],
          vat_reversed: params[:finance_vat_reversed],
          client_id: client.id,
          iban: params[:iban]
        )
        if finance.save
          render json: { status: 'success', message: 'Finance details created successfully' }
        else
          render json: { status: 'error', message: finance.errors.full_messages.join(', ') }
        end
      end
    end

    def download_file
      invoice = Invoice.find(params[:id])
      attachment = invoice.attachment
      blob = attachment.blob
      send_data(
        blob.download,
        filename: attachment.filename.to_s,
        type: attachment.content_type,
        disposition: 'attachment'
      )
    end

    def download_pdf_zip
      pdfs = []
      if params[:start_date].present? && params[:end_date].present?

        start_date = Date.parse(params[:start_date])
        end_date = Date.parse(params[:end_date])
        invoices = Invoice.where("invoice_date >= ? AND invoice_date <= ?", start_date, end_date)
        if invoices.empty?
          render json: { error: "Er zijn geen facturen gevonden voor het geselecteerde datumbereik." }, status: :unprocessable_entity
          # return
        else
          invoices.each do |invoice|
            invoice_pdf = invoice.invoice_pdf
            pdfs << [invoice_pdf.download, invoice]
          end

          zip_filename = "#{start_date} - #{end_date}.zip"

          Zip::File.open(zip_filename, Zip::File::CREATE) do |zipfile|
            pdfs.each do |pdf_content, invoice|
              pdf_filename = if invoice.client.present?
                               "#{invoice.invoice_number}-#{invoice.client.client_name}.pdf"
                             elsif invoice.contractor.present?
                               "#{invoice.invoice_number}-#{invoice.contractor.contractor_name}.pdf"
                             else
                               "#{invoice.invoice_number}.pdf"
                             end
              zipfile.get_output_stream(pdf_filename) { |f| f.puts pdf_content }
            end
          end

          send_file(
            zip_filename,
            filename: zip_filename,
            type: 'application/zip',
            disposition: 'attachment'
          )
        end
      else
        render json: { error: "start date and end date not selected" }, status: :unprocessable_entity
      end
    end

    private

    def invoice_params
      params.require(:invoice).permit(:client_id, :contractor_id, :invoice_number, :description, :invoice_date, :expiration_date, :payment_term, :status, :invoice_number_character, :year,
                                      :company_name, :attachment)
    end
  end
end
