Trestle.resource(:tkc_cost_amounts) do
  routes do
    post :delete_tkc_cost_amount, on: :collection
  end
  controller do 
    def delete_tkc_cost_amount
      tkc_cost_amount_id = params[:tkc_cost_amount_id]
      tkc_cost_amount = TkcCostAmount.find(tkc_cost_amount_id)
      tkc_cost_amount.destroy
      if tkc_cost_amount.destroyed?
        render json: { reponse: "success" }, status: :ok
      else
        render json: { error: 'Part not found' }, status: :not_found
      end
    end
  end
end