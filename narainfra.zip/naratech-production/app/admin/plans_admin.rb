Trestle.resource(:plans) do
  table do
    column :week
    column :employees do |plan|
      plan.employees.map(&:name).join(', ')
    end
  end

  form do |plan|
    flash.now[:error] = plan.errors.full_messages.join(', ') if plan.errors.any?

    if params[:project]
      project_id = params[:project].to_i
    elsif plan&.project_id
      project_id = plan.project_id.to_i
    end
    hidden_field :project_id, value: project_id
    select :team_ids, Team.all.map { |t| [t.team_name, t.id] },
           { label: t("activerecord.attributes.plan.teams"), prompt: t("prompt.plan.select_teams") }, { multiple: true, selected: @team_ids }
    select :activity_id, Activity.where(project_id: project_id).map { |a| [a.activity_name, a.id] }, label: t("activerecord.attributes.plan.activity"), prompt: t("prompt.plan.select_activity")
    select :start_week_id, Week.where(project_id: project_id).order(year: :asc, week_number: :asc).map { |w| [w.week_number, w.id] },
           { label: t("activerecord.attributes.plan.start_week"), prompt: t("prompt.plan.select_start_week") }, selected: plan.start_week_id
    select :end_week_id, Week.where(project_id: project_id).order(year: :asc, week_number: :asc).map { |w| [w.week_number, w.id] },
           { label: t("activerecord.attributes.plan.end_week"), prompt: t("prompt.plan.select_end_week") }, selected: plan.end_week_id
  end

  controller do
    def create
      plan = Plan.new(plan_params)
      project = plan.project
      if plan.save
        redirect_to "/admin/projects/#{project.id}?tab=plans#!tab-plans"
      else
        flash[:error] = plan.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def update
      plan = Plan.find(params[:id])
      plan.assign_attributes(plan_params)
      project = plan.project

      if plan.save
        redirect_to "/admin/projects/#{project.id}?tab=plans#!tab-plans"
      else
        flash[:error] = plan.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def destroy
      @plan = Plan.find(params[:id])
      project = @plan.project
      @plan.destroy
      redirect_to "/admin/projects/#{project.id}?tab=plans#!tab-plans"
    end

    private

    def plan_params
      params.require(:plan).permit(:project_id, :start_week_id, :end_week_id, :activity_id, team_ids: [])
    end
  end
end
