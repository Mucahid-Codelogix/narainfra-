Trestle.resource(:invoice_settings) do
  authorize do
    actions :index, :edit, :update, :show, :destroy, :fetch_invoice_settings do
      true if current_user.role == "admin"
    end
    actions :new, :create do
      InvoiceSetting.first.nil? && current_user.role == "admin"
    end
  end

  menu do
    item :settings, icon: "fa fa fa-wrench", label: t("menu.invoice_setting"), priority: 7
  end

  routes do
    get :fetch_invoice_settings, on: :collection
  end
  table do
    column :year
    column :characters
    column :digits_length do |resource|
      resource.digits_length_before_type_cast
    end
    actions
  end

  form do |_setting|
    row do
      col(sm: 4) { text_field :characters }
      col(sm: 4) do
        hidden_field :year, value: Time.now.strftime("%y")
        number_field :year, min: 0, value: Time.now.strftime("%y"), disabled: true
      end
      col(sm: 4) do
        select :digits_length, InvoiceSetting.digits_lengths.keys.map { |digit|
                                 [InvoiceSetting.digits_lengths[digit].to_s, digit]
                               }, label: t("activerecord.attributes.invoice_setting.digits_length")
      end
    end
  end
  controller do
    def fetch_invoice_settings
      type = params[:type]
      data = case type
             when 'invoice_setting'
               { invoice_settings: InvoiceSetting.all, certificate_types: [], roles: [], project_settings: [] }
             when 'certificate'
               { certificate_types: CertificateType.all, count: CertificateType.count, invoice_settings: [], roles: [], project_settings: [] }
             when 'roles'
               { roles: Role.all, count: Role.count, invoice_settings: [], certificate_types: [], project_settings: [] }
              when 'project_setting'
                { project_settings: ProjectSetting.all, certificate_types: [], roles: [], invoice_settings: [] }
             else
               { invoice_settings: [], certificate_types: [], roles: [], project_settings: [] }
             end

      render json: data
    end

    def destroy
      @invoice_setting = InvoiceSetting.find(params[:id])
      @invoice_setting.destroy
      redirect_to "/admin/invoice_settings"
    end
  end
end
