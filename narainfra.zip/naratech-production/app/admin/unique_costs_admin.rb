Trestle.resource(:unique_costs) do
  routes do
    post :delete_unique_cost, on: :collection
  end
  controller do
    def delete_unique_cost
      unique_cost_id = params[:id]
      unique_cost = UniqueCost.find(unique_cost_id)
      unique_cost.destroy
      if unique_cost.destroyed?
        render json: { reponse: "success" }, status: :ok
      else
        render json: { error: 'Unique cost not found' }, status: :not_found
      end
    end
  end
end
