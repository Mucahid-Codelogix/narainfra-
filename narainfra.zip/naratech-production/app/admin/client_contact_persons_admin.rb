Trestle.resource(:client_contact_persons) do
  table do
    column :name
    column :position
    column :email
    column :phone
  end

  form do |contact_person|
    flash.now[:error] = contact_person.errors.full_messages.join(', ') if contact_person.errors.any?

    if params[:client]
      client_id = params[:client].to_i
    elsif contact_person&.client_id
      client_id = contact_person.client_id.to_i
    end

    hidden_field :client_id, value: client_id
    row do
      col(sm: 4) { text_field :name }
      col(sm: 4) { text_field :position }
      col(sm: 4) { email_field :email }
    end
    row do
      col(sm: 4) { telephone_field :phone, pattern: '(\+31\d{3,11}|0\d{5,13})', oninvalid: "this.setCustomValidity('#{t('validations.valid_phone_format')}')", oninput: "this.setCustomValidity('')" }
    end
  end

  controller do
    def create
      contact_person = ClientContactPerson.new(contact_person_params)
      client = contact_person.client

      if contact_person.save
        redirect_to "/admin/clients/#{client.id}?tab=Contact_persons#!tab-Contact_persons"
      else
        flash[:error] = contact_person.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def update
      contact_person = ClientContactPerson.find(params[:id])
      contact_person.assign_attributes(contact_person_params)
      client = contact_person.client

      if contact_person.save
        redirect_to "/admin/clients/#{client.id}?tab=Contact_persons#!tab-Contact_persons"
      else
        flash[:error] = contact_person.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def destroy
      @contact_person = ClientContactPerson.find(params[:id])
      client = @contact_person.client
      @contact_person.destroy
      redirect_to "/admin/clients/#{client.id}?tab=Contact_persons#!tab-Contact_persons"
    end

    private

    def contact_person_params
      params.require(:client_contact_person).permit(:client_id, :name, :position, :email, :phone)
    end
  end
end
