Trestle.resource(:activities) do
  controller do
    def destroy
      @activity = Activity.find(params[:id])
      project = @activity.project
      @activity.destroy
      redirect_to "/admin/projects/#{project.id}?tab=Activities#!tab-Activities"
    end
  end
end
