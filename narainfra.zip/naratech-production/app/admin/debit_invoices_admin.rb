Trestle.resource(:debit_invoices) do
  menu do
    group :Facturen, priority: 3 do
      item :debit, icon: "fa fa-money-bill-wave", label: t("menu.invoice_debit"), priority: 2
    end
  end
  routes do
    get :fetch_finances, on: :collection
    get :fetch_projects, on: :collection
    get :fetch_invoices_client, on: :collection
    post :invoice_pdf_creater, on: :member
    post :pdf_download, on: :member
    get :fetch_invoices, on: :collection
    post :update_payment, on: :collection
    post :convert_invoice, on: :collection
    post :download_pdf_zip, on: :collection
  end
  table do
    column :invoice_number
    column :description
    column :invoice_date do |invoice|
      invoice.invoice_date&.strftime("%d/%m/%Y")
    end
    column :expiration_date do |invoice|
      invoice.expiration_date&.strftime("%d/%m/%Y")
    end
    column :paid_date do |invoice|
      invoice.paid_date&.strftime("%d/%m/%Y")
    end
    column :payment_term
    column :status, ->(invoice) { t("activerecord.attributes.invoice.status_#{invoice.status}") }
    column :pdf, link: true do |invoice|
      if invoice&.invoice_pdf.present?
        "<div>
          #{link_to 'Pdf', Rails.application&.routes&.url_helpers&.rails_blob_path(invoice&.invoice_pdf, only_path: true), target: '_blank', class: 'btn btn-primary'}
        </div>".html_safe
      end
    end
    # actions do |toolbar, instance, admin|
    #   link_to "Exporteer PDF", admin.path(:pdf_download, id: instance.id), method: :post, class: "btn btn-primary"
    # end
    actions
  end

  form do |invoice|
    flash.now[:error] = invoice.errors.full_messages.join(', ') if invoice.errors.any?
    hidden_field :payment_term, value: invoice.payment_term, id: 'payment_term_value_display_invoice'
    disabled_fields = true unless invoice.new_record?
    disabled = invoice&.status == "partially_paid" || invoice&.status == "paid"
    if invoice.new_record?
      invoice_setting = InvoiceSetting.first

      last_invoice = DebitInvoice.where(invoice_number_digits: 3, year: Date.current.year, invoice_number_character: "").last
      if last_invoice.present?
        new_invoice_number = last_invoice.digits.to_i + 1
        new_invoice_number = new_invoice_number.to_s.rjust(3, '0')
        invoice_number = "#{Date.current.year}#{new_invoice_number}"
      else
        invoice_number = "#{Date.current.year}001"
      end

      if invoice_setting.present?
        last_invoice = if invoice_setting.characters.present?
                         DebitInvoice.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year,
                                            invoice_number_character: invoice_setting.characters).last
                       elsif invoice_setting.characters.nil?
                         DebitInvoice.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year, invoice_number_character: nil).last
                       else
                         DebitInvoice.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year, invoice_number_character: "").last
                       end
        if last_invoice.present?
          new_invoice_number = last_invoice.digits.to_i + 1
          new_invoice_number = new_invoice_number.to_s.rjust(invoice_setting.digits_length_before_type_cast, '0')
          invoice_number = "#{invoice_setting.characters}#{invoice_setting.characters.present? ? '-' : invoice_setting.characters}#{invoice_setting.year}#{new_invoice_number}"
        else
          new_invoice_number = 1
          new_invoice_number = new_invoice_number.to_s.rjust(invoice_setting.digits_length_before_type_cast, '0')
          invoice_number = "#{invoice_setting.characters}#{invoice_setting.characters.present? ? '-' : invoice_setting.characters}#{invoice_setting.year}#{new_invoice_number}"
        end
        hidden_field :invoice_number_character, value: invoice_setting.characters.present? ? invoice_setting.characters : ""
        hidden_field :year, value: invoice_setting.year
      else
        hidden_field :year, value: Date.current.year
        hidden_field :invoice_number_character, value: ""
      end
    end

    row do
      col(sm: 3) do
        select :client_id, Client.where(active: true).map { |c|
                             [c.client_name, c.id]
                           }, label: t("activerecord.attributes.debit_invoice.client"), prompt: t("prompt.invoice.select_client"), disabled: disabled_fields
      end
      render partial: "admin/shared/create_client_button", locals: { source: "invoices", css_class: "create-client-button-invoice" }
      col(sm: 4) { text_field :invoice_number, value: invoice.invoice_number.present? ? invoice.invoice_number : invoice_number, disabled: invoice.id.present? }
      col(sm: 4) { text_field :description }
    end
    row do
      col(sm: 4) do
        render partial: "admin/shared/date_field", locals: {
          label: t("activerecord.attributes.debit_invoice.invoice_date"),
          field_name: "debit_invoice[invoice_date]",
          field_id: "invoice_invoice_date",
          formatted_value: invoice.invoice_date&.present? ? invoice.invoice_date&.strftime('%d/%m/%Y') : Time.now.in_time_zone('Amsterdam').strftime('%d/%m/%Y')
        }
      end
      col(sm: 4) do
        render partial: "admin/shared/date_field", locals: {
          label: t("activerecord.attributes.debit_invoice.expiration_date"),
          field_name: "debit_invoice[expiration_date]",
          field_id: "invoice_expiration_date",
          formatted_value: invoice.expiration_date&.present? ? invoice.expiration_date&.strftime('%d/%m/%Y') : Time.now.in_time_zone('Amsterdam').strftime('%d/%m/%Y'),
          disabled: true
        }
      end
      if invoice&.status == "paid"
        col(sm: 4) do
          render partial: "admin/shared/date_field", locals: {
            label: t("activerecord.attributes.debit_invoice.paid_date"),
            field_name: "debit_invoice[paid_date]",
            field_id: "debit_invoice_paid_date",
            formatted_value: invoice.paid_date&.present? ? invoice.paid_date&.strftime('%d/%m/%Y') : Time.now.in_time_zone('Amsterdam').strftime('%d/%m/%Y'),
            disabled: true
          }
        end
      end
      col(sm: 4) do
        # payment_term_value = invoice&.client&.finance&.payment_term_value || 0
        # "<div class='form-group'>
        #   <label class='control-label'>#{t('activerecord.attributes.debit_invoice.payment_term')}</label>
        #   <div class='form-control' id='payment_term_value_display_invoice'>#{payment_term_value}</div>
        # </div>".html_safe
      end
    end

    table invoice.invoice_details.order(id: :asc), admin: InvoiceDetailsAdmin, class: "invoice-details-table", id: "invoice-details-table" do |t|
      t.column :amount, sort: false do |invoice_detail|
        "<div>
          #{number_field_tag "invoice_details[#{invoice_detail.id}][amount]", invoice_detail.amount, class: 'amount-field-invoice-detail form-control text-currency', disabled: disabled}
        </div>".html_safe
      end
      t.column :description, sort: false do |invoice_detail|
        text_field_tag "invoice_details[#{invoice_detail.id}][description]", invoice_detail.description, id: "description-#{invoice_detail.id}", class: "invoice-detail-description form-control",
                                                                                                         disabled: disabled
      end
      t.column :unit, sort: false do |invoice_detail|
        text_field_tag "invoice_details[#{invoice_detail.id}][unit]", invoice_detail.unit, id: "unit-#{invoice_detail.id}", class: "invoice-detail-unit form-control", disabled: disabled
      end
      t.column :price_excluding_vat, sort: false do |invoice_detail|
        "<div class='currency-wrap'>
          <span class='currency-code'>€</span>
          #{number_field_tag "invoice_details[#{invoice_detail.id}][price]", invoice_detail.price, class: 'price-field-invoice-detail form-control text-currency', disabled: disabled, step: 'any'}
        </div>".html_safe
      end

      t.column :vat, lambda { |_invoice_detail|
        "#{invoice&.client&.finance.present? ? invoice&.client&.finance&.vat : 0}% "
      }, class: "vat-column-invoice-detail table-font-code"
      t.column :price_including_vat, lambda { |invoice_detail|
                                       vat = 21
                                       vat_reversed = false
                                       if invoice&.client&.finance.present?
                                         vat = invoice.client.finance.vat
                                         vat_reversed = invoice.client.finance.vat_reversed
                                       end
                                       vat = (vat * invoice_detail&.total_amount) / 100
                                       total_amount = if vat_reversed == false
                                                        vat + invoice_detail&.total_amount
                                                      else
                                                        invoice_detail&.total_amount
                                                      end
                                       invoice_detail.debit_invoice.client.euro_format(invoice_detail.debit_invoice.client.format_number(total_amount&.ceil(2)))
                                     }, class: "total-column-invoice-detail table-font-code"
      if disabled == false
        t.column :action, sort: false do |invoice_detail|
          button_tag "Delete", type: "button", class: "btn btn-danger invoice-delete-button", data: { invoice_detail_id: invoice_detail.id, source: "debit-invoices" }
        end
      end
    end
    render partial: "admin/shared/add_row", locals: { id: "add-invoice" } if disabled == false
  end

  controller do
    before_action :invoice_details_calculation, only: [:update]

    def create
      invoice = DebitInvoice.new(invoice_params)
      invoice_number = invoice.invoice_number
      invoice_setting = InvoiceSetting.first
      pattern = if invoice_setting.present?
                  /\d{2}(\d+)$/
                else
                  /\d{4}(\d+)$/
                end
      match = invoice_number.match(pattern)
      if match
        digits_after_year = match[1]
        digits_after_year_length = digits_after_year.length
        invoice.invoice_number_digits = digits_after_year_length
        invoice.digits = digits_after_year
      end
      if invoice.save
        @invoice_id = invoice.id
        invoice_details_calculation
        redirect_to debit_invoices_admin_index_path
      else
        render json: { errors: invoice.errors.full_messages }, status: :unprocessable_entity
        # super
      end
    end

    def invoice_details_calculation
      id = params[:id] || @invoice_id
      total = 0
      invoice = DebitInvoice.find(id)
      invoice_details = params[:invoice_details]
      if invoice&.status == "sent" || invoice&.status == "open"
        invoice_details&.each do |invoice_detail_id, detail_params|
          invoice_detail = invoice.invoice_details.find_by(id: invoice_detail_id)
          total += BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
          if invoice_detail.present?
            invoice_detail.update(
              description: detail_params[:description],
              unit: detail_params[:unit],
              amount: detail_params[:amount],
              price: detail_params[:price],
              total_amount: BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
            )
          else
            InvoiceDetail.create(
              debit_invoice: invoice,
              description: detail_params[:description],
              unit: detail_params[:unit],
              amount: detail_params[:amount],
              price: detail_params[:price],
              total_amount: BigDecimal(detail_params[:amount].to_s) * BigDecimal(detail_params[:price].to_s)
            )
          end
        end
        invoice.update(total: total)
      end
      invoice_pdf_creater(id)
    end

    def fetch_projects
      client = Client.find(params[:id])
      finance = client.finance
      projects = client.projects
      render json: { projects: projects, finance: finance }
    end

    def update_payment
      amsterdam_time_zone = ActiveSupport::TimeZone.new('Amsterdam')
      current_datetime_amsterdam = Time.now.in_time_zone(amsterdam_time_zone)
      current_date_amsterdam = if params[:payment_date].present?
                                 Date.parse(params[:payment_date])
                               else
                                 current_datetime_amsterdam.to_date

                               end
      invoices = params[:invoices]
      included_vat_value = nil
      paid_amount = params[:paidAmount].to_f
      if invoices.is_a?(Array)
        invoices.each do |invoice_id|
          invoice = DebitInvoice.find(invoice_id)
          if paid_amount.positive?
            if invoice.status == "partially_paid" || invoice.status == "paid"
              total = invoice.total - paid_amount
            elsif invoice&.client&.finance.present? && invoice&.client&.finance&.vat_reversed == false
              vat = (invoice.client.finance.vat * invoice.total) / 100
              total = invoice.total + vat - paid_amount
              included_vat_value = invoice.client.finance.vat
            elsif invoice&.client&.finance.blank?
              vat = (21.0 * invoice.total) / 100
              total = invoice.total + vat - paid_amount
              included_vat_value = 21.0
            else
              total = invoice.total - paid_amount
            end
            if total.positive?
              status = "partially_paid"
            elsif total.zero? || total.negative?
              status = "paid"
            end
            paid_value = invoice.paid_value + paid_amount
            paid_value = total + invoice.paid_value if paid_amount > total
            total = [total, 0].max
            invoice.update(status: status, total: total, payment_date: current_date_amsterdam, paid_value: paid_value, paid_date: current_date_amsterdam, included_vat_value: included_vat_value)
          elsif paid_amount.negative? && (invoice.status == "paid" || invoice.status == "partially_paid")
            total = invoice.total
            total_amount = 0
            total_amount_include_tax = 0
            amount_paid = invoice.paid_value
            status = invoice.status
            converted_paid_amount_sign = paid_amount.abs
            invoice&.invoice_details&.each do |i|
              total_amount += i.total_amount
            end
            total_amount_include_tax = include_tax_value(invoice, total_amount)
            if converted_paid_amount_sign == total_amount_include_tax || (total_amount_include_tax == invoice.total + converted_paid_amount_sign)
              total = total_amount
              amount_paid = 0
              status = "open"
              included_vat_value = nil
            elsif total_amount_include_tax > invoice.total + converted_paid_amount_sign
              total = invoice.total + converted_paid_amount_sign
              amount_paid = total_amount_include_tax - (invoice.total + converted_paid_amount_sign)
              status = "partially_paid"
              included_vat_value = if invoice&.client&.finance.present?
                                     invoice.client.finance.vat
                                   else
                                     21.0
                                   end
            end
            invoice.update(status: status, total: total, payment_date: current_date_amsterdam, paid_value: amount_paid, paid_date: current_date_amsterdam, included_vat_value: included_vat_value)
          end
        end
      else
        invoice = DebitInvoice.find(invoices)
        if paid_amount.positive?
          if invoice.status == "partially_paid" || invoice.status == "paid"
            total = invoice.total - paid_amount
          elsif invoice&.client&.finance.present? && invoice&.client&.finance&.vat_reversed == false
            vat = (invoice.client.finance.vat * invoice.total) / 100
            total = invoice.total + vat - paid_amount
            included_vat_value = invoice.client.finance.vat
          elsif invoice&.client&.finance.blank?
            vat = (21.0 * invoice.total) / 100
            total = invoice.total + vat - paid_amount
            included_vat_value = 21.0
          else
            total = invoice.total - paid_amount
          end
          if total.positive?
            status = "partially_paid"
          elsif total.zero? || total.negative?
            status = "paid"
          end
          paid_value = invoice.paid_value + paid_amount
          paid_value = total + invoice.paid_value if paid_amount > total
          total = [total, 0].max
          invoice.update(status: status, total: total, payment_date: current_date_amsterdam, paid_value: paid_value, paid_date: current_date_amsterdam, included_vat_value: included_vat_value)
        elsif paid_amount.negative? && (invoice.status == "paid" || invoice.status == "partially_paid")
          total = invoice.total
          total_amount = 0
          total_amount_include_tax = 0
          amount_paid = invoice.paid_value
          status = invoice.status
          converted_paid_amount_sign = paid_amount.abs
          invoice&.invoice_details&.each do |i|
            total_amount += i.total_amount
          end
          total_amount_include_tax = include_tax_value(invoice, total_amount)
          if converted_paid_amount_sign == total_amount_include_tax || (total_amount_include_tax == invoice.total + converted_paid_amount_sign)
            total = total_amount
            amount_paid = 0
            status = "open"
            included_vat_value = nil
          elsif total_amount_include_tax > invoice.total + converted_paid_amount_sign
            total = invoice.total + converted_paid_amount_sign
            amount_paid = total_amount_include_tax - (invoice.total + converted_paid_amount_sign)
            status = "partially_paid"
            included_vat_value = if invoice&.client&.finance.present?
                                   invoice.client.finance.vat
                                 else
                                   21.0
                                 end
          else
            return
          end
          invoice.update(status: status, total: total, payment_date: current_date_amsterdam, paid_value: amount_paid, paid_date: current_date_amsterdam, included_vat_value: included_vat_value)
        end
      end

      render json: { status: 'success', message: 'Payment updated successfully' }
    end

    def include_tax_value(invoice, _total_amount)
      total_amount = _total_amount
      if invoice&.client&.finance.present? && invoice&.client&.finance&.vat_reversed == false
        vat = (invoice.client.finance.vat * total_amount) / 100
        total_amount += vat
      elsif invoice&.client&.finance.blank?
        vat = (21.0 * total_amount) / 100
        total_amount += vat
      end
      total_amount.round(2)
    end

    def convert_invoice
      debit_invoice = DebitInvoice.find(params[:invoice_id])
      invoice_number = debit_invoice.invoice_number
      invoice_setting = InvoiceSetting.first
      pattern = if invoice_setting.present?
                  /\d{2}(\d+)$/
                else
                  /\d{4}(\d+)$/
                end
      match = invoice_number.match(pattern)
      if match
        digits_after_year = match[1]
        digits_after_year_length = digits_after_year.length
        invoice_number_digits = digits_after_year_length
        digits = digits_after_year
      end
      ActiveRecord::Base.transaction do
        amsterdam_time_zone = ActiveSupport::TimeZone.new('Amsterdam')
        current_datetime_amsterdam = Time.now.in_time_zone(amsterdam_time_zone)
        current_date_amsterdam = current_datetime_amsterdam.to_date
        invoice_setting = InvoiceSetting.first
        last_invoice = DebitInvoice.where(invoice_number_digits: 3, year: Date.current.year, invoice_number_character: "").last
        if last_invoice.present?
          new_invoice_number = last_invoice.digits.to_i + 1
          new_invoice_number = new_invoice_number.to_s.rjust(3, '0')
          digits = new_invoice_number
          invoice_number_digits = 3
          invoice_number = "#{Date.current.year}#{new_invoice_number}"
        else
          invoice_number = "#{Date.current.year}001"
        end
        year = Date.current.year
        if invoice_setting.present?
          last_invoice = if invoice_setting.characters.present?
                           DebitInvoice.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year,
                                              invoice_number_character: invoice_setting.characters).last
                         elsif invoice_setting.characters.nil?
                           DebitInvoice.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year, invoice_number_character: nil).last
                         else
                           DebitInvoice.where(invoice_number_digits: invoice_setting.digits_length_before_type_cast, year: invoice_setting.year, invoice_number_character: "").last
                         end
          if last_invoice.present?
            new_invoice_number = last_invoice.digits.to_i + 1
            new_invoice_number = new_invoice_number.to_s.rjust(invoice_setting.digits_length_before_type_cast, '0')
            invoice_number = "#{invoice_setting.characters}#{invoice_setting.characters.present? ? '-' : invoice_setting.characters}#{invoice_setting.year}#{new_invoice_number}"
          else
            new_invoice_number = 1
            new_invoice_number = new_invoice_number.to_s.rjust(invoice_setting.digits_length_before_type_cast, '0')
            invoice_number = "#{invoice_setting.characters}#{invoice_setting.characters.present? ? '-' : invoice_setting.characters}#{invoice_setting.year}#{new_invoice_number}"
          end
          digits = new_invoice_number
          invoice_number_digits = new_invoice_number.length
          invoice_number_character = invoice_setting.characters.present? ? invoice_setting.characters : ""
          year = invoice_setting.year
        end
        # Create a new credit invoice
        credit_invoice = DebitInvoice.new(
          client_id: debit_invoice.client_id,
          invoice_number: invoice_number,
          description: debit_invoice.description,
          invoice_date: debit_invoice.invoice_date,
          expiration_date: debit_invoice.expiration_date,
          paid_date: debit_invoice.paid_date,
          status: "paid",
          invoice_type: "debit",
          payment_date: current_date_amsterdam,
          total: -debit_invoice.total,
          paid_value: current_date_amsterdam,
          credited: true,
          digits: digits,
          invoice_number_digits: invoice_number_digits,
          year: year,
          invoice_number_character: invoice_number_character.present? ? invoice_number_character : ""
        )
        if credit_invoice.save
          debit_invoice.invoice_details.each do |invoice_detail|
            InvoiceDetail.create!(
              debit_invoice_id: credit_invoice.id,
              description: invoice_detail.description,
              unit: invoice_detail.unit,
              amount: invoice_detail.amount,
              price: invoice_detail.price,
              total_amount: -invoice_detail.total_amount
            )
          end
          debit_invoice.update(status: "paid")
        end
        # If everything is successful, delete the debit invoice
        # debit_invoice.destroy!
      end
      render json: { success: true, message: 'Invoice converted successfully' }
    rescue ActiveRecord::RecordNotFound
      render json: { success: false, message: 'Debit invoice not found' }, status: :not_found
    rescue ActiveRecord::RecordInvalid => e
      render json: { success: false, message: e.message }, status: :unprocessable_entity
    rescue StandardError => e
      render json: { success: false, message: "An error occurred: #{e.message}" }, status: :internal_server_error
    end

    # def convert_invoice
    #   debit_invoice = params[:invoice]
    #   invoice = Invoice.new(
    #     client_id: debit_invoice.client_id,
    #     invoice_number: debit_invoice.invoice_number,
    #     description: debit_invoice.description,
    #     invoice_date: debit_invoice.invoice_date,
    #     expiration_date: debit_invoice.expiration_date,
    #     paid_date: debit_invoice.paid_date,
    #     status: debit_invoice.status,
    #     invoice_type: "credit",
    #     payment_date: debit_invoice.payment_date,
    #     total: debit_invoice.total,
    #     paid_value: debit_invoice.paid_value
    #   )
    #   if invoice.save
    #      invoice_details = debit_invoice.invoice_details
    #      invoice_details&.each do |invoice_detail|
    #         InvoiceDetail.create(
    #           invoice_id: invoice.id,
    #           description: invoice_detail.description,
    #           unit: invoice_detail.unit,
    #           amount: invoice_detail.amount,
    #           price: invoice_detail.price,
    #           total_amount: invoice_detail.total_amount
    #         )
    #      end
    # end

    def fetch_weeks_and_codes
      project = Project.find(params[:id])
      weeks = project.weeks
      specification_codes = project.specification_codes
      render json: { weeks: weeks, specification_codes: specification_codes }
    end

    def invoice_pdf_creater(id)
      invoice = DebitInvoice.find(id)
      invoice_details = invoice&.invoice_details
      client = invoice.client
      template = params[:template]
      pdf_filename = "#{invoice.invoice_number}-#{invoice.client.client_name}.pdf"
      template_path = "#{Rails.root}/app/views/trestle/invoice/debit_invoice_pdf.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)

      invoice.invoice_pdf.attach(io: StringIO.new(pdf), filename: pdf_filename, content_type: 'application/pdf')
    end

    def pdf_download
      invoice = DebitInvoice.find(params[:id])
      invoice_details = invoice&.invoice_details
      client = invoice.client
      template = params[:template]
      pdf_filename = "#{invoice.invoice_number}-#{invoice.client.client_name}.pdf"
      template_path = "#{Rails.root}/app/views/trestle/invoice/debit_invoice_pdf.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)

      if params[:preview].present?
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'inline')
      else
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'attachment')
      end
      # redirect_to "/admin/projects/8?tab=weeks#!tab-weeks"
    end

    def fetch_finances
      client = Client.find(params[:id])
      finance = client.finance
      render json: { finance: finance }
    end

    def fetch_invoices_client
      statuses = params[:status]&.split(',')&.map(&:to_sym) if params[:status]
      sort_field = params[:sort_field] || 'id'
      sort_direction = params[:sort_direction] || 'asc'
      search_term = params[:search_term]
      client_id = params[:client_id]
      invoices = DebitInvoice.where(client_id: client_id)
      if search_term.present?
        if search_term.present?
          invoices = invoices.joins('LEFT JOIN clients ON debit_invoices.client_id = clients.id')
                             .where("debit_invoices.description ILIKE :search_term OR debit_invoices.invoice_number ILIKE :search_term OR clients.client_name ILIKE :search_term",
                                    search_term: "%#{search_term}%")
        end
      end
      invoices = invoices.where(status: statuses) if statuses && !statuses.empty?
      total_invoices = invoices
      count = invoices.count
      # invoices = invoices.order(id: :desc).kaminari_page(params[:page]).per(10)
      if ['C-rekening', 'G-rekening'].include?(sort_field)
        sorted_invoices = invoices.sort_by do |invoice|
          percentage = calculate_percentage(invoice, sort_field)
          sort_direction == 'asc' ? percentage : -percentage
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal incl'
        sorted_invoices = invoices.sort_by do |invoice|
          total_incl = calculate_sum_of_total_amount(invoice.invoice_details, invoice)
          sort_direction == 'asc' ? total_incl : -total_incl
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal excl'
        sorted_invoices = invoices.sort_by do |invoice|
          total_excl = calculate_total_excluding_vat(invoice.invoice_details)
          sort_direction == 'asc' ? total_excl : -total_excl
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal openstaand'
        sorted_invoices = invoices.sort_by do |invoice|
          total_outstanding = calculate_total_outstanding(invoice)
          sort_direction == 'asc' ? total_outstanding : -total_outstanding
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'client'
        invoices = invoices.joins(:client).order("clients.client_name #{sort_direction}").kaminari_page(params[:page]).per(100)
      else
        invoices = invoices.order("#{sort_field} #{sort_direction}").kaminari_page(params[:page]).per(100)
      end
      render json: { invoices: invoices.as_json(include: { client: { include: :finance }, invoice_details: {} }), count: count,
                     total_invoices: total_invoices.as_json(include: { client: { include: :finance }, invoice_details: {} }) }
    end

    def fetch_invoices
      statuses = params[:status]&.split(',')&.map(&:to_sym) if params[:status]
      sort_field = params[:sort_field] || 'id'
      sort_direction = params[:sort_direction] || 'asc'
      search_term = params[:search_term]
      invoices = DebitInvoice.includes(client: :finance, invoice_details: {}, invoice_codes: {})
      if search_term.present?
        if search_term.present?
          invoices = invoices.joins('LEFT JOIN clients ON debit_invoices.client_id = clients.id')
                             .where("debit_invoices.description ILIKE :search_term OR debit_invoices.invoice_number ILIKE :search_term OR clients.client_name ILIKE :search_term",
                                    search_term: "%#{search_term}%")
        end
      end
      invoices = invoices.where(status: statuses) if statuses && !statuses.empty?
      total_invoices = invoices
      count = invoices.count
      # invoices = invoices.order(id: :desc).kaminari_page(params[:page]).per(10)
      if ['C-rekening', 'G-rekening'].include?(sort_field)
        sorted_invoices = invoices.sort_by do |invoice|
          percentage = calculate_percentage(invoice, sort_field)
          sort_direction == 'asc' ? percentage : -percentage
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal incl'
        sorted_invoices = invoices.sort_by do |invoice|
          total_incl = calculate_sum_of_total_amount(invoice.invoice_details, invoice)
          sort_direction == 'asc' ? total_incl : -total_incl
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal excl'
        sorted_invoices = invoices.sort_by do |invoice|
          total_excl = calculate_total_excluding_vat(invoice.invoice_details)
          sort_direction == 'asc' ? total_excl : -total_excl
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'Totaal openstaand'
        sorted_invoices = invoices.sort_by do |invoice|
          total_outstanding = calculate_total_outstanding(invoice)
          sort_direction == 'asc' ? total_outstanding : -total_outstanding
        end
        invoices = Kaminari.paginate_array(sorted_invoices).page(params[:page]).per(100)
      elsif sort_field == 'client'
        invoices = invoices.joins(:client).order("clients.client_name #{sort_direction}").kaminari_page(params[:page]).per(100)
      else
        invoices = invoices.order("#{sort_field} #{sort_direction}").kaminari_page(params[:page]).per(100)
      end
      clients_with_invoices = Client.joins(:debit_invoices).distinct
      render json: { invoices: invoices.as_json(include: { client: { include: :finance }, invoice_details: {} }), count: count, clients: clients_with_invoices,
                     total_invoices: total_invoices.as_json(include: { client: { include: :finance }, invoice_details: {} }) }
    end

    def calculate_total_outstanding(invoice)
      total = invoice.total.to_f
      
      if invoice.status == 'paid' || invoice.status == 'partially_paid'
        total = invoice.total.to_f
      elsif invoice.client&.finance&.vat_reversed == false
        vat = (invoice.client.finance.vat.to_f * total) / 100
        total += vat
      elsif invoice.contractor&.contractor_finance&.vat_reversed == false
        vat = (invoice.contractor.contractor_finance.vat.to_f * total) / 100
        total += vat
      elsif invoice.client_id.nil? && invoice.contractor_id.nil? && invoice.total_included_vat
        total = invoice.total_included_vat.to_f
      elsif invoice.client&.finance.nil? && invoice.contractor&.contractor_finance.nil?
        vat = (21.0 * total) / 100
        total += vat
      end
      
      total.round(2)
    end
    

    def calculate_total_excluding_vat(invoice_details)
      total_sum = invoice_details.sum { |detail| detail.total_amount.to_f }
      total_sum.round(2)
    end

    def calculate_percentage(item, field)
      if item.client&.finance
        percentage_field = field == 'C-rekening' ? 'c_account_percentage' : 'g_account_percentage'
        percentage = item.client.finance[percentage_field].to_f
        total_amount = calculate_sum_of_total_amount(item.invoice_details, item)
        return (percentage * total_amount / 100).round(2)
      elsif item.contractor&.contractor_finance
        percentage_field = field == 'C-rekening' ? 'c_account_percentage' : 'g_account_percentage'
        percentage = item.contractor.contractor_finance[percentage_field].to_f
        total_amount = calculate_sum_of_total_amount(item.invoice_details, item)
        return (percentage * total_amount / 100).round(2)
      else
        return 0
      end
    end

    def calculate_sum_of_total_amount(invoice_details, invoice)
      total_sum = invoice_details.sum { |detail| detail.total_amount.to_f }
      vat_rate = 0.0
    
      if invoice.client&.finance && !invoice.client.finance.vat_reversed
        vat_rate = invoice.client.finance.vat.to_f
      elsif invoice.contractor&.contractor_finance && !invoice.contractor.contractor_finance.vat_reversed
        vat_rate = invoice.contractor.contractor_finance.vat.to_f
      elsif invoice.client_id.nil? && invoice.contractor_id.nil? && invoice.total_included_vat
        total_sum = invoice.total_included_vat.to_f
      elsif !invoice.client&.finance && !invoice.contractor&.contractor_finance
        vat_rate = 21.0
      end
    
      total_sum += (vat_rate * total_sum / 100)
      return total_sum.round(2)
    end

    def download_pdf_zip
      pdfs = []
      if params[:start_date].present? && params[:end_date].present?

        start_date = Date.parse(params[:start_date])
        end_date = Date.parse(params[:end_date])
        invoices = DebitInvoice.where("invoice_date >= ? AND invoice_date <= ?", start_date, end_date)
        if invoices.empty?
          render json: { error: "Er zijn geen facturen gevonden voor het geselecteerde datumbereik." }, status: :unprocessable_entity
          # return
        else
          invoices.each do |invoice|
            invoice_pdf = invoice.invoice_pdf
            pdfs << [invoice_pdf.download, invoice]
          end

          zip_filename = "#{start_date} - #{end_date}.zip"

          Zip::File.open(zip_filename, Zip::File::CREATE) do |zipfile|
            pdfs.each do |pdf_content, invoice|
              pdf_filename = if invoice.client.present?
                               "#{invoice.invoice_number}-#{invoice.client.client_name}.pdf"
                             elsif invoice.contractor.present?
                               "#{invoice.invoice_number}-#{invoice.contractor.contractor_name}.pdf"
                             else
                               "#{invoice.invoice_number}.pdf"
                             end
              zipfile.get_output_stream(pdf_filename) { |f| f.puts pdf_content }
            end
          end

          send_file(
            zip_filename,
            filename: zip_filename,
            type: 'application/zip',
            disposition: 'attachment'
          )
        end
      else
        render json: { error: "start date and end date not selected" }, status: :unprocessable_entity
      end
    end

    private

    def invoice_params
      params.require(:debit_invoice).permit(:client_id, :invoice_number, :description, :invoice_date, :expiration_date, :payment_term, :status, :vat, :invoice_number_character, :year)
    end
  end
end
