Trestle.resource(:certificate_types) do
  table do
    column :name
    actions
  end

  form do |_certificate_type|
    text_field :name
  end

  controller do
    def create
      @certificate_type = CertificateType.new(params.require(:certificate_type).permit(:name))

      if @certificate_type.save
        flash[:message] = "Certificaattype is succesvol aangemaakt"
      else
        flash[:error] = @certificate_type.errors.full_messages.to_sentence
      end
      respond_to do |format|
        format.js { render js: "location.reload();" }
      end
    end

    def destroy
      @certificate_type = CertificateType.find(params[:id])
      @certificate_type.destroy
      redirect_to "/admin/invoice_settings?type=certificate"
    end
  end
end
