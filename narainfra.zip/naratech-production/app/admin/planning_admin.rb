Trestle.admin(:planning) do
  menu do
    item :planning, icon: "fa fa-chart-bar", priority: :last if current_user.role == "admin"
  end

  controller do
  end
end
