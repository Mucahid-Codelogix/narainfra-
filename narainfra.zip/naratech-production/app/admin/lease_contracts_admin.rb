Trestle.resource(:lease_contracts) do
  table do
   
  end
  form do |lease_contract|
    flash.now[:error] = lease_contract.errors.full_messages.join(', ') if lease_contract.errors.any?
    if params[:material]
      material_id = params[:material]&.to_i || nil
    elsif params[:equipment_material]
      equipment_material_id = params[:equipment_material]&.to_i || nil
    elsif lease_contract&.material_id
      material_id = lease_contract.material_id.to_i
    elsif lease_contract&.equipment_material_id
      equipment_material_id = lease_contract.equipment_material_id.to_i
    end

    hidden_field :material_id, value: material_id
    hidden_field :equipment_material_id, value: equipment_material_id

    row do
      col(sm: 4) { text_field :lease_company }
      col(sm: 4) { text_field :contract_number }
      col(sm: 4) { text_field :lease_amount_ex_vat }
    end
  end

  controller do
    def create
      lease_contract = LeaseContract.new(lease_contract_params)
      material = lease_contract.material
      equipment_material = lease_contract.equipment_material

      if lease_contract.save
        if lease_contract.material.present?
          redirect_to "/admin/materials/#{material.id}?tab=lease_contract#!tab-lease_contract"
        else
          redirect_to "/admin/equipment_materials/#{equipment_material.id}?tab=lease_contract#!tab-lease_contract"
        end
      else
        super
      end
    end

    def update
      lease_contract = LeaseContract.find(params[:id])
      lease_contract.assign_attributes(lease_contract_params)
      material = lease_contract.material
      equipment_material = lease_contract.equipment_material

      if lease_contract.save
        if lease_contract.material.present?
          redirect_to "/admin/materials/#{material.id}?tab=lease_contract#!tab-lease_contract"
        else
          redirect_to "/admin/equipment_materials/#{equipment_material.id}?tab=lease_contract#!tab-lease_contract"
        end
        # redirect_to "/admin/materials/#{material.id}?tab=lease_contract#!tab-lease_contract"
      else
        super
      end
    end

    private

    def lease_contract_params
      params.require(:lease_contract).permit(:material_id, :lease_company, :contract_number, :lease_amount_ex_vat, :equipment_material_id)
    end
  end
end
