Trestle.resource(:teams) do
  menu do
    item :teams, icon: "fas fa-user-tie", label: t("menu.teams"), priority: 5
  end

  authorize do
    actions :new, :show, :create, :index, :edit, :update, :destroy do
      current_user.role == "admin"
    end
  end

  table do
    column :team_name
    column :employees do |team|
      team.employees.map(&:first_name).join(', ')
    end
  end

  form do |team|
    text_field :team_name
    select :employee_ids, Employee.all.map { |e| [e.first_name, e.id] },
           { label: t("activerecord.attributes.team.employees"), prompt: t("prompt.team.select_employees") }, { multiple: true, selected: @employee_ids }
  end
end
