Trestle.resource(:tkc_costs) do
  table do
    column :week, ->(tkc_cost) { tkc_cost.week.week_number }
    column :services
    column :material
    column :additional
    column :tkc_total
    actions
  end

  routes do
    get :specification_code, on: :collection
  end

  form do |tkc_cost|
    flash.now[:error] = tkc_cost.errors.full_messages.join(', ') if tkc_cost.errors.any?

    if params[:project]
      project_id = params[:project].to_i
    elsif tkc_cost&.project_id
      project_id = tkc_cost.project_id.to_i
      # tkc_cost = TkcCost.find(tkc_cost.id)
      @week = tkc_cost.week
    end

    disabled_fields = tkc_cost.persisted?

    project = Project.find(project_id)
    hidden_field :project_id, value: project_id, id: "tkc-cost-project-field", data: { project_id: project_id, tkc_cost_amount: tkc_cost.tkc_cost_amounts }
    row do
      col(sm: 4) { text_field :project_number, label: t("activerecord.attributes.tkc_cost.project"), value: project.projectnumber, disabled: true }
      col(sm: 4) do
        select :week_id, Week.where(project_id: project_id).order(year: :asc, week_number: :asc).map { |w|
                           [w.week_number, w.id]
                         }, label: t("activerecord.attributes.tkc_cost.week"), prompt: t("prompt.tkc_cost.select_week"), disabled: disabled_fields
      end
    end
    label :tkc_description, t("activerecord.attributes.tkc_cost.tkc_description"), class: "control-label"
    rich_text_area :tkc_description
    table tkc_cost.unique_costs.order(id: :asc), admin: UniqueCostsAdmin, class: "unique-cost-table", id: "unique-cost-table" do |t|
      t.column :description, sort: false do |unique_cost|
        text_field_tag "unique_costs[#{unique_cost.id}][description]", unique_cost.description, id: "description-#{unique_cost.id}", class: "unique-cost-description form-control"
      end
      t.column :amount, sort: false do |unique_cost|
        "<div>
          #{number_field_tag "unique_costs[#{unique_cost.id}][amount]", unique_cost.amount, class: 'amount-field-unique-cost form-control text-currency', step: 'any'}
      </div>".html_safe
      end
      t.column :price, sort: false do |unique_cost|
        "<div class='currency-wrap'>
          <span class='currency-code'>€</span>
          #{number_field_tag "unique_costs[#{unique_cost.id}][price]", unique_cost.price, class: 'price-unique-cost form-control text-currency', step: 'any'}
        </div>".html_safe
      end

      t.column :total, lambda { |unique_cost|
                         tkc_cost.project.euro_format(project.format_number(unique_cost.total))
                       }, class: "total-column-unique-cost table-font-code"

      t.column :action, sort: false do |unique_cost|
        button_tag "Verwijderen", type: "button", class: "btn btn-danger unique-cost-delete-button", data: { unique_cost_id: unique_cost.id }
      end
    end
    render partial: "admin/shared/add_row", locals: { id: "add-unique-cost" }
    table tkc_cost.tkc_cost_amounts.order(id: :asc), admin: TkcCostAmountsAdmin, class: "tkc-cost-amount-table", id: "tkc-cost-amount-table" do |t|
      t.column :specification_code, sort: false do |tkc_cost_amount|
        spec_code = tkc_cost_amount.specification_code
        description = spec_code.description.present? ? " - #{spec_code.description}" : ""
        specification_display = "#{spec_code.specification_code}#{description}"
        text_field_tag "tkc_cost_amount_codes[#{tkc_cost_amount.id}][specification_code]", specification_display, id: "specification-code-field-#{tkc_cost_amount.id}",
                                                                                                                  class: "specification-code-field form-control", readonly: true
      end

      t.column :amount, class: "tkc-cost-amount-col", sort: false do |tkc_cost_amount|
        spec_code = tkc_cost_amount.specification_code
        "<div>
          #{hidden_field_tag "tkc_cost_amount_codes[#{tkc_cost_amount.id}][specification_code_id]", spec_code.id}
          #{number_field_tag "tkc_cost_amount_codes[#{tkc_cost_amount.id}][amount]", tkc_cost_amount.amount, class: 'amount-field-tkc-cost', min: 0}
        </div>".html_safe
      end
      t.column :price, class: "price-column-tkc-cost table-font-code" do |tkc_cost_amount|
        price = if tkc_cost_amount.price.present?
                  tkc_cost.week.project.euro_format(tkc_cost.week.project.format_number(tkc_cost_amount.price.ceil(2)))
                else
                  tkc_cost.week.project.euro_format(tkc_cost.week.project.format_number(tkc_cost_amount.specification_code.price.ceil(2)))
                end
        price
      end
      t.column :total, lambda { |tkc_cost_amount|
                         tkc_cost.week.project.euro_format(tkc_cost.week.project.format_number(tkc_cost_amount.total_amount&.ceil(2)))
                       }, class: "total-column-tkc-cost table-font-code"
      t.column :action, sort: false do |tkc_cost_amount|
        button_tag "Verwijderen", type: "button", class: "btn btn-danger custom-tkc-const-amount-delete-button", data: { tkc_cost_amount_id: tkc_cost_amount.id }
      end
    end
    render partial: "trestle/tkc_costs/add_row_button"
  end

  controller do
    before_action :validate_tkc_amounts, only: [:update]

    def create
      tkc_cost = TkcCost.new(tkc_cost_params)
      project = tkc_cost.project
      if tkc_cost.save
        @tkc_cost_id = tkc_cost.id
        validate_tkc_amounts
        redirect_to "/admin/projects/#{project.id}?tab=Tkc#!tab-Tkc"
      else
        # super
        render json: { errors: tkc_cost.errors.full_messages }, status: :unprocessable_entity
      end
    end

    def update
      tkc_cost = TkcCost.find(params[:id])
      tkc_cost.assign_attributes(tkc_cost_params)

      project = tkc_cost.project
      # tkc_cost.services ||= 0
      # tkc_cost.material ||= 0
      # tkc_cost.additional ||= 0
      # tkc_total = tkc_cost.services + tkc_cost.material + tkc_cost.additional
      # tkc_cost.tkc_total = tkc_total

      if tkc_cost.save
        redirect_to "/admin/projects/#{project.id}?tab=Tkc#!tab-Tkc"
      else
        super
      end
    end

    def destroy
      @tkc_cost = TkcCost.find(params[:id])
      project = @tkc_cost.project
      @tkc_cost.destroy
      redirect_to "/admin/projects/#{project.id}?tab=Tkc#!tab-Tkc"
    end

    def validate_tkc_amounts
      id = params[:id] || @tkc_cost_id
      tkc_cost = TkcCost.find(id)
      project = tkc_cost.project
      tkc_cost_amount_codes = params[:tkc_cost_amount_codes]
      unique_costs = params[:unique_costs]
      tkc_cost_amount_codes&.each do |amount_id, code_params|
        code_id = code_params[:specification_code_id]
        amount = code_params[:amount].to_i
        next unless amount_id.present? && code_id.present?

        specification_code = SpecificationCode.find(code_id)
        tkc_cost_amount_created = tkc_cost.tkc_cost_amounts.find_by(id: amount_id)
        if tkc_cost_amount_created.present?
          tkc_cost_amount_created.update(amount: amount, total_amount: BigDecimal(amount.to_s) * BigDecimal(tkc_cost_amount_created.price.to_s)) if amount
        else
          TkcCostAmount.create(
            tkc_cost: tkc_cost,
            project: project,
            specification_code: specification_code,
            price: specification_code.price,
            amount: amount,
            total_amount: BigDecimal(amount.to_s) * BigDecimal(specification_code.price.to_s)
          )
        end
      end

      unique_costs&.each do |cost_id, cost_params|
        description = cost_params[:description]
        amount = cost_params[:amount].to_f
        price = cost_params[:price].to_f
        next unless cost_id.present?

        unique_cost_created = tkc_cost.unique_costs.find_by(id: cost_id)
        if unique_cost_created.present?
          unique_cost_created.update(amount: amount, price: price, description: description, total: BigDecimal(amount.to_s) * BigDecimal(price.to_s)) if amount && price
        else
          UniqueCost.create(
            tkc_cost: tkc_cost,
            price: price,
            amount: amount,
            description: description,
            total: BigDecimal(amount.to_s) * BigDecimal(price.to_s)
          )
        end
      end
    end

    def specification_code
      code = SpecificationCode.find(params[:specification_code_id])
      render json: { specification_code: code }, status: :ok
    end

    private

    def tkc_cost_params
      params.require(:tkc_cost).permit(:project_id, :week_id, :tkc_description)
    end
  end
end
