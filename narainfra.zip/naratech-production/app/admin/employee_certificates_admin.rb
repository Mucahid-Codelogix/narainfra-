Trestle.resource(:employee_certificates) do
  table do
    column :employee, ->(certificate) { certificate.employee.first_name }
    column :certificate_type
    column :certificate_number
    actions
  end
  routes do
    post :delete_file, on: :member
    post :download_file, on: :member
  end

  form do |employee_certificate|
    flash.now[:error] = employee_certificate.errors.full_messages.join(', ') if employee_certificate.errors.any?
    if params[:employee]
      employee_id = params[:employee].to_i
    elsif employee_certificate&.employee_id
      employee_id = employee_certificate.employee_id.to_i
    end

    employee = Employee.find(employee_id)
    @active_tab = params[:tab] ? params[:tab].to_sym : :employee_certificate_details
    tab :employee_certificate_details, label: t("tabs.employee_certificate_tabs.employee_certificate") do
      next unless @active_tab == :employee_certificate_details

      hidden_field :employee_id, value: employee_id, id: "employe-certificate-employee-field"
      row do
        col(sm: 4) { text_field :employee, value: employee.first_name, disabled: true }
        col(sm: 4) { select :certificate_type_id, (CertificateType.all.map { |type| [type.name, type.id] }), label: 'Soort certificaat', prompt: 'Selecteer soort certificaat' }
        col(sm: 4) { text_field :certificate_number }
      end
      row do
        col(sm: 4) do
          render partial: "trestle/projects/custom_date_field", locals: {
            label: t("activerecord.attributes.employee_certificate.date_achieved"),
            field_name: "employee_certificate[date_achieved]",
            field_id: "employee_certificate_date_achieved",
            formatted_value: employee_certificate.date_achieved&.strftime('%d/%m/%Y')
          }
        end
        col(sm: 4) do
          render partial: "trestle/projects/custom_date_field", locals: {
            label: t("activerecord.attributes.employee_certificate.end_date"),
            field_name: "employee_certificate[end_date]",
            field_id: "employee_certificate_end_date",
            formatted_value: employee_certificate.end_date&.strftime('%d/%m/%Y')
          }
        end
        col(sm: 4) { file_field :attachment }
      end
    end
  end

  controller do
    def create
      employee_certificate = EmployeeCertificate.new(employee_certificate_params)
      employee = employee_certificate.employee

      if employee_certificate.save
        redirect_to "/admin/employees/#{employee.id}?tab=Certificate#!tab-Certificate"
      else
        super
      end
    end

    def destroy
      @employee_certificate = EmployeeCertificate.find(params[:id])
      employee = @employee_certificate.employee
      @employee_certificate.destroy
      redirect_to "/admin/employees/#{employee.id}?tab=Certificate#!tab-Certificate"
    end

    def delete_file
      certificate = EmployeeCertificate.find(params[:id])
      attachment = certificate.attachments.find_by_id(params[:file_id])
      if attachment
        attachment.purge
        flash[:message] = "Bijlage is succesvol verwijderd"
      else
        flash[:alert] = "Error"
      end
    end

    def download_file
      employee_certificate = EmployeeCertificate.find(params[:id])
      attachment = employee_certificate.attachment
      blob = attachment.blob
      send_data(
        blob.download, 
        filename: attachment.filename.to_s,
        type: attachment.content_type,
        disposition: 'attachment'
      )
    end

    private

    def employee_certificate_params
      params.require(:employee_certificate).permit(:employee_id, :certificate_type_id, :certificate_number, :date_achieved, :end_date, :attachment)
    end
  end
end
