Trestle.resource(:project_disciplines) do
  form do |project_discipline|
  end
end