Trestle.resource(:employees) do
  menu do
    item :employees, icon: "fa fa-star", label: t("menu.employees"), priority: 4
  end

  authorize do
    actions :new, :show, :create, :index, :edit, :update, :destroy, :get_clients, :create_certificate, :pdf_download do
      current_user.role == "admin"
    end
  end

  routes do
    get :get_clients, on: :collection
    post :create_certificate, on: :member
    post :pdf_download, on: :member
  end

  table do
    column :first_name
    column :last_name
    column :role, ->(employee) { employee.role&.role_title }
    column :contractor, ->(employee) { employee.contractor&.contractor_name }
    actions do |_toolbar, instance, admin|
      "<div>
        <a href='#{admin.path(:pdf_download, id: instance.id, preview: true)}' data-method='post' class='btn btn-primary' target='_blank' rel='nofollow'>
          <i class='fas fa-eye mr-1'></i>
        </a>
        <a href='#{admin.path(:pdf_download, id: instance.id)}' data-method='post' class='btn btn-primary' rel='nofollow'>
          Exporteer PDF
        </a>
      </div>".html_safe
    end
    # actions do |_toolbar, instance, admin|
    #   link_to "Exporteer PDF", admin.path(:pdf_download, id: instance.id), method: :post, class: "btn btn-primary"
    # end
    actions
  end

  search do |query|
    if query.present?
      Employee.joins(:role, :contractor)
              .where("LOWER(employees.first_name) LIKE :query OR LOWER(employees.last_name) LIKE :query OR LOWER(roles.role_title) LIKE :query OR LOWER(contractors.contractor_name) LIKE :query", query: "%#{query.downcase}%")
    else
      Employee.all
    end
  end

  form do |employee|
    @active_tab = params[:tab] ? params[:tab].to_sym : :employee_details
    tab :employee_details, label: t("tabs.employee_tabs.employee_details") do
      next unless @active_tab == :employee_details
      row do
        col(sm: 4) { text_field :first_name }
        col(sm: 4) { text_field :last_name }
        col(sm: 4) { select :gender, Employee.genders.keys.map { |type| [t("activerecord.attributes.employee.gender_#{type}"), type] }, label: t("activerecord.attributes.employee.gender") }
      end
      row do
        # col(sm: 4) { select :marital_status, Employee.marital_statuses.keys.map { |type| [t("activerecord.attributes.employee.marital_status_#{type}"), type] }, label: t("activerecord.attributes.employee.marital_status") }
        col(sm: 4) do
          render partial: "trestle/projects/custom_date_field", locals: {
            label: t("activerecord.attributes.employee.date_of_birth"),
            field_name: "employee[date_of_birth]",
            field_id: "employee_date_of_birth",
            formatted_value: employee.date_of_birth&.strftime('%d/%m/%Y')
          }
        end
        col(sm: 4) { text_field :place_of_birth }
        col(sm: 4) { text_field :social_number }
      end
      row do
        col(sm: 4) { text_field :bank_account_number }
        col(sm: 4) { select :role_id, Role.all.map { |role| [role.role_title, role.id] }, label: 'Functie', prompt: 'Selecteer Functie' }
        col(sm: 4) { select :contractor_id, Contractor.all.map { |contractor| [contractor.contractor_name, contractor.id] }, label: 'Bedrijf', prompt: 'Selecteer Bedrijf' }
      end
      row do
        col(sm: 4) { number_field :rate, step: '0.01', min: 0 }
        col(sm: 4) { email_field :email }
        col(sm: 4) do
          telephone_field :phone, pattern: '(\+31\d{3,11}|0\d{5,13})', oninvalid: "this.setCustomValidity('#{t('validations.valid_phone_format')}')", oninput: "this.setCustomValidity('')"
        end
      end
      check_box :active
    end
    unless employee.new_record?
      tab :Clients, label: t("tabs.employee_tabs.clients") do
        table employee.employees_clients.order(id: :asc), admin: EmployeesClientsAdmin, class: "employees-clients-table", id: "employees-clients-table" do |t|
          t.column :client, sort: false do |employee_client|
            client = employee_client.client
            client_name = client.client_name
            client_id = client.id
            selected = client.id
            disabled = employee.clients.include?(client) ? { disabled: true } : {}
            select_tag "employee_client_name[#{employee_client.id}][client]", options_for_select([[client_name, client_id]], selected: selected), disabled.merge(class: "employee-client-name-field form-control")
          end
          t.column :employee_number, sort: false do |employee_client|
            number_field_tag "employee_client_employee_number[#{employee_client.id}][employee_number]", employee_client.employee_number, id: "employee-number-field-#{employee_client.id}", class: "employee-number-field form-control"
          end
          actions
        end
        render partial: "trestle/employees/add_client_button", locals: { employee: employee }
      end
      tab :Certificate, label: t("tabs.employee_tabs.Certificate") do
        render partial: "trestle/employees/add_certificate_button", locals: { employee: employee }
        table EmployeeCertificate.where(employee_id: employee.id).order(id: :asc), admin: EmployeeCertificatesAdmin do |t|
          t.column :employee, ->(certificate) { certificate.employee.first_name }
          t.column :certificate_type
          t.column :certificate_number
          t.column :date_achieved, ->(certificate) { certificate&.date_achieved.strftime('%d/%m/%Y') }
          t.column :end_date, ->(certificate) { certificate&.end_date.strftime('%d/%m/%Y') }
          actions do |toolbar, instance, admin|
            link_to "Download", admin.path(:download_file, id: instance.id), method: :post, class: "btn btn-primary" if instance.attachment.present?
          end
          actions
        end
      end
    end
  end

  controller do
    before_action :validate_clients, only: [:update]

    def create_certificate
      employee = Employee.find(params[:id])

      redirect_to new_employee_certificates_admin_path(employee: employee)
    end

    def validate_clients
      employee = Employee.find(params[:id])
      client_names = params[:employee_client_name]
      employee_numbers = params[:employee_client_employee_number]
      new_clients = []

      client_names.each do |id, client_params|
        employee_client = EmployeesClient.find_by(employee_id: employee.id, client_id: id)
        unless employee_client
          new_clients << {
            id: id,
            client_id: client_params[:client]
          }
        end
      end if client_names

      employee_numbers.each do |id, employee_number_params|
        next unless employee_number_params[:employee_number]
        new_client = new_clients.find { |c| c[:id] == id }
        employee_client = EmployeesClient.find_by(id: id)
        if new_client
          new_client[:employee_number] = employee_number_params[:employee_number]
        elsif employee_client
          existing_employee_client = EmployeesClient.find_by(employee_number: employee_number_params[:employee_number])
          if existing_employee_client && existing_employee_client != employee_client
            flash[:error] = t('activerecord.errors.models.employees_client.attributes.employee_number.blank')
            flash.keep[:error]
            respond_to do |format|
              format.js { render js: "location.reload();" }
            end
            return
          else
            employee_client.update(employee_number: employee_number_params[:employee_number])
          end
        end
      end if employee_numbers

      new_clients.each do |new_client|
        employee_number = new_client[:employee_number]
        if new_client[:client_id]
          employee_client = EmployeesClient.new(
            employee_id: employee.id,
            client_id: new_client[:client_id],
            employee_number: employee_number
          )
          unless employee_client.save
            flash[:error] = t('activerecord.errors.models.employees_client.attributes.employee_number.blank')
            flash.keep[:error]
            respond_to do |format|
              format.js { render js: "location.reload();" }
            end
          end
        end
      end if new_clients
    end

    def get_clients
      employee_id = params[:employee_id]
      employee = Employee.find_by(id: employee_id)

      if employee
        unassociated_clients = Client.where.not(id: employee.clients.pluck(:id))
        render json: { clients: unassociated_clients }, status: :ok
      else
        render json: { error: 'Employee not found' }, status: :not_found
      end
    end

    def pdf_download
      employee = Employee.find(params[:id])
      pdf_filename = "#{employee.first_name}.pdf"
      template_path = "#{Rails.root}/app/views/trestle/employees/employee_pdf.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)

      if params[:preview].present?
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'inline')
      else
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'attachment')
      end
    end
  end
end
