Trestle.resource(:finances) do

  collection do
    Finance.order(id: :asc)
  end

  table do
    column :vat_number
    column :kvk_number
    column :c_account_percentage
    column :g_account_percentage
    column :vat
    column :client do |c|
      c.client.client_name
    end
    actions
  end

  form do |finance|
    flash.now[:error] = finance.errors.full_messages.join(', ') if finance.errors.any?
    if params[:client]
      client_id = params[:client].to_i
      client = Client.find(client_id)
    elsif finance&.client_id
      client_id = finance.client_id.to_i
      client = Client.find(client_id)
    end

    hidden_field :client_id, value: client.id

    row do
      col(sm: 4) { text_field :vat_number }
      col(sm: 4) { number_field :kvk_number, min: 0 }
      col(sm: 4) { number_field :vat, min: 0 }
    end

    row do
      col(sm: 4) { number_field :c_account_percentage, min: 0, step: '0.01' }
      col(sm: 4) { number_field :g_account_percentage, min: 0, disabled: true }
      col(sm: 4) { number_field :payment_term_value, min: 0 }
      hidden_field :g_account_percentage, id: "g_account_percentage_hidden"
    end
    row do
      col(sm: 12) do
        "<div><strong>BTW verlegd</strong> <i class='fas fa-question-circle' style='color:blue;'></i></div>".html_safe
      end
    end
    row do
      col(sm: 4) { check_box :vat_reversed, label: "Ja" }
    end
  end

  controller do
    def create
      finance = Finance.new(finance_params)
      client = finance.client

      if finance.save
        redirect_to "/admin/clients/#{client.id}?tab=Finance#!tab-Finance"
      else
        super
      end
    end

    def update
      finance = Finance.find(params[:id])
      finance.assign_attributes(finance_params)
      client = finance.client

      if finance.save
        redirect_to "/admin/clients/#{client.id}?tab=Finance#!tab-Finance"
      else
        super
      end
    end

    def destroy
      @finance = Finance.find(params[:id])
      client = @finance.client
      invoices = client.invoices
      debit_invoices = client.debit_invoices
      invoices&.each do |invoice|
        inovice_date = invoice.invoice_date
        invoice.update(expiration_date: inovice_date)
      end

      debit_invoices&.each do |invoice|
        inovice_date = invoice.invoice_date
        invoice.update(expiration_date: inovice_date)
      end
      @finance.destroy
      redirect_to "/admin/clients/#{client.id}?tab=Finance#!tab-Finance"
    end

    private

    def finance_params
      params.require(:finance).permit(:client_id, :vat_number, :kvk_number, :c_account_percentage, :g_account_percentage, :vat, :vat_reversed, :payment_term_value)
    end
  end
end
