Trestle.resource(:disciplines) do
  table do
    column :name
  end

  routes do
    get :specification_codes, on: :member
    post :import_specification_codes, on: :member
    post :add_flat_rate, on: :member
    post :create_specification_code, on: :member
    post :export_specification_codes, on: :member
    post :delete_multiple_specification_codes, on: :member
  end

  form do |discipline|
    @active_tab = params[:tab] ? params[:tab].to_sym : :discipline_details
    flash.now[:error] = discipline.errors.full_messages.join(', ') if discipline.errors.any?
    if params[:client]
      client_id = params[:client].to_i
    elsif discipline&.client_id
      client_id = discipline.client_id.to_i
    end
    tab :discipline_details, label: t("tabs.discipline_tabs.discipline_details") do
      next unless @active_tab == :discipline_details

      hidden_field :client_id, value: client_id
      text_field :name
    end
    unless discipline.new_record?
      tab :SpecificationCode, label: t("tabs.discipline_tabs.specification_code") do
        render partial: "trestle/disciplanes/action_buttons", locals: { client: discipline.client, discipline: discipline }
        render partial: "trestle/disciplanes/dialog_box", locals: { discipline: discipline }
        render "specification_codes", specification_codes: discipline.specification_codes.order(id: :asc).kaminari_page(1)
      end
    end
    render partial: "admin/shared/loader"
  end

  controller do
    def specification_codes
      load_instance
      render partial: "specification_codes", locals: { specification_codes: instance.specification_codes.order(id: :asc).kaminari_page(params[:page]) }
    end

    def import_specification_codes
      discipline_id = params[:id]
      discipline = Discipline.find(discipline_id.to_i)
      client = discipline.client
      excel_file = params[:excel_file]
      workbook = Roo::Spreadsheet.open(excel_file.path)
      sheet = workbook.sheet('Liander AD')
      new_specification_codes = []

      sheet.each_row_streaming(offset: 2) do |row|
        specification_code = row[0]&.value
        specification_code = nil if specification_code == 0.0
        measurement = row[1]&.value || '-'
        specification_description = row[2]&.value || '-'
        price = row[3]&.value || 0
        price = price.to_f

        next unless specification_code.present?

        existing_specification_code = SpecificationCode.find_by(specification_code: specification_code, client_id: client.id, discipline_id: discipline.id)
        next if existing_specification_code

        new_specification_codes << {
          specification_code: specification_code,
          description: specification_description,
          measurement: measurement,
          price: price.ceil(2),
          client: client,
          discipline: discipline
        }
      end

      SpecificationCode.create(new_specification_codes) unless new_specification_codes.empty?

      respond_to do |format|
        format.js { render js: "location.reload();" }
      end
    end

    def update_specification_codes(discipline_id, new_flat_rate, client_id)
      tkc_costs = TkcCost.all
      specification_codes = SpecificationCode.where(client_id: client_id, discipline_id: discipline_id)
      specification_codes&.each do |specification_code|
        price = (specification_code.price.to_f * new_flat_rate).ceil(2)
        specification_code.price = price

        associated_purchase_orders = PurchaseOrder.where(specification_code_id: specification_code.id)
        associated_purchase_orders&.each do |existing_purchase_order|
          existing_purchase_order.update(price: price) if existing_purchase_order.amount.nil? || existing_purchase_order.amount == 0.0
        end
        tkc_costs&.each do |tkc_cost|
          tkc_cost_amount = TkcCostAmount.find_by(specification_code_id: specification_code.id, tkc_cost_id: tkc_cost.id)
          tkc_cost_amount.update(price: price) if tkc_cost_amount.present? && (tkc_cost_amount.amount.nil? || tkc_cost_amount.amount == 0.0)
        end
        specification_code.save
      end
    end

    def add_flat_rate
      discipline_id = params[:discipline_id]
      discipline = Discipline.find(discipline_id.to_i)
      flat_rate = params[:flat_rate].to_f
      client =  discipline.client
      if flat_rate.present? && flat_rate > 0 && client.specification_codes.present?
        discipline.update(flat_rate: flat_rate)
        update_specification_codes(discipline_id, flat_rate, client.id)
        render json: { success: "flat rate updated" }
      else
        render json: { error: "flat rate not updated" }
      end
    end

    def create_specification_code
      discipline = Discipline.find(params[:id])

      redirect_to new_specification_codes_admin_path(discipline: discipline)
    end

    def create
      discipline = Discipline.new(discipline_params)
      client = discipline.client

      if discipline.save
        redirect_to "/admin/clients/#{client.id}?tab=disciplines#!tab-disciplines"
      else
        super
      end
    end

    def update
      discipline = Discipline.find(params[:id])
      discipline.assign_attributes(discipline_params)
      client = discipline.client

      if discipline.save
        redirect_to "/admin/clients/#{client.id}?tab=disciplines#!tab-disciplines"
      else
        super
      end
    end

    def destroy
      @discipline = Discipline.find(params[:id])
      client = @discipline.client
      @discipline.destroy
      redirect_to "/admin/clients/#{client.id}?tab=disciplines#!tab-disciplines"
    end

    def export_specification_codes
      puts "export_specification_codes: #{params}"
      discipline_id = params[:id]
      @specification_codes = SpecificationCode.where(discipline_id: discipline_id).order(id: :asc)

      respond_to do |format|
        format.html
        format.xlsx
      end
      render xlsx: 'export_specification_codes'
    end

    def delete_multiple_specification_codes
      discipline = Discipline.find(params[:id])
      select_all_codes = params[:select_all_codes]
      if select_all_codes == "true"
        discipline.specification_codes.destroy_all
      else
        specification_codes = params[:specification_codes]
        specification_codes&.each do |specification_code_id|
          specification_code = SpecificationCode.find(specification_code_id)
          specification_code.destroy
        end
      end
      render json: { message: 'Specification codes deleted successfully' }, status: :ok
    end

    private

    def discipline_params
      params.require(:discipline).permit(:client_id, :name)
    end
  end
end
