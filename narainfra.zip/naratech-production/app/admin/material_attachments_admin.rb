Trestle.resource(:material_attachments) do
  routes do
    post :delete_file, on: :member
    post :download_file, on: :member
  end

  controller do
    def delete_file
      material_attachment = MaterialAttachment.find(params[:id])
      attachment = material_attachment.attachment
      if material_attachment
        attachment.purge
        material_attachment.destroy
        flash[:message] = "Bijlage is succesvol verwijderd"
      else
        flash[:alert] = "Image not found."
      end
    end

    def download_file
      material_attachment = MaterialAttachment.find(params[:id])
      attachment = material_attachment.attachment
      blob = attachment.blob
      send_data(
        blob.download, 
        filename: attachment.filename.to_s,
        type: attachment.content_type,
        disposition: 'attachment'
      )
    end
  end
end
