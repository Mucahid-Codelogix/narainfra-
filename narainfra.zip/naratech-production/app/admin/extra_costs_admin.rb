Trestle.resource(:extra_costs) do
  table do
    column :week, ->(extra_cost) { extra_cost.week.week_number }
    column :item_type, ->(extra_cost) { t("activerecord.attributes.extra_cost.item_type_#{extra_cost.item_type}") }
    column :cost
  end

  form do |extra_cost|
    flash.now[:error] = extra_cost.errors.full_messages.join(', ') if extra_cost.errors.any?

    if params[:project]
      project_id = params[:project].to_i
    elsif extra_cost&.project_id
      project_id = extra_cost.project_id.to_i
      @week = extra_cost.week
    end
    project = Project.find(project_id)

    hidden_field :project_id, value: project_id
    row do
      col(sm: 4) { text_field :project_number, label: t("activerecord.attributes.extra_cost.project"), value: project.projectnumber, disabled: true }
      col(sm: 4) { select :week_id, Week.where(project_id: project_id).order(year: :asc, week_number: :asc).map { |w| [w.week_number, w.id] }, label: t("activerecord.attributes.extra_cost.week"), prompt: t("prompt.extra_cost.select_week") }
      col(sm: 4) { select :item_type, ExtraCost.item_types.keys.map { |type| [t("activerecord.attributes.extra_cost.item_type_#{type}"), type] }, label: t("activerecord.attributes.extra_cost.item_type"), prompt: "Select an item type" }
    end
    row do
      col(sm: 4) { number_field :cost, step: '0.01' }
      col(sm: 4) { text_field :description }
    end
  end

  controller do
    def create
      extra_cost = ExtraCost.new(extra_cost_params)
      project = extra_cost.project

      if extra_cost.save
        redirect_to "/admin/projects/#{project.id}?tab=Extra_cost#!tab-Extra_cost"
      else
        super
      end
    end

    def update
      extra_cost = ExtraCost.find(params[:id])
      extra_cost.assign_attributes(extra_cost_params)
      project = extra_cost.project

      if extra_cost.save
        redirect_to "/admin/projects/#{project.id}?tab=Extra_cost#!tab-Extra_cost"
      else
        super
      end
    end

    def destroy
      @extra_cost = ExtraCost.find(params[:id])
      project = @extra_cost.project
      @extra_cost.destroy
      redirect_to "/admin/projects/#{project.id}?tab=Extra_cost#!tab-Extra_cost"
    end

    private

    def extra_cost_params
      params.require(:extra_cost).permit(:project_id, :week_id, :cost, :item_type, :description)
    end
  end
end
