Trestle.resource(:purchase_orders) do
  remove_action :show
end
