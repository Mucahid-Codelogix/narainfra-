Trestle.resource(:materials) do
  # menu do
  #   item :materials, icon: "fa fa-star", label: t("menu.material"), priority: 7
  # end

  menu do
    group :materialen, priority: 2 do
      item :Voertuigen, icon: "fa fa-car"
    end
  end

  scopes do
    scope :active, default: true, label: "Actief" do |materials|
      materials.where(in_use: "yes")
    end
    scope :inactive, label: "Inactief" do |materials|
      materials.where(in_use: "no")
    end
  end

  search do |query|
    if query
      Material.where("CAST(ref_number AS text) LIKE ? OR description LIKE ? OR number_plate LIKE ? OR LOWER(driver) LIKE ?",
                       "%#{query}%", "%#{query}%", "%#{query}%", "%#{query.downcase}%")
    else
      Material.all
    end
  end

  table do
    column :ref_number
    column :material_type, ->(material) { t("activerecord.attributes.material.material_type_#{material.material_type}") }
    column :description
    column :brand
    column :type_name
    column :number_plate do |material|
      if material.number_plate.present?
        "<div style='background-color: #f3bd00; letter-spacing: 4px; padding: 20px 20px; border: 1px solid black; position: relative; text-align: center; border-radius: 2px;'>
        <span style='width: 20px; height: 61px; position: absolute; background-color: blue; top: 0px; left: 0;'></span>
          #{material.number_plate.upcase}
        </div>".html_safe
      end
    end
    column :driver
    column :construction_date do |material|
      material.construction_date&.strftime("%d/%m/%Y")
    end
    actions
  end
  routes do
    post :create_notes, on: :member
    post :update_notes, on: :member
    post :delete_note, on: :collection
    post :create_lease_contract, on: :member
    post :create_insurance, on: :member
  end

  form do |material|
    @active_tab = params[:tab] ? params[:tab].to_sym : :material_details
    tab :material_details, label: t("tabs.material_tabs.material_details") do
      next unless @active_tab == :material_details
      row do
        col(sm: 4) { text_field :ref_number }
        col(sm: 4) { text_field :brand }
        col(sm: 4) { text_field :type_name }
      end
      row do
        col(sm: 4) { text_field :number_plate }
        col(sm: 4) do
          select :driver, Employee.all.map { |e| ["#{e.first_name} #{e.last_name}", "#{e.first_name} #{e.last_name}"] }, include_blank: 'Selecteer Bestuurder'
        end
        col(sm: 4) do
          construction_date = material.construction_date.is_a?(String) ? Date.current : material.construction_date
          render partial: "admin/shared/date_field", locals: {
            label: t("activerecord.attributes.material.construction_date"),
            field_name: "material[construction_date]",
            field_id: "material_construction_date",
            formatted_value: construction_date&.strftime('%d/%m/%Y')
          }
        end
      end
      row do
        col(sm: 4) { text_field :description }
        col(sm: 4) { select(:in_use, Material.in_uses.keys.map { |type| [t("activerecord.attributes.material.in_use_#{type}"), type] }) }
      end
      check_box :active
    end

    unless material.new_record?
      tab :lease_contract, label: t("tabs.material_tabs.lease_contract") do
        render partial: "trestle/materials/material_custom_buttons", locals: { material: material, method_name: "create_lease_contract", source: "materials", label: t('buttons.material.add_lease_contract') }
        lease_contracts = LeaseContract.where(material_id: material.id)
        table lease_contracts, admin: LeaseContractsAdmin, id: "material-lease-contract-table" do |t|
          t.column :lease_company
          t.column :contract_number
          t.column :lease_amount_ex_vat
        end
      end

      tab :insurance, label: t("tabs.material_tabs.insurance") do
        render partial: "trestle/materials/material_custom_buttons", locals: { material: material, method_name: "create_insurance", source: "materials", label: t('buttons.material.add_insurance') }
        insurance = Insurance.where(material_id: material.id)
        table insurance, admin: InsurancesAdmin, id: "material-lease-contract-table" do |t|
          t.column :insurer
          t.column :policy_number
          t.column :premium_period
          t.column :premium_per_period
        end
      end

      tab :notes, label: t("tabs.material_tabs.notes") do
        render partial: 'admin/shared/notes', locals: { material: material, current_user: current_user, source: "materials" }
      end

      tab :attachments, label: t("tabs.material_tabs.attachments") do
        render partial: "trestle/materials/add_attachment_row", locals: { label: t('buttons.material.add_new_attachment') }
        material_attachments = MaterialAttachment.where(material_id: material.id)
        table material_attachments, admin: MaterialAttachmentsAdmin, id: "material-attachment-table" do |t|
          t.column :title
          t.column :attachment, header: false do |attachment|
            if attachment.attachment.attached?
              url = Rails.application.routes.url_helpers.rails_blob_path(attachment.attachment, only_path: true)
              "<div>
                <a class='btn btn-primary' rel='nofollow' target='_blank' href='#{url}'><i class='fas fa-eye mr-1'></i></a>
                <a class='btn btn-primary' rel='nofollow' data-method='post' href=#{download_file_material_attachments_admin_path(attachment.id)}>Download</a>

                <span class='btn btn-danger delete-file' style='margin-left: 20px;' data-file-id='#{attachment.attachment.blob.id}' data-id='#{attachment.attachment.record.id}' data-source='material_attachments'>Delete</span>
               </div>".html_safe
            end
          end
        end

        fields_for :material_attachments, material.material_attachments.build, child_index: Time.now.to_i do |attachment_fields|
          render partial: "trestle/materials/attachment_fields", locals: { attachment_fields: attachment_fields }
        end
      end
    end
  end

  controller do
    before_action :create_material_attachments, only: [:update]
    def update
      @material = Material.find(params[:id])
      if @material.update(material_params)
        flash[:message] = "Materiaal is succesvol bijgewerkt"
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      else
        flash[:error] = @material.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end


    def create_lease_contract
      material = Material.find(params[:id])

      redirect_to new_lease_contracts_admin_path(material: material)
    end

    def create_insurance
      material = Material.find(params[:id])

      redirect_to new_insurances_admin_path(material: material)
    end

    def create_notes
      comment = params[:note][:comment]
      Note.create(user_id: current_user.id, material_id: params[:id], comment: comment)
      redirect_to "/admin/materials/#{params[:id]}?tab=notes#!tab-notes"
    end

    def update_notes
      note = Note.find(params[:note][:note_id].to_i)
      note.update(comment: params[:note][:comment])
      redirect_to "/admin/materials/#{params[:id]}?tab=notes#!tab-notes"
    end

    def delete_note
      note_id = params[:note_id]&.to_i
      if note_id.present?
        note = Note.find(note_id)
        note.destroy
      end
    end

    protected

    def create_material_attachments
      @material = Material.find(params[:id])
      material_attachments_attributes = params[:material]
      material_attachments_attributes = material_attachments_attributes[:material_attachments_attributes]
      material_attachments_attributes&.each do |_key, attachment_params|
        MaterialAttachment.create(
          title: attachment_params[:title],
          attachment: attachment_params[:attachment][0],
          material: @material
        ) if attachment_params[:title].present? && attachment_params[:attachment][0].present?
      end
    end

    private

    def material_params
      params.require(:material).permit(:ref_number, :material_type, :type_name, :brand, :number_plate, :driver, :year, :description, :in_use, :active)
    end
  end
end
