require 'roo'
Trestle.resource(:contractors) do
  routes do
    # get :specification_codes, on: :member
    post :create_contact_person, on: :member
    # post :create_discipline, on: :member
    post :create_finance, on: :member
    get :contact_persons_data, on: :member
  end

  menu do
    group :Relatie, priority: 1 do
      item :contractors, icon: "fas fa-user-tie", label: t("menu.contractors"), priority: 2
    end
  end

  search do |query|
    if query
      Contractor.where("CAST(contractor_id AS text) LIKE ? OR contractor_name LIKE ? OR email LIKE ? OR phone LIKE ? OR address LIKE ? OR postal_code LIKE ?",
                       "%#{query}%", "%#{query}%", "%#{query}%", "%#{query}%", "%#{query}%", "%#{query}%")
    else
      Contractor.order(contractor_name: :asc)
    end
  end

  table do
    column :contractor_id, link: true
    column :contractor_name
    column :email
    column :phone
    column :address
    column :postal_code
    actions
  end

  form do |contractor|
    @active_tab = params[:tab] ? params[:tab].to_sym : :contractor_details
    tab :contractor_details, label: t("tabs.client_tabs.contractor_details") do
      next unless @active_tab == :contractor_details

      row do
        col(sm: 4) { number_field :contractor_id, min: 0, value: contractor.contractor_id || next_available_contractor_id }
        col(sm: 4) { text_field :contractor_name }
        col(sm: 4) { email_field :email }
      end
      row do
        col(sm: 4) { text_field :contactperson }
        col(sm: 4) { text_field :postal_code }
        col(sm: 4) { text_field :city }
      end
      row do
        col(sm: 4) { text_field :address }
        col(sm: 4) do
          telephone_field :phone, pattern: '(\+31\d{3,11}|0\d{5,13})', oninvalid: "this.setCustomValidity('#{t('validations.valid_phone_format')}')", oninput: "this.setCustomValidity('')"
        end
      end
      check_box :active
      render partial: "admin/shared/warning", locals: { text: "Deze opdrachtnemer bestaat al" }
      render partial: "trestle/clients/hidden_field_for_warning_param"
    end

    unless contractor.new_record?
      tab :Contact_persons, label: t("tabs.client_tabs.contact_persons") do
        render partial: "admin/contractor_contact_persons/contractor_contact_persons_data"
      end
      tab :Finance, label: t("tabs.client_tabs.bank_details") do
        render partial: "admin/shared/add_finance_button", locals: { id: contractor.id, source: "contractors" } if contractor.contractor_finance.blank?
        finances = ContractorFinance.where(contractor_id: contractor.id)
        table finances, admin: ContractorFinancesAdmin do |t|
          t.column :vat_number
          t.column :kvk_number
          t.column :vat
          t.column :c_account_percentage
          t.column :g_account_percentage
          actions
        end
      end
    end
  end

  controller do

    def create
      duplicate_name_allow_contractor = params[:client_warning].map { |cw| cw.split(',') }.flatten

      existing_contractor = Contractor.find_by(contractor_name: contractor_params[:contractor_name])
      duplicate_name_allow_contractor.include?(existing_contractor&.contractor_name)

      if duplicate_name_allow_contractor.include?(existing_contractor&.contractor_name)
        contractor = Contractor.new(contractor_params)
        if contractor.valid?
          super
        else
          render json: { errors: contractor.errors.full_messages }, status: :unprocessable_entity
        end
      elsif existing_contractor
        render json: { errors: "contractor already exist" }, status: :unprocessable_entity
      else
        contractor = Contractor.new(contractor_params)
        if contractor.valid?
          super
        else
          render json: { errors: contractor.errors.full_messages }, status: :unprocessable_entity
        end
      end
    end

    def create_contact_person
      contractor = Contractor.find(params[:id])

      redirect_to new_contractor_contact_persons_admin_path(contractor: contractor)
    end

    def create_finance
      contractor = Contractor.find(params[:id])

      redirect_to new_contractor_finances_admin_path(contractor: contractor)
    end

    def contact_persons_data
      contractor = Contractor.find(params[:id])
      contact_persons = ContractorContactPerson.where(contractor_id: contractor.id).order(id: :asc)
      employees = Employee.where(contractor_id: contractor.id).order(id: :asc)
      merged_data = contact_persons.map do |contact_person|
        {
          id: contact_person.id,
          name: contact_person.name,
          position: contact_person.position,
          email: contact_person.email,
          phone: contact_person.phone,
          type: 'Contact Person'
        }
      end
      merged_data += employees.map do |employee|
        {
          id: employee.id,
          name: "#{employee.first_name} #{employee.last_name}",
          position: employee.role.role_title,
          email: employee.email,
          phone: employee.phone,
          type: 'Employee'
        }
      end
      render json: { data: merged_data }
    end

    private

    def contractor_params
      params.require(:contractor).permit(
        :contractor_name,
        :address,
        :postal_code,
        :email,
        :phone,
        :contactperson,
        :city,
        :contractor_id,
        :active
      )
    end
  end

  helper do
    def next_available_contractor_id
      starting_id = 2001
      next_id = starting_id
      while Contractor.exists?(contractor_id: next_id)
        next_id += 1
      end
      next_id
    end
  end
end
