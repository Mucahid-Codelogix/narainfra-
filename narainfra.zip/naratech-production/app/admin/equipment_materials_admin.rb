Trestle.resource(:equipment_materials) do
  # menu do
  #   item :materials, icon: "fa fa-star", label: t("menu.material"), priority: 7
  # end

  menu do
    group :materialen, priority: 2 do
      item :Apparatuur, icon: "fa fa-gear"
    end
  end

  scopes do
    scope :all, default: true, label: t('scopes.equipment_materials.all')
    scope :devices, -> { EquipmentMaterial.where(category: 0) }, label: t('scopes.equipment_materials.devices')
    scope :machines, -> { EquipmentMaterial.where(category: 1) }, label: t('scopes.equipment_materials.machines')
  end

  table do
    column :ref_number
    column :description
    column :purchase_value
    column :purchase_date do |material|
      material.purchase_date&.strftime("%d/%m/%Y")
    end
    column :inspection_date do |material|
      material.inspection_date&.strftime("%d/%m/%Y")
    end
    column :construction_date do |material|
      material.construction_date&.strftime("%d/%m/%Y")
    end
    # column :construction_date
    actions
  end
  routes do
    post :create_notes, on: :member
    post :update_notes, on: :member
    post :delete_note, on: :collection
    post :create_lease_contract, on: :member
    post :create_insurance, on: :member
  end

  form do |equipment_material|
    @active_tab = params[:tab] ? params[:tab].to_sym : :equipment_material_details
    tab :equipment_material_details, label: t("tabs.equipment_material_tabs.equipment_material_details") do
      next unless @active_tab == :equipment_material_details
      row do
        col(sm: 4) { select(:category, EquipmentMaterial.categories.keys.map { |type| [t("activerecord.attributes.equipment_material.category_#{type}"), type] }) }
        col(sm: 4) { text_field :ref_number }
        col(sm: 4) { text_field :serial_number }
      end
      row do
        col(sm: 4) do
          construction_date = equipment_material.construction_date.is_a?(String) ? Date.current : equipment_material.construction_date
          render partial: "admin/shared/date_field", locals: {
            label: t("activerecord.attributes.equipment_material.construction_date"),
            field_name: "equipment_material[construction_date]",
            field_id: "equipment_material_construction_date",
            formatted_value: construction_date&.strftime('%d/%m/%Y')
          }
        end
        col(sm: 4) { text_field :brand }
        col(sm: 4) { text_field :type_name }
      end
      row do
        col(sm: 4) { text_field :description }
        col(sm: 4) { select(:in_use, EquipmentMaterial.in_uses.keys.map { |type| [t("activerecord.attributes.material.in_use_#{type}"), type] }) }
        col(sm: 4) { number_field :purchase_value, min: 0, step: '0.01' }
      end
      row do
        col(sm: 4) do
          render partial: "admin/shared/date_field", locals: {
            label: t("activerecord.attributes.equipment_material.purchase_date"),
            field_name: "equipment_material[purchase_date]",
            field_id: "equipment_material_purchase_date",
            formatted_value: equipment_material.purchase_date&.strftime('%d/%m/%Y')
          }
        end
        col(sm: 4) do
          render partial: "admin/shared/date_field", locals: {
            label: t("activerecord.attributes.equipment_material.inspection_date"),
            field_name: "equipment_material[inspection_date]",
            field_id: "equipment_material_inspection_date",
            formatted_value: equipment_material.inspection_date&.strftime('%d/%m/%Y')
          }
        end
      end
    end

    unless equipment_material.new_record?
      tab :lease_contract, label: t("tabs.material_tabs.lease_contract") do
        render partial: "trestle/materials/material_custom_buttons", locals: { material: equipment_material, method_name: "create_lease_contract", source: "equipment_materials", label: t('buttons.material.add_lease_contract') }
        lease_contracts = LeaseContract.where(equipment_material_id: equipment_material.id)
        table lease_contracts, admin: LeaseContractsAdmin, id: "material-lease-contract-table" do |t|
          t.column :lease_company
          t.column :contract_number
          t.column :lease_amount_ex_vat
        end
      end

      tab :insurance, label: t("tabs.material_tabs.insurance") do
        render partial: "trestle/materials/material_custom_buttons", locals: { material: equipment_material, method_name: "create_insurance", source: "equipment_materials", label: t('buttons.material.add_insurance') }
        insurance = Insurance.where(equipment_material_id: equipment_material.id)
        table insurance, admin: InsurancesAdmin, id: "material-lease-contract-table" do |t|
          t.column :insurer
          t.column :policy_number
          t.column :premium_period
          t.column :premium_per_period
        end
      end

      tab :notes, label: t("tabs.material_tabs.notes") do
        render partial: 'admin/shared/notes', locals: { material: equipment_material, current_user: current_user, source: "equipment_materials" }
      end

      tab :attachments, label: t("tabs.material_tabs.attachments") do
        render partial: "trestle/materials/add_attachment_row", locals: { label: t('buttons.material.add_new_attachment') }
        material_attachments = MaterialAttachment.where(equipment_material_id: equipment_material.id)
        table material_attachments, admin: MaterialAttachmentsAdmin, id: "material-attachment-table" do |t|
          t.column :title
          t.column :attachment, header: false do |attachment|
            if attachment.attachment.attached?
              url = Rails.application.routes.url_helpers.rails_blob_path(attachment.attachment, only_path: true)
              "<div>
                <a class='btn btn-primary' rel='nofollow' data-method='post' href=#{download_file_material_attachments_admin_path(attachment.id)}>Download</a>

                <span class='btn btn-danger delete-file' style='margin-left: 20px;' data-file-id='#{attachment.attachment.blob.id}' data-id='#{attachment.attachment.record.id}' data-source='material_attachments'>Delete</span>
               </div>".html_safe
            end
          end
        end

        fields_for :material_attachments, equipment_material.material_attachments.build, child_index: Time.now.to_i do |attachment_fields|
          render partial: "trestle/materials/attachment_fields", locals: { attachment_fields: attachment_fields }
        end
      end
    end
  end

  controller do
    before_action :create_material_attachments, only: [:update]
    def update
      @material = EquipmentMaterial.find(params[:id])
      if @material.update(material_params)
        flash[:message] = "Materiaal is succesvol bijgewerkt"
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      else
        super
      end
    end


    def create_lease_contract
      equipment_material = EquipmentMaterial.find(params[:id])
      redirect_to new_lease_contracts_admin_path(equipment_material: equipment_material)
    end

    def create_insurance
      equipment_material = EquipmentMaterial.find(params[:id])

      redirect_to new_insurances_admin_path(equipment_material: equipment_material)
    end

    def create_notes
      comment = params[:note][:comment]
      Note.create(user_id: current_user.id, equipment_material_id: params[:id], comment: comment)
      redirect_to "/admin/equipment_materials/#{params[:id]}?tab=notes#!tab-notes"
    end

    def update_notes
      note = Note.find(params[:note][:note_id].to_i)
      note.update(comment: params[:note][:comment])
      redirect_to "/admin/equipment_materials/#{params[:id]}?tab=notes#!tab-notes"
    end

    def delete_note
      note_id = params[:note_id]&.to_i
      if note_id.present?
        note = Note.find(note_id)
        note.destroy
      end
    end

    protected

    def create_material_attachments
      @material = EquipmentMaterial.find(params[:id])
      material_attachments_attributes = params.dig(:material, :material_attachments_attributes)
      material_attachments_attributes&.each do |_key, attachment_params|
        if attachment_params[:title].present? && attachment_params[:attachment]&.first.present?
          MaterialAttachment.create(
            title: attachment_params[:title],
            attachment: attachment_params[:attachment].first,
            equipment_material: @material
          )
        end
      end
    end

    private

    def material_params
      params.require(:equipment_material).permit(:ref_number, :type_name, :serial_number, :construction_date, :brand, :description, :purchase_value, :construction_date, :purchase_date, :inspection_date, :in_use, :category)
    end
  end
end
