Trestle.resource(:contractor_contact_persons) do
  table do
    column :name
    column :position
    column :email
    column :phone
  end

  form do |contact_person|
    flash.now[:error] = contact_person.errors.full_messages.join(', ') if contact_person.errors.any?

    if params[:contractor]
      contractor_id = params[:contractor].to_i
    elsif contact_person&.contractor_id
      contractor_id = contact_person.contractor_id.to_i
    end

    hidden_field :contractor_id, value: contractor_id
    row do
      col(sm: 4) { text_field :name }
      col(sm: 4) { text_field :position }
      col(sm: 4) { email_field :email }
    end
    row do
      col(sm: 4) { telephone_field :phone, pattern: '(\+31\d{3,11}|0\d{5,13})', oninvalid: "this.setCustomValidity('#{t('validations.valid_phone_format')}')", oninput: "this.setCustomValidity('')" }
    end
  end

  controller do
    def create
      contact_person = ContractorContactPerson.new(contact_person_params)
      contractor = contact_person.contractor

      if contact_person.save
        redirect_to "/admin/contractors/#{contractor.id}?tab=Contact_persons#!tab-Contact_persons"
      else
        flash[:error] = contact_person.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def update
      contact_person = ContractorContactPerson.find(params[:id])
      contact_person.assign_attributes(contact_person_params)
      contractor = contact_person.contractor

      if contact_person.save
        redirect_to "/admin/contractors/#{contractor.id}?tab=Contact_persons#!tab-Contact_persons"
      else
        flash[:error] = contact_person.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def destroy
      @contact_person = ContractorContactPerson.find(params[:id])
      contractor = @contact_person.contractor
      @contact_person.destroy
      redirect_to "/admin/contractors/#{contractor.id}?tab=Contact_persons#!tab-Contact_persons"
    end

    private

    def contact_person_params
      params.require(:contractor_contact_person).permit(:contractor_id, :name, :position, :email, :phone)
    end
  end
end
