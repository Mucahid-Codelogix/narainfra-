Trestle.resource(:employee_schedulings) do
  menu do
    item :employees_scheduling, icon: "fa fa-calendar", label: t("menu.employees_scheduling"), priority: 7 if current_user.role == "admin"
  end

  routes do
    get :fetch_weeks_and_codes, on: :collection
    get :fetch_days, on: :collection
    get :get_rate, on: :collection
    get :varificaion_scheduling_other_projects, on: :collection
    get :create_projects, on: :collection
    get :fetch_employee_schedulings, on: :collection
    get :fetch_employees, on: :collection
    post :pdf_download, on: :collection
  end

  search do |query|
    if query.present?
      myquery = "%#{query.downcase}%"
      query_as_integer = query.to_i
      EmployeeScheduling.joins(:project, :week, :employee).where("LOWER(projects.projectnumber) LIKE ? OR LOWER(employees.first_name) LIKE ? OR weeks.week_number = ?", myquery, myquery,
                                                                 query_as_integer)
    else
      EmployeeScheduling.all
    end
  end

  table do
    column :project, ->(employee_scheduling) { employee_scheduling.project.projectnumber }
    column :employee, ->(employee_scheduling) { employee_scheduling.employee.first_name }
    column :week, ->(employee_scheduling) { employee_scheduling.week.week_number }
    column :hours, ->(employee_scheduling) { employee_scheduling.calculte_hours(employee_scheduling, employee_scheduling.week) }
    actions
  end

  form do |employee_scheduling|
    flash.now[:error] = employee_scheduling.errors.full_messages.join(', ') if employee_scheduling.errors.any?

    disabled_fields = false
    if employee_scheduling&.project_id
      project_id = employee_scheduling.project_id.to_i
      disabled_fields = employee_scheduling&.project_id.present?
      project = Project.find(project_id)
      @employee_scheduling = EmployeeScheduling.find(employee_scheduling.id)
      @week = @employee_scheduling.week
      @days = @week&.days || []
    end
    hidden_field :project_id, value: project_id, id: "week-project-field", data: { local: I18n.locale }
    check_box :include_specification_code
    row(class: "form-row-employee-scheduling") do
      if disabled_fields
        col(sm: 4) { select :project_id, Project.all.map { |p| ["#{p.projectnumber} - #{p.place}", p.id] }, id: "", prompt: 'Select project', data: { local: I18n.locale }, disabled: disabled_fields }
        col(sm: 4) do
          select :week_id, Week.where(project_id: project_id).map { |w|
                             [w.week_number, w.id]
                           }, label: t("activerecord.attributes.employee_scheduling.week"), id: "employee_scheduling_week_id", prompt: t("prompt.employee_scheduling.select_week"), disabled: disabled_fields
        end
      else
        col(sm: 3, class: 'project-selection') do
          select :project_id, Project.all.map { |p|
                              ["#{p.projectnumber} - #{p.place}", p.id]
                              }, id: "employee_scheduling_project_id", prompt: 'Select project', data: { local: I18n.locale }
        end
        render partial: "trestle/employee_schedulings/create_project_button"
        col(sm: 4, class: 'week-selection') do
          select :week_id, [], label: t("activerecord.attributes.employee_scheduling.week"), id: "employee_scheduling_week_id", prompt: t("prompt.employee_scheduling.select_week")
        end
      end
      col(sm: 4) do
        select :employee_id, Employee.where(active: true).map { |e|
                               ["#{e.first_name} #{e.last_name}", e.id]
                             }, label: t("activerecord.attributes.employee_scheduling.employee"), id: "employee_scheduling_employee_id", prompt: t("prompt.employee_scheduling.select_employee")
      end
    end
    row do
      if disabled_fields
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/place_field", locals: {
            place_value: @employee_scheduling.project.place, disabled: true
          }
        end
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/client_field", locals: {
            client_value: @employee_scheduling.project.client.client_name, disabled: true
          }
        end
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/executor_field", locals: {
            executor_value: @employee_scheduling.project.projectperformer, disabled: true
          }
        end
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/address_field", locals: {
            address_value: @employee_scheduling&.project&.address, disabled: true
          }
        end
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/employee_role_field", locals: {
            employee_role: @employee_scheduling&.employee&.role&.role_title, disabled: true
          }
        end
        if project.tbs
          col(sm: 4) do
            select :specification_code_id, SpecificationCode.joins(:discipline).where(disciplines: { id: project.disciplines.pluck(:id) }).map { |e|
                                             ["#{e.specification_code} - #{e.description}", e.id]
                                           }, label: t("activerecord.attributes.employee_scheduling.specificaion_code"), prompt: t("prompt.employee_scheduling.select_specification_code")
          end
        else
          col(sm: 4) do
            select :specification_code_id, project.specification_codes.map { |e|
                                             ["#{e.specification_code} - #{e.description}", e.id]
                                           }, label: t("activerecord.attributes.employee_scheduling.specificaion_code"), prompt: t("prompt.employee_scheduling.select_specification_code")
          end
        end
      else
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/place_field", locals: {
            place_value: '', disabled: true
          }
        end
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/client_field", locals: {
            client_value: '', disabled: true
          }
        end
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/executor_field", locals: {
            executor_value: '', disabled: true
          }
        end
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/address_field", locals: {
            address_value: '', disabled: true
          }
        end
        col(sm: 4) do
          render partial: "trestle/employee_schedulings/employee_role_field", locals: {
            employee_role: '', disabled: true
          }
        end
        col(sm: 4) { select :specification_code_id, [], label: t("activerecord.attributes.employee_scheduling.specificaion_code"), prompt: t("prompt.employee_scheduling.select_specification_code") }
      end
    end

    hidden_field :rate, id: "employee_scheduling_rate_hidden"

    if disabled_fields
      render partial: "trestle/employee_schedulings/days_column", locals: { days: @days, employee_scheduling: @employee_scheduling }
    else
      render partial: "trestle/employee_schedulings/days_column", locals: { days: @days }
      render partial: "trestle/employee_schedulings/add_entity"
      render partial: "trestle/employee_schedulings/entities_table"
    end
    render partial: "admin/shared/warning", locals: {text: "Deze werknemer is al ingepland voor de geselecteerde week"}
    render partial: "admin/shared/loader"
  end

  controller do
    def fetch_weeks_and_codes
      project = Project.find(params[:id])
      weeks = project.weeks.order(year: :asc, week_number: :asc)
      first_week = Week.find_by(id: weeks.first.id)
      client = project.client

      @days = first_week&.days || []
      specification_codes = if project.tbs
                              SpecificationCode.joins(:discipline).where(disciplines: { id: project.disciplines.pluck(:id) })
                            else
                              project.specification_codes
                            end
      render json: { weeks: weeks, specification_codes: specification_codes, project: project, client: client, days: @days }
    end

    def fetch_days
      week_id = params[:id]
      week = Week.find_by(id: week_id)
      @days = week&.days || []

      render json: { days: @days }
    end

    def get_rate
      employee = Employee.find(params[:id])
      if employee
        rate = employee.rate
        render json: { rate: rate, employee_role: employee.role.role_title }
      else
        render json: { error: "Employee not found" }, status: :not_found
      end
    end

    def create_projects
      project = Project.new(
        projectnumber: params[:projectnumber],
        projectleader: params[:projectleader],
        projectperformer: params[:projectperformer],
        contactpersoon: params[:contactpersoon],
        place: params[:place],
        supervisor: params[:supervisor],
        address: params[:address],
        zip_code: params[:zip_code],
        start_date: params[:project_start_date],
        end_date: params[:project_end_date],
        tbs: params[:tbs],
        archived: params[:project_archived],
        client_id: params[:client_id]&.to_i,
        user_id: current_user.id,
        discipline_ids: params[:discipline_ids]
      )
      if project.save
        created_project = Project.find(project.id)
        render json: { status: true, project: created_project }
      else
        render json: { status: false, message: project.errors.full_messages.join(', ') }
      end
    end

    def varificaion_scheduling_other_projects
      week = Week.find(params[:week_id])
      employee = Employee.find(params[:employee_id])
      conflicting_scheduling = EmployeeScheduling.joins(:week)
                                                 .where(weeks: { week_number: week.week_number }, employee_id: employee.id)
                                                 .where.not(project_id: week.project)
                                                 .first
      render json: { conflict: conflicting_scheduling.present? }
    end

    def create
      project_numbers = params[:project_numbers]
      employee_names = params[:employee_names]
      week_numbers = params[:week_numbers]
      days = params[:days_details]
      include_specification_codes = params[:include_specification_codes]
      specification_codes = params[:specification_codes]
      new_employee_schedulings = []

      project_numbers&.each do |project_number_id, project_number_params|
        project = Project.find(project_number_params[:project_number].to_i)
        new_employee_schedulings << {
          employee_scheduling_id: project_number_id,
          project: project
        }
      end

      include_specification_codes&.each do |include_spec_code_id, include_spec_code_params|
        if new_employee_schedulings.any? { |es| es[:employee_scheduling_id] == include_spec_code_id }
          new_employee_scheduling = new_employee_schedulings.find { |es| es[:employee_scheduling_id] == include_spec_code_id }
          new_employee_scheduling[:include_specification_code] = include_spec_code_params[:include_specification_code] == "true"
        end
      end

      specification_codes&.each do |spec_code_id, spec_code_params|
        if new_employee_schedulings.any? { |es| es[:employee_scheduling_id] == spec_code_id }
          new_employee_scheduling = new_employee_schedulings.find { |es| es[:employee_scheduling_id] == spec_code_id }
          new_employee_scheduling[:specification_code] = (spec_code_params[:specification_code].to_i if spec_code_params[:specification_code].present?)
        end
      end

      days&.each do |day_id, day_params|
        next unless new_employee_schedulings.any? { |es| es[:employee_scheduling_id] == day_id }

        days = JSON.parse(day_params[:day_details])
        new_employee_scheduling = new_employee_schedulings.find { |es| es[:employee_scheduling_id] == day_id }
        new_employee_scheduling[:schedule_dates] = days
      end

      employee_names&.each do |employee_name_id, employee_name_params|
        next unless new_employee_schedulings.any? { |es| es[:employee_scheduling_id] == employee_name_id }

        employee = Employee.find(employee_name_params[:employee_name].to_i)
        new_employee_scheduling = new_employee_schedulings.find { |es| es[:employee_scheduling_id] == employee_name_id }
        new_employee_scheduling[:employee] = employee
      end

      week_numbers&.each do |week_number_id, week_number_params|
        next unless new_employee_schedulings.any? { |es| es[:employee_scheduling_id] == week_number_id }

        week = Week.find(week_number_params[:week_number].to_i)
        new_employee_scheduling = new_employee_schedulings.find { |es| es[:employee_scheduling_id] == week_number_id }
        new_employee_scheduling[:week] = week
      end

      success_count = 0

      new_employee_schedulings&.each do |new_es|
        employee = new_es[:employee]
        week = new_es[:week]
        project = new_es[:project]
        schedule_dates = new_es[:schedule_dates].present? && new_es[:schedule_dates].length > 0 ? new_es[:schedule_dates] : []
        next unless employee && week && project

        EmployeeScheduling.create(
          project: project,
          week: week,
          employee: employee,
          rate: employee.rate,
          schedule_dates: schedule_dates,
          include_specification_code: new_es[:include_specification_code],
          specification_code_id: new_es[:specification_code]
        )
        success_count += 1
      end

      return unless success_count.positive?

      flash[:message] = "Urenregistraties zijn succesvol aangemaakt."
      redirect_to employee_schedulings_admin_index_path
    end

    def update
      employee_scheduling = EmployeeScheduling.find(params[:id])
      employee_scheduling.assign_attributes(employee_scheduling_params)
      schedule_dates = []
      params[:days].each do |day_name, values|
        hours = values[:hours].to_i
        next if hours.zero? # Skip if hours are zero

        schedule_date = values[:date].to_date # Replace with the appropriate date
        schedule_dates << { day_date: schedule_date, hours: hours, day_name: day_name }
      end
      employee_scheduling.schedule_dates = schedule_dates

      employee_scheduling.specification_code_id = params[:employee_scheduling][:specification_code_id] if employee_scheduling_params[:include_specification_code] == "1"

      if employee_scheduling.save
        redirect_to employee_schedulings_admin_index_path
      else
        flash[:error] = employee_scheduling.errors.full_messages.join(', ')
        flash.keep[:error]
        respond_to do |format|
          format.js { render js: "location.reload();" }
        end
      end
    end

    def pdf_download
      week = Week.find(params[:week_id])
      days = week.days
      schedulings = EmployeeScheduling.where(week_id: week.id).order(id: :desc)
      pdf_filename = "week number #{week.week_number}.pdf"
      template_path = "#{Rails.root}/app/views/trestle/employees/pdf.html.erb"
      image_path = "#{Rails.root}/app/assets/images/logo.png"
      base64_encoded_image = Base64.strict_encode64(File.read(image_path))

      erb_template = File.read(template_path)

      processed_template = ERB.new(erb_template).result(binding)

      pdf = WickedPdf.new.pdf_from_string(processed_template)

      if params[:preview].present?
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'inline')
      else
        send_data(pdf, filename: pdf_filename, type: 'application/pdf', disposition: 'attachment')
      end
    end

    def fetch_employee_schedulings
      schedulings = EmployeeScheduling.includes(:project, :week, :employee).order(id: :desc)
      count = EmployeeScheduling.count
      projects_with_schedulings = Project.joins(:employee_schedulings).distinct
      render json: { schedulings: schedulings.as_json(include: [:project, :employee, { week: { include: :days } }]), count: count, projects: projects_with_schedulings }
    end

    def fetch_employees
      project_id = params[:project_id]
      schedulings = EmployeeScheduling.where(project_id: project_id).includes(:week, :employee).order(id: :desc)
      count = schedulings.count
      weeks_with_schedulings = Week.joins(:employee_schedulings).where(employee_schedulings: { project_id: project_id }).distinct
      render json: { schedulings: schedulings.as_json(include: [:employee, { week: { include: :days } }]), count: count, weeks: weeks_with_schedulings }
    end

    def destroy
      @employee_scheduling = EmployeeScheduling.find(params[:id])
      @employee_scheduling.destroy
      redirect_to employee_schedulings_admin_index_path
    end

    private

    def employee_scheduling_params
      params.require(:employee_scheduling).permit(:employee_id, :project_id, :week_id, :include_specification_code, :rate)
    end
  end
end
