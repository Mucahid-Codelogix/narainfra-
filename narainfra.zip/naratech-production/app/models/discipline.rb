class Discipline < ApplicationRecord
  belongs_to :client
  # belongs_to :project, optional: true
  has_many :specification_codes, dependent: :destroy
  has_many :project_disciplines, dependent: :destroy
  has_many :projects, through: :project_disciplines
  validates :name, presence: true
  validates_uniqueness_of :name, scope: :client_id
end
