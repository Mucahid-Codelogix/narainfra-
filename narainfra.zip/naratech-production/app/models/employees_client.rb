class EmployeesClient < ApplicationRecord
  belongs_to :client
  belongs_to :employee
  validates :client_id, uniqueness: { scope: :employee_id }
  validates_uniqueness_of :employee_number, allow_nil: true
end
