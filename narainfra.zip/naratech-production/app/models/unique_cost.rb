class UniqueCost < ApplicationRecord
  belongs_to :tkc_cost
end
