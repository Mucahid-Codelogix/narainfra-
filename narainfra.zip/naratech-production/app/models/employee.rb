class Employee < ApplicationRecord
  belongs_to :role
  belongs_to :contractor, optional: true
  validates :first_name, presence: true
  validates :last_name, presence: true

  has_many :employee_schedulings, dependent: :destroy
  has_many :projects, through: :employee_schedulings

  has_many :employees_teams, dependent: :destroy
  has_many :teams, through: :employees_teams

  has_many :employees_clients, dependent: :destroy
  has_many :clients, through: :employees_clients
  has_many :employee_certificates, dependent: :destroy

  after_create :assign_to_clients

  enum gender: {
    male: 0,
    female: 1
  }, _prefix: true

  def assign_to_clients
    Client.all.each do |client|
      client.employees << self
    end
  end
end
