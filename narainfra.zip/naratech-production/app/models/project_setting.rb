class ProjectSetting < ApplicationRecord
  validates :ak_cost, presence: true
end
