class ProjectDiscipline < ApplicationRecord
  belongs_to :discipline
  belongs_to :project
end
