class EmployeeCertificate < ApplicationRecord
  belongs_to :employee
  belongs_to :certificate_type
  has_one_attached :attachment
  # validates :certificate_type, presence: true
  validates :certificate_number, presence: true
  validates :date_achieved, presence: true
  validates :end_date, presence: true
  validate :unique_certificate_number_without_spaces
  validate :date_achieved_must_be_before_end_date

  private

  def unique_certificate_number_without_spaces
    cleaned_certificate_number = certificate_number&.delete(" ")
    existing_certificate = EmployeeCertificate.where("LOWER(REPLACE(certificate_number, ' ', '')) = ?", cleaned_certificate_number.downcase).where.not(id: id).first
    errors.add(:certificate_number, :already_exist) if existing_certificate
  end

  def date_achieved_must_be_before_end_date
    return if date_achieved.blank? || end_date.blank?

    errors.add(:date_achieved, :date_before_end_date) if date_achieved >= end_date
  end
end
