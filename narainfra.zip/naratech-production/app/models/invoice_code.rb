class InvoiceCode < ApplicationRecord
  belongs_to :invoice, optional: true
  belongs_to :debit_invoice, optional: true
  belongs_to :specification_code
end
