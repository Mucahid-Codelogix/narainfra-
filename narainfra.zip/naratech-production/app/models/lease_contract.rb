class LeaseContract < ApplicationRecord
  belongs_to :material, optional: true
  belongs_to :equipment_material, optional: true
  validates :lease_company, presence: true
  validates :contract_number, presence: true
  validates :lease_amount_ex_vat, presence: true
end
