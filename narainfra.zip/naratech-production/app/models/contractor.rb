class Contractor < ApplicationRecord
  has_many :invoices, dependent: :destroy
  has_many :contractor_contact_persons, dependent: :destroy
  has_many :employees, dependent: :nullify
  has_one :contractor_finance, dependent: :destroy
  validates :contractor_id, presence: true, uniqueness: true
  validates :contractor_name, presence: true
  validates :email, presence: true
end
