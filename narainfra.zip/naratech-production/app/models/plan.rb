class Plan < ApplicationRecord
  belongs_to :project
  belongs_to :activity
  belongs_to :start_week, class_name: 'Week', foreign_key: 'start_week_id'
  belongs_to :end_week, class_name: 'Week', foreign_key: 'end_week_id'
  has_many :plan_teams, dependent: :destroy
  has_many :teams, through: :plan_teams

  validate :start_week_must_be_before_end_week

  validate :activity_has_no_existing_plan, on: [:create, :update]

  private

  def start_week_must_be_before_end_week
    errors.add(:base, :week_before_end_week) if start_week && end_week && start_week.week_number >= end_week.week_number
  end

  def activity_has_no_existing_plan
    errors.add(:base, :selected_activity_already_has_plan) if activity && project.plans.where(activity: activity).where.not(id: id).exists?
  end
end
