class User < ApplicationRecord
  include Trestle::Auth::ModelMethods
  include Trestle::Auth::ModelMethods::Rememberable
  has_many :projects, dependent: :destroy
  has_many :notes, dependent: :destroy

  enum role: {
    admin: 0,
    accountant: 1
  }, _prefix: true
end
