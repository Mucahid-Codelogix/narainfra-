class Day < ApplicationRecord
  belongs_to :week
  belongs_to :project

  enum day_name: { monday: 0, tuesday: 1, wednesday: 2, thursday: 3, friday: 4, saturday: 5, sunday: 6 }

  validates :date, presence: true
  validates :day_name, presence: true
end
