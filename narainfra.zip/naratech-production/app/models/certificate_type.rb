class CertificateType < ApplicationRecord
  has_many :employee_certificates, dependent: :nullify
  validates :name, presence: true
end
