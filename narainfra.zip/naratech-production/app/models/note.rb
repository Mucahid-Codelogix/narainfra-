class Note < ApplicationRecord
  belongs_to :user
  belongs_to :material, optional: true
  belongs_to :equipment_material, optional: true
end
