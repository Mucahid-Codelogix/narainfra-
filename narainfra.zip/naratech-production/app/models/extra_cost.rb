class ExtraCost < ApplicationRecord
  belongs_to :project
  belongs_to :week

  enum item_type: {
    material: 0,
    machinery: 1,
    other: 2
  }, _prefix: true
end
