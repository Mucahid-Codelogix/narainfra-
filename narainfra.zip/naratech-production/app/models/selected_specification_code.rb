class SelectedSpecificationCode < ApplicationRecord
  belongs_to :specification_code
  belongs_to :project
end
