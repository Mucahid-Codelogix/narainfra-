class SpecificationCode < ApplicationRecord
  belongs_to :client
  belongs_to :discipline
  has_many :selected_specification_codes, dependent: :destroy
  has_many :projects, through: :selected_specification_codes
  has_many :invoice_codes, dependent: :destroy
  has_many :invoices, through: :invoice_codes
  has_many :purchase_orders, dependent: :destroy
  has_many :tkc_cost_amounts, dependent: :destroy
  has_many :employee_schedulings, dependent: :nullify

  validates :price, presence: true

  validates :specification_code, uniqueness: { scope: [:client_id, :discipline_id], message: :client_spec_disc_uniqueness }

  # validates :price, format: { with: /\A\d+\.\d{0,2}\z/, message: "can have at most two decimal places" }, allow_nil: false
end
