class ClientContactPerson < ApplicationRecord
  self.table_name = "client_contact_persons"
  belongs_to :client
  validates :name, presence: true
end
