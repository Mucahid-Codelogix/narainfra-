class DebitInvoice < ApplicationRecord
  belongs_to :client
  has_one_attached :invoice_pdf

  has_many :invoice_details, dependent: :destroy

  has_many :invoice_codes, dependent: :destroy
  has_many :specification_codes, through: :invoice_codes

  validates :invoice_number, presence: true, uniqueness: true
  # validates_uniqueness_of :client_id, scope: [:project_id, :week_id], message: I18n.t('activerecord.errors.models.invoice.attributes.client.taken')

  enum status: {
    open: 0,
    sent: 1,
    partially_paid: 2,
    paid: 3
  }, _prefix: true

  def calculate_total(invoice)
    invoice_codes = invoice.invoice_codes
    total_amount_sum = 0.0
    invoice_codes.each do |invoice_code|
      total_amount_sum += invoice_code.total_amount
    end
    total_amount_sum
  end

  def euro_format(amount)
    if amount.to_f < 0
      formatted_amount = ActionController::Base.helpers.number_to_currency(-1 * amount.to_f, unit: "€", format: "%u -%n")
    else
      formatted_amount = ActionController::Base.helpers.number_to_currency(amount, unit: "€", format: "%u %n")
    end

    formatted_amount
  end

  def format_number(amount)
    integer_part, decimal_part = ("%.2f" % amount).split(".")
    integer_part.gsub!(/\d(?=(...)+$)/, '\0.')
    "#{integer_part},#{decimal_part}"
  end
end
