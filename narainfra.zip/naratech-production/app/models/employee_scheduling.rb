class EmployeeScheduling < ApplicationRecord
  belongs_to :project
  belongs_to :employee
  belongs_to :week
  belongs_to :specification_code, optional: true

  validates :project, uniqueness: { scope: [:employee_id, :week_id], message: "already exists for this employee and week" }
  validate :specification_code_presence_if_required

  def calculte_hours(employee_scheduling, week)
    calculate_total_hours(employee_scheduling.schedule_dates, week.days)
  end

  def calculate_total_hours(schedule_dates, week_days)
    total_hours = 0
    schedule_dates&.each do |schedule|
      day_name = schedule['day_name'].downcase
      if week_days.any? { |day| day.day_name.downcase == day_name }
        total_hours += schedule['hours'].to_i
      end
    end
    total_hours
  end

  def get_hours_for_day(employee_scheduling, day)
    desired_object = employee_scheduling.schedule_dates.select { |date| date["day_name"] == day.day_name }.first
    if desired_object
      desired_object["hours"]
    else
      0
    end
  end

  private

  def specification_code_presence_if_required
    errors.add(:base, :specification_code_must_selected) if include_specification_code && specification_code_id.nil?
  end
end
