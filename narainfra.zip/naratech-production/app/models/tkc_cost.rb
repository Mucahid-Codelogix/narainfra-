class TkcCost < ApplicationRecord
  belongs_to :project
  belongs_to :week
  has_many :tkc_cost_amounts, dependent: :destroy
  has_many :unique_costs, dependent: :destroy
  has_rich_text :tkc_description

  # before_validation :calculate_tkc_total

  validates :tkc_description, presence: true
  validates :week, uniqueness: { scope: :project_id, message: I18n.t('activerecord.errors.models.tkc_cost.attributes.week.taken') }

  # def calculate_tkc_total
  #   self.services ||= 0
  #   self.material ||= 0
  #   self.additional ||= 0
  #   self.tkc_total = self.services + self.material + self.additional
  # end
end
