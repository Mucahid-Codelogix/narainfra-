class Activity < ApplicationRecord
  belongs_to :project
  has_one :plan, dependent: :destroy
  validates :activity_name, presence: true
  validates :project, uniqueness: { scope: [:activity_name], message: "already exists for this activity" }
end
