class TkcCostAmount < ApplicationRecord
  belongs_to :project
  belongs_to :specification_code
  belongs_to :tkc_cost
end
