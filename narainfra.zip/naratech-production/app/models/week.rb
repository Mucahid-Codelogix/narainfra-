class Week < ApplicationRecord
  validates :start_date, presence: true
  validates :end_date, presence: true
  validates :year, presence: true
  has_rich_text :description

  enum status: {
    open: 0,
    pending: 1,
    send: 2,
    approved: 3
  }, _prefix: true

  # enum pdf_status: {
  #   send: 0,
  #   approved: 1
  # }, _prefix: true

  enum tkc_status: {
    send: 0,
    approved: 1
  }, _prefix: true

  belongs_to :project
  has_many :purchase_orders, dependent: :destroy
  has_many :employee_schedulings, dependent: :destroy
  has_many :days, dependent: :destroy
  has_one :tkc_cost, dependent: :destroy
  has_many :extra_costs, dependent: :destroy

  has_many :start_week_plans, class_name: 'Plan', foreign_key: 'start_week_id', dependent: :destroy
  has_many :end_week_plans, class_name: 'Plan', foreign_key: 'end_week_id', dependent: :destroy

  validate :unique_week_number_within_project_and_year

  def calculate_employee_revenue_pdf(week, project, selected_specification_code_id)
    employee_scheduling = week.employee_schedulings.where(project_id: project.id, week_id: week.id, selected_specification_code_id: selected_specification_code_id, include_specification_code: true)
    employee_revenue_total_sum(employee_scheduling, week)
  end

  def calculate_employee_revenue(week, project)
    employee_scheduling = EmployeeScheduling.where(project_id: project.id, week_id: week.id)
    employee_revenue_total_sum(employee_scheduling, week)
  end

  def employee_revenue_total_sum(employee_scheduling, week)
    total_sum_all_employee_scheduling = 0.0
    employee_scheduling.each do |e|
      total_sum_all_employee_scheduling += calculate_employee_scheduling_revenue(e, week)
    end
    total_sum_all_employee_scheduling
  end

  def calculate_employee_scheduling_revenue(employee_scheduling, week)
    total_hours_with_code_price = employee_scheduling.specification_code && employee_scheduling.include_specification_code ? employee_scheduling.specification_code.price : 0
    total_hours = calculate_total_hours(employee_scheduling.schedule_dates, week.days)
    total_hours * total_hours_with_code_price
  end

  def calculate_total_hours(schedule_dates, week_days)
    total_hours = 0
    schedule_dates.each do |schedule|
      day_name = schedule['day_name'].downcase
      total_hours += schedule['hours'].to_i if week_days.any? { |day| day.day_name.downcase == day_name }
    end
    total_hours
  end

  def calculate_total_tkc_cost_week(week, project)
    tkc_costs = TkcCost.where(week_id: week.id, project_id: project.id)
    tkc_cost_sum = tkc_costs.sum(:tkc_total)
    total_cost_amount_sum = 0.0
    tkc_cost_unique_cost_sum = 0.0
    tkc_costs.each do |tkc_cost|
      total_cost_amount_sum += tkc_cost.tkc_cost_amounts.sum(:total_amount)
      tkc_cost_unique_cost_sum += tkc_cost.unique_costs.sum(:total)
    end
    tkc_cost_sum + total_cost_amount_sum + tkc_cost_unique_cost_sum
  end

  def calculate_total_revenue(week, project)
    purchase_orders_sum = PurchaseOrder.where(project_id: project.id, week_id: week.id).sum(:total_amount)
    employee_revenue = calculate_employee_revenue(week, project)
    total_tkc_cost = calculate_total_tkc_cost_week(week, project)
    if project.tbs == false
      purchase_orders_sum + total_tkc_cost + employee_revenue
    else
      purchase_orders_sum + employee_revenue
    end
  end

  def calculate_turn_over_week(week, project)
    purchase_orders_sum = PurchaseOrder.where(project_id: project.id, week_id: week.id).sum(:total_amount)
    employee_revenue = calculate_employee_revenue(week, project)
    purchase_orders_sum + employee_revenue
  end

  def total_overview_turn_over
    week = self
    project = self.project
    purchase_orders_sum = PurchaseOrder.where(project_id: project.id, week_id: week.id).sum(:total_amount)
    employee_revenue = calculate_employee_revenue(week, project)
    purchase_orders_sum + employee_revenue
  end

  def turnover_week
    project = self.project
    amount = calculate_turn_over_week(self, project)
    project.euro_format(project.format_number(amount))
  end

  def calculate_turn_over_week_pdf(week, project, discipline)
    # purchase_orders_sum = PurchaseOrder.where(project_id: project.id, week_id: week.id).sum(:total_amount)
    purchase_orders_sum = PurchaseOrder.joins(:specification_code)
                                       .where(project_id: project.id, week_id: week.id, specification_codes: { discipline_id: discipline.id })
                                       .sum(:total_amount)
    # employee_revenue = calculate_employee_revenue(week, project)
    # purchase_orders_sum + employee_revenue

    employee_schedulings = EmployeeScheduling.joins(:specification_code)
                                             .where(
                                               project_id: project.id,
                                               week_id: week.id,
                                               include_specification_code: true,
                                               specification_codes: { discipline_id: discipline.id }
                                             )
    employee_revenue = employee_revenue_total_sum(employee_schedulings, week)
    purchase_orders_sum + employee_revenue
  end

  def calculate_other_cost(week, project)
    turnover = calculate_total_revenue(week, project)
    percentage = ProjectSetting.first&.ak_cost || 15
    percentage /= 100.to_f
    turnover * percentage
  end

  def calculate_total_cost_employee(schedule_dates, rate, week)
    rate ? calculate_total_hours(schedule_dates, week.days) * rate : 0
  end

  def calculate_total_cost_week_employee(week, project)
    EmployeeScheduling.where(project_id: project.id, week_id: week.id).sum { |employee_scheduling| calculate_total_cost_employee(employee_scheduling.schedule_dates, employee_scheduling.rate, week) }
  end

  def calculate_total_extra_cost_week(week, project)
    ExtraCost.where(week_id: week.id, project_id: project.id).sum(:cost)
  end

  def sum_of_employee_and_extra_costs(week, project)
    total_employee_cost = calculate_total_cost_week_employee(week, project)
    total_extra_cost = calculate_total_extra_cost_week(week, project)

    total_employee_cost + total_extra_cost
  end

  def calculate_total_cost(week, project)
    total_employee_cost = calculate_total_cost_week_employee(week, project)
    total_extra_cost = calculate_total_extra_cost_week(week, project)
    other_cost = calculate_other_cost(week, project)
    if project.tbs == false
      total_employee_cost + total_extra_cost + other_cost
    else
      total_employee_cost + other_cost
    end
  end

  def calculate_profit(week, project)
    total_cost = calculate_total_cost(week, project)
    total_cost = total_cost.round(1)
    total_revenue = calculate_total_revenue(week, project)
    total_revenue = total_revenue.round(1)
    total_revenue - total_cost
  end

  def show_comulatief(project_id, week_number, code, amount)
    project = Project.find(project_id)
    previous_weeks = project.weeks.where("week_number < ?", week_number)

    if previous_weeks.present?
      purchase_orders = PurchaseOrder.joins(:week).where(specification_code: code, weeks: { id: previous_weeks })
      total_sum_amount = purchase_orders.sum(:amount)
    else
      total_sum_amount = 0
    end

    (total_sum_amount + amount)
  end

  def show_comulatief_project_contract_type(project_id, week_number, amount)
    project = Project.find(project_id)
    previous_weeks = project.weeks.where("week_number < ?", week_number)

    if previous_weeks.present?
      purchase_orders = PurchaseOrder.joins(:week).where(project_id: project_id, weeks: { id: previous_weeks })
      total_sum_amount = purchase_orders.sum(:amount)
    else
      total_sum_amount = 0
    end

    (total_sum_amount + amount)
  end

  def get_comulatief_project_contract_type(week)
    project = week.project
    total_comulatief_amount = 0
    if project.purchase_orders.any?
      week_number = week.week_number
      previous_weeks = project.weeks.where("week_number < ?", week_number)
      if previous_weeks.present?
        purchase_orders = PurchaseOrder.joins(:week).where(project_id: project_id, weeks: { id: previous_weeks })
        total_comulatief_amount = purchase_orders.sum(:amount)
      else
        total_comulatief_amount = 0
      end
    end
    total_comulatief_amount
  end

  private

  def unique_week_number_within_project_and_year
    existing_week = Week.where(project_id: project_id, year: year, week_number: week_number).where.not(id: id).first
    errors.add(:week_number, "Week number #{week_number} already exists for the same project and year") if existing_week
  end
end
