class MaterialAttachment < ApplicationRecord
  belongs_to :material, optional: true
  belongs_to :equipment_material, optional: true
  has_one_attached :attachment
end
