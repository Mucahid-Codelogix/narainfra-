class Material < ApplicationRecord
  has_many :notes, dependent: :destroy
  has_many :lease_contracts, dependent: :destroy
  has_many :material_attachments, dependent: :destroy
  # accepts_nested_attributes_for :material_attachments, allow_destroy: true
  has_many :insurances, dependent: :destroy
  validate :unique_ref_number_without_spaces
  # enum material_type: {
  #   vehicle: 0,
  #   machinery: 1
  # }, _prefix: true

  enum in_use: {
    no: 0,
    yes: 1
  }, _prefix: true

  private

  def unique_ref_number_without_spaces
    cleaned_ref_number = ref_number&.delete(" ")
    existing_material = Material.where("LOWER(REPLACE(ref_number, ' ', '')) = ?", cleaned_ref_number.downcase).where.not(id: id).first
    errors.add(:ref_number, :already_exist) if existing_material
  end
end
