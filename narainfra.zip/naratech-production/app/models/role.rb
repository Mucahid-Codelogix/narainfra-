class Role < ApplicationRecord
  has_many :employees, dependent: :nullify
  validates :role_title, presence: true
end
