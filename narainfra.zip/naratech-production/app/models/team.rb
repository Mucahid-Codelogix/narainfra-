class Team < ApplicationRecord
  has_many :employees_teams, dependent: :destroy
  has_many :employees, through: :employees_teams

  has_many :plan_teams, dependent: :destroy
  has_many :plans, through: :plan_teams

  validates :team_name, presence: true
end
