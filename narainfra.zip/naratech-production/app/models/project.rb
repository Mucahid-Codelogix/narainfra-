class Project < ApplicationRecord
  belongs_to :client
  belongs_to :user
  has_many :selected_specification_codes, dependent: :destroy
  has_many :specification_codes, through: :selected_specification_codes
  has_many :weeks, dependent: :destroy
  has_many :purchase_orders, dependent: :destroy
  has_many :tkc_cost_amounts, dependent: :destroy
  has_many :employee_schedulings, dependent: :destroy
  has_many :employees, through: :employee_schedulings
  has_many :days, through: :weeks
  has_many :tkc_costs, dependent: :destroy
  has_many :extra_costs, dependent: :destroy
  has_many :activities, dependent: :destroy
  has_many :plans, dependent: :destroy
  has_many :project_disciplines, dependent: :destroy
  has_many :disciplines, through: :project_disciplines
  # has_many :disciplines, dependent: :nullify

  validates :projectnumber, presence: true
  validate :unique_projectnumber_without_spaces
  validates :start_date, presence: true
  validates :end_date, presence: true
  # validate :unique_projectnumber_without_spaces

  validate :start_date_must_be_before_end_date

  after_create :create_weeks
  before_update :update_weeks, if: -> { start_date_changed? || end_date_changed? }

  def selected_budget(specification_code, project)
    selected_specification_code = SelectedSpecificationCode.find_by(project_id: project.id, specification_code_id: specification_code.id)
    selected_specification_code&.total_budget
  end

  def select_status(week)
    week = Week.find(week.id)
    week&.pdf_status
  end

  def euro_format(amount)
    if amount.match?(/-/)
      amount_without_minus = amount.gsub("-", "")
      formatted_amount = ActionController::Base.helpers.number_to_currency(amount_without_minus, unit: "€", format: "%u -%n")
    else
      formatted_amount = ActionController::Base.helpers.number_to_currency(amount, unit: "€", format: "%u %n")
    end
  end

  def format_number(amount)
    integer_part, decimal_part = ("%.2f" % amount).split(".")
    integer_part.gsub!(/\d(?=(...)+$)/, '\0.')
    "#{integer_part},#{decimal_part}"
  end

  def filter_specification_codes(specification_codes, project, discipline)
    specification_codes = if discipline == "all"
                            specification_codes.joins(:discipline).where(disciplines: { id: project.disciplines.pluck(:id) })
                          else
                            specification_codes.joins(:discipline).where(disciplines: { id: discipline })
                          end
  end

  private

  def unique_projectnumber_without_spaces
    cleaned_projectnumber = projectnumber&.delete(" ")
    existing_project = Project.where("LOWER(REPLACE(projectnumber, ' ', '')) = ?", cleaned_projectnumber.downcase).where.not(id: id).first
    errors.add(:projectnumber, :already_exist) if existing_project
  end

  def start_date_must_be_before_end_date
    return if start_date.blank? || end_date.blank?

    errors.add(:start_date, :date_before_end_date) if start_date >= end_date
  end

  # def create_weeks
  #   current_date = start_date
  #   week_number = current_date.strftime("%V").to_i
  #   week_number = 1 if week_number == 0 # Ensure that the first week is always week 1
  #   custom_year = 0

  #   while current_date <= end_date
  #     week_end_date = [current_date.end_of_week(:sunday) + 1.day, end_date].min

  #     # Calculate the year for the week
  #     if current_date == start_date
  #       if start_date.sunday?
  #         week_start_date = start_date
  #         week_end_date = start_date
  #         week_number -= 1
  #       else
  #         if start_date.month == 1 && start_date.day == 1
  #           week_start_date = start_date.beginning_of_year
  #         else
  #           week_start_date = current_date
  #         end
  #       end
  #     else
  #       if (current_date + 7.days).year != current_date.year
  #         custom_year += 1
  #       end
  #       week_start_date = current_date.beginning_of_week(:monday)
  #     end

  #     if current_date == end_date && end_date.year != current_date.year
  #       week_end_date = end_date.end_of_year
  #     end

  #     if (custom_year > 0)
  #       week = weeks.create(start_date: week_start_date, end_date: week_end_date, year: custom_year, week_number: week_number)
  #     else
  #       week = weeks.create(start_date: week_start_date, end_date: week_end_date, year: current_date.year, week_number: week_number)
  #     end

  #     (week_start_date..week_end_date).each do |day_date|
  #       day = week.days.create(day_name: day_date.strftime("%A").downcase.to_sym, date: day_date, project: self)
  #     end

  #     current_date = current_date.beginning_of_week(:monday) + 7.days
  #     week_number += 1
  #   end
  # end

  def create_weeks
    current_date = start_date
    week_number = current_date.strftime("%V").to_i
    week_number = 1 if week_number == 0 # Ensure that the first week is always week 1
    custom_year = 0
    while current_date <= end_date
      week_end_date = [current_date.end_of_week(:sunday) + 1.day, end_date].min
      if week_number != current_date.strftime("%V").to_i # Use ISO-8601 standard consistently
        if current_date.year == Date.today.year
          week_number = current_date.strftime("%V").to_i # Use ISO-8601 standard consistently
          custom_year = current_date.year
        elsif current_date.strftime("%V").to_i + 1 == 53
          week_number = 1
          custom_year = current_date.year + 1
        else
          week_number = current_date.strftime("%V").to_i + 1 # Use ISO-8601 standard consistently
          custom_year = current_date.year
        end
      end

      if current_date == start_date
        if start_date.sunday?
          week_start_date = start_date
          week_end_date = start_date
          week_number -= 1
        else
          week_start_date = if start_date.month == 1 && start_date.day == 1
                              start_date.beginning_of_year
                            else
                              current_date
                            end
        end
      else
        week_start_date = current_date.beginning_of_week(:monday)
      end

      custom_year += 1 if current_date.year != week_end_date.year && week_number == 1

      week = if custom_year > 0
               weeks.create(start_date: week_start_date, end_date: week_end_date, year: custom_year, week_number: week_number)
             else
               weeks.create(start_date: week_start_date, end_date: week_end_date, year: current_date.year, week_number: week_number)
             end

      (week_start_date..week_end_date).each do |day_date|
        day = week.days.create(day_name: day_date.strftime("%A").downcase.to_sym, date: day_date, project: self)
        day.save
      end

      current_date = current_date.beginning_of_week(:monday) + 7.days
      week_number += 1

      # ... rest of the code ...
    end
  end

  # def create_weeks
  #   current_date = start_date
  #   week_number = current_date.strftime("%V").to_i
  #   week_number = 1 if week_number == 0
  #   custom_year = 0
  #   while current_date <= end_date
  #     week_end_date = [current_date.end_of_week(:sunday) + 1.day, end_date].min
  #     if week_number != current_date.strftime("%V").to_i
  #       if current_date.year != Date.today.year
  #         if current_date.strftime("%U").to_i + 1 == 53
  #           week_number = 1
  #           custom_year = current_date.year + 1
  #         else
  #           week_number = current_date.strftime("%U").to_i + 1
  #           custom_year = current_date.year
  #         end
  #       else
  #         week_number = current_date.strftime("%U").to_i
  #         custom_year = current_date.year
  #       end
  #     end

  #     if current_date == start_date
  #       if start_date.sunday?
  #         week_start_date = start_date
  #         week_end_date = start_date
  #         week_number -= 1
  #       else
  #         week_start_date = current_date
  #       end
  #     else
  #       week_start_date = current_date.beginning_of_week(:monday)
  #     end

  #     if (custom_year > 0)
  #       week = weeks.create(start_date: week_start_date, end_date: week_end_date, year: custom_year, week_number: week_number)
  #     else
  #       week = weeks.create(start_date: week_start_date, end_date: week_end_date, year: current_date.year, week_number: week_number)
  #     end

  #     # Create days for the week
  #     (week_start_date..week_end_date).each do |day_date|
  #       day = week.days.create(day_name: day_date.strftime("%A").downcase.to_sym, date: day_date, project: self)
  #       day.save
  #     end

  #     current_date = current_date.beginning_of_week(:monday) + 7.days
  #     week_number += 1
  #   end
  # end
  def update_weeks
    overlapping_weeks = weeks.where("start_date <= ? AND end_date >= ?", end_date, start_date)

    # Update overlapping weeks
    overlapping_weeks.each do |week|
      week_start_date = [week.start_date, start_date].max
      week_end_date = [week.end_date, end_date].min

      week.update(start_date: week_start_date, end_date: week_end_date)

      # Delete days outside of the new week range
      days_to_delete = week.days.where.not(date: week_start_date..week_end_date)
      days_to_delete.destroy_all

      # Update or create days within the week to match the new sequence
      (week_start_date..week_end_date).each do |day_date|
        day = week.days.find_or_initialize_by(date: day_date)
        day.update(day_name: day_date.strftime("%A").downcase.to_sym, project: self)
      end
    end
    # Destroy weeks outside of the new date range
    weeks_to_destroy = weeks.where.not(id: overlapping_weeks.pluck(:id))
    weeks_to_destroy.destroy_all
    # Create or update weeks as needed
    current_date = start_date
    while current_date <= end_date
      # week_start_date = current_date.beginning_of_week(:monday)
      week_end_date = [current_date.end_of_week(:sunday) + 1.day, end_date].min

      if current_date == start_date
        if start_date.sunday?
          week_start_date = start_date
          week_end_date = start_date
          week_number -= 1
        else
          # If the start date is in the first week of January, set the week_start_date to the first day of the year
          week_start_date = if start_date.month == 1 && start_date.day == 1
                              start_date.beginning_of_year
                            else
                              current_date
                            end
        end
      else
        week_start_date = current_date.beginning_of_week(:monday)
      end
      # if current_date == start_date
      #   if start_date.sunday?
      #     week_start_date = start_date
      #     week_end_date = start_date
      #     week_number -= 1
      #   else
      #     week_start_date = current_date
      #   end
      # else
      #   week_start_date = current_date.beginning_of_week(:monday)
      # end

      week_number = current_date.strftime("%V").to_i
      custom_year = current_date.year

      # Adjust week number and year if needed
      custom_year += 1 if current_date.year != week_end_date.year && week_number == 1

      week = weeks.find_or_initialize_by(week_number: week_number, year: custom_year)
      week.update(start_date: week_start_date, end_date: week_end_date)

      # Create days for the week
      (week_start_date..week_end_date).each do |day_date|
        day = week.days.find_or_initialize_by(date: day_date)
        day.update(day_name: day_date.strftime("%A").downcase.to_sym, project: self)
      end

      current_date = current_date.beginning_of_week(:monday) + 7.days
    end
    # Create or update purchase orders
    specification_codes = selected_specification_codes
    weeks.each do |week|
      specification_codes.each do |specification_code|
        specification_code_id = specification_code.specification_code_id
        code = specification_code.specification_code
        existing_purchase_order = PurchaseOrder.find_by(
          project_id: id,
          specification_code_id: specification_code_id,
          week_id: week.id
        )

        if existing_purchase_order.nil?
          purchase_order = PurchaseOrder.create(
            project_id: id,
            specification_code_id: specification_code_id,
            week_id: week.id,
            price: code.price,
            total_budget: specification_code.total_budget
          )
        elsif existing_purchase_order.amount.nil? || existing_purchase_order.amount == 0.0
          existing_purchase_order.update(total_budget: specification_code.total_budget, price: code.price)
        end
      end
    end
  end

  # def update_weeks
  #   overlapping_weeks = weeks.where("start_date <= ? AND end_date >= ?", end_date, start_date)
  #   overlapping_weeks.each do |week|
  #     week_start_date = [week.start_date, start_date].max
  #     week_end_date = [week.end_date, end_date].min

  #     week.update(start_date: week_start_date, end_date: week_end_date)

  #     days_to_delete = week.days.where.not(date: week_start_date..week_end_date)
  #     days_to_delete.destroy_all

  #     # Update days within the week to match the new sequence
  #     (week_start_date..week_end_date).each do |day_date|
  #       day = week.days.find_or_initialize_by(date: day_date)
  #       day.update(day_name: day_date.strftime("%A").downcase.to_sym, project: self)
  #     end
  #   end

  #   weeks_to_destroy = weeks.where.not(id: overlapping_weeks.pluck(:id))
  #   weeks_to_destroy.destroy_all

  #   # Create or update other weeks as needed
  #   current_date = start_date
  #   week_number = current_date.strftime("%V").to_i
  #   custom_year = 0
  #   while current_date <= end_date
  #     week_end_date = [current_date.end_of_week(:sunday) + 1.day, end_date].min

  #     if week_number != current_date.strftime("%V").to_i
  #       if current_date.year != Date.today.year
  #         if current_date.strftime("%V").to_i + 1 == 53
  #           week_number = 1
  #           custom_year = current_date.year + 1
  #         else
  #           week_number = current_date.strftime("%V").to_i + 1
  #           custom_year = current_date.year
  #         end
  #       else
  #         week_number = current_date.strftime("%V").to_i
  #         custom_year = current_date.year
  #       end
  #     end

  #     if current_date == start_date
  #       if start_date.sunday?
  #         week_start_date = start_date
  #         week_end_date = start_date
  #         week_number -= 1
  #       else
  #         week_start_date = current_date
  #       end
  #     else
  #       week_start_date = current_date.beginning_of_week(:monday)
  #     end

  #     if (custom_year > 0)
  #       week = weeks.find_or_initialize_by(week_number: week_number, year: custom_year)
  #       week.update(start_date: week_start_date, end_date: week_end_date, year: custom_year)
  #     else
  #       week = weeks.find_or_initialize_by(week_number: week_number, year: current_date.year)
  #       week.update(start_date: week_start_date, end_date: week_end_date, year: current_date.year)
  #     end

  #     # Create days for the week
  #     (week_start_date..week_end_date).each do |day_date|
  #       day = week.days.find_or_initialize_by(date: day_date)
  #       day.update(day_name: day_date.strftime("%A").downcase.to_sym, project: self)
  #     end

  #     current_date = current_date.beginning_of_week(:monday) + 7.days
  #     week_number += 1
  #   end
  #   specification_codes = selected_specification_codes

  #   weeks.each do |week|
  #     specification_codes.each do |specification_code|
  #       specification_code_id = specification_code.specification_code_id
  #       code = specification_code.specification_code
  #       existing_purchase_order = PurchaseOrder.find_by(
  #         project_id: id,
  #         specification_code_id: specification_code_id,
  #         week_id: week.id,
  #       )

  #       if existing_purchase_order.nil?
  #         purchase_order = PurchaseOrder.create(
  #           project_id: id,
  #           specification_code_id: specification_code_id,
  #           week_id: week.id,
  #           price: code.price,
  #           total_budget: specification_code.total_budget,
  #         )
  #       elsif existing_purchase_order.amount.nil? || existing_purchase_order.amount == 0.0
  #         existing_purchase_order.update(total_budget: specification_code.total_budget, price: code.price)
  #       end
  #     end
  #   end
  # end

  def projects_with_plans
    {
      id: id,
      plans: plans.map { |plan| { id: plan.id, name: plan.start_week } }
    }
  end
end
