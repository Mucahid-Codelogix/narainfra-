class ContractorContactPerson < ApplicationRecord
  self.table_name = "contractor_contact_persons"
  belongs_to :contractor
  validates :name, presence: true
end
