class Insurance < ApplicationRecord
  belongs_to :material, optional: true
  belongs_to :equipment_material, optional: true
  validates :insurer, presence: true
  validates :policy_number, presence: true
end
