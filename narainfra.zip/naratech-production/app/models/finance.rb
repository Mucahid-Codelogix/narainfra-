class Finance < ApplicationRecord
  belongs_to :client
  validates :vat_number, presence: true
  validate :unique_vat_number_without_spaces
  after_create :update_invoices
  after_update :update_invoices

  private

  def update_invoices
    payment_term_value = self.payment_term_value
    invoices = self.client.invoices
    debit_invoices = self.client.debit_invoices
    # # Your logic to update the associated invoices goes here
    invoices&.each do |invoice|
      inovice_date = invoice&.invoice_date

      # Add 35 days to the current date
      if invoice&.invoice_date&.present? && payment_term_value.present?
        new_date = inovice_date + payment_term_value
        invoice.update(expiration_date: new_date)
      end
    end

    debit_invoices&.each do |invoice|
      inovice_date = invoice.invoice_date

      # Add 35 days to the current date
      if invoice&.invoice_date&.present? && payment_term_value.present?
        new_date = inovice_date + payment_term_value
        invoice.update(expiration_date: new_date)
      end
      
    end
  end

  def unique_vat_number_without_spaces
    cleaned_vat_number = vat_number&.delete(" ")
    existing_vat = Finance.where("LOWER(REPLACE(vat_number, ' ', '')) = ?", cleaned_vat_number.downcase).where.not(id: id).first
    errors.add(:vat_number, :already_exist) if existing_vat
  end
end
