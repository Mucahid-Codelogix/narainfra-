class Invoice < ApplicationRecord
  belongs_to :client, optional: true
  belongs_to :contractor, optional: true
  has_one_attached :invoice_pdf
  has_one_attached :attachment
  has_many :invoice_details, dependent: :destroy

  has_many :invoice_codes, dependent: :destroy
  has_many :specification_codes, through: :invoice_codes

  # validate :client_or_contractor

  validates :invoice_number, presence: true
  validate :unique_invoice_number_for_contractor_or_client_or_other
  # validates_uniqueness_of :client_id, scope: [:project_id, :week_id], message: I18n.t('activerecord.errors.models.invoice.attributes.client.taken')

  enum status: {
    open: 0,
    sent: 1,
    partially_paid: 2,
    paid: 3
  }, _prefix: true

  def calculate_total(invoice)
    invoice_codes = invoice.invoice_codes
    total_amount_sum = 0.0
    invoice_codes.each do |invoice_code|
      total_amount_sum += invoice_code.total_amount
    end
    total_amount_sum
  end

  def euro_format(amount)
    if amount.match?(/-/)
      amount_without_minus = amount.gsub("-", "")
      formatted_amount = ActionController::Base.helpers.number_to_currency(amount_without_minus, unit: "€", format: "%u -%n")
    else
      formatted_amount = ActionController::Base.helpers.number_to_currency(amount, unit: "€", format: "%u %n")
    end
  end

  def format_number(amount)
    integer_part, decimal_part = ("%.2f" % amount).split(".")
    integer_part.gsub!(/\d(?=(...)+$)/, '\0.')
    "#{integer_part},#{decimal_part}"
  end

  def attachment_attached
    attachment.attached?
  end

  def attachment_url
    if attachment.attached?
      Rails.application.routes.url_helpers.rails_blob_url(attachment, only_path: true)
    end
  end

  private

  def unique_invoice_number_for_contractor_or_client_or_other
    if new_record?
      if contractor && Invoice.where(contractor_id: contractor.id, invoice_number: invoice_number).exists?
        errors.add(:invoice_number, "is al in gebruik voor de geselecteerde opdrachtnemer")
      end
      if client && Invoice.where(client_id: client.id, invoice_number: invoice_number).exists?
        errors.add(:invoice_number, "is al in gebruik voor de geselecteerde opdrachtgever")
      end
      if contractor.nil? && client.nil? && Invoice.where(client_id: nil, contractor_id: nil, invoice_number: invoice_number).exists?
        errors.add(:invoice_number, "is al in gebruik")
      end
    end
  end
end
