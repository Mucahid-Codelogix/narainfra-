class DebitInvoiceQuoteDetail < ApplicationRecord
  belongs_to :debit_invoice_quote, optional: true

  def calculate_debit_invoice_quote_detail_total_amount_sum(invoice)
    invoice_details = invoice.debit_invoice_quote_details
    if invoice_details.present?
      invoice_details.sum(:total_amount)
    else
      0
    end
  end
end
