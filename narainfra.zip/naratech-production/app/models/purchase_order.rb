class PurchaseOrder < ApplicationRecord
  belongs_to :project
  belongs_to :specification_code, optional: true
  belongs_to :week
end
