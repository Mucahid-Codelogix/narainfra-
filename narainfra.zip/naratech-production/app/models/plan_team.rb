class PlanTeam < ApplicationRecord
  belongs_to :plan
  belongs_to :team
end
