class DebitInvoiceQuote < ApplicationRecord
  belongs_to :client
  has_one_attached :invoice_pdf

  has_many :debit_invoice_quote_details, dependent: :destroy

  validates :quote_number, presence: true, uniqueness: true
  # validates_uniqueness_of :client_id, scope: [:project_id, :week_id], message: I18n.t('activerecord.errors.models.invoice.attributes.client.taken')

  def euro_format(amount)
    if amount.to_f < 0
      ActionController::Base.helpers.number_to_currency(-1 * amount.to_f, unit: "€", format: "%u -%n")
    else
      ActionController::Base.helpers.number_to_currency(amount, unit: "€", format: "%u %n")
    end
  end

  def format_number(amount)
    integer_part, decimal_part = ("%.2f" % amount).split(".")
    integer_part.gsub!(/\d(?=(...)+$)/, '\0.')
    "#{integer_part},#{decimal_part}"
  end
end
