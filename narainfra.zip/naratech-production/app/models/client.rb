class Client < ApplicationRecord
  has_many :specification_codes, dependent: :destroy
  has_many :projects, dependent: :destroy
  has_many :client_contact_persons, dependent: :destroy
  has_many :invoices, dependent: :destroy
  has_many :debit_invoices, dependent: :destroy
  has_many :debit_invoice_quotes, dependent: :destroy

  has_many :employees_clients, dependent: :destroy
  has_many :employees, through: :employees_clients
  has_many :disciplines, dependent: :destroy
  has_one :finance, dependent: :destroy

  validates :client_id, presence: true, uniqueness: true
  validates :client_name, presence: true
  validates :email, presence: true, uniqueness: true

  def euro_format(amount)
    ActionController::Base.helpers.number_to_currency(amount, unit: "€", format: "%u %n")
  end

  def format_number(amount)
    integer_part, decimal_part = ("%.2f" % amount).split(".")
    integer_part.gsub!(/\d(?=(...)+$)/, '\0.')
    "#{integer_part},#{decimal_part}"
  end
end
