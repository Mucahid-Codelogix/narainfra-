class ProjectsController < ApplicationController
  def index
    @projects = Project.includes(:plans, :activities, :weeks).all
    data = []

    @projects.map do |project|
      plans = []
      project.plans.map do |plan|
        teams = PlanTeam.includes(:team).where(plan: plan)
        plans.append({ id: plan.id,
                       plan_start_date: plan.start_week.start_date,
                       plan_end_date: plan.end_week.end_date,
                       activity_name: plan.activity.activity_name,
                       activity_color: plan.activity.color,
                       teams: teams.map { |plan_team| plan_team.team.team_name } })
      end

      data.append({ project: project, activities: plans })
    end

    render json: data, status: :ok
  end
end
