//= require_tree .
var url = null;
var activeDisciplineId = "all";
var activeCode = "open";
var vat = null;
var vatReversed = null;
var selectTypeInvoice = "contractor";
var selectedVatValue = 0;
var totalAmountInvoice = 0;
let specificationCodesData = [];
let selectedSpecificationCodeIds = [];
let test = "imran";
var dateFieldEndDate = null;
var dateFieldStartDate = null;
var endDatePicker = null;
var startDatePicker = null;
var duplicateClientNames = [];
$(document).on("turbolinks:load", function () {
  dateFieldEndDate = $("#project_end_date");
  endDatePicker = flatpickr(dateFieldEndDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    weekNumbers: true,
    onChange: function (selectedDates, dateStr, instance) {
      // Re-open the date picker after a date is selected
      // instance.open();
    },
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
  dateFieldStartDate = $("#project_start_date");
  startDatePicker = flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    weekNumbers: true,
    onChange: function (selectedDates, dateStr, instance) {
      // dateFieldEndDate.focus();
      setTimeout(function () {
        dateFieldEndDate.focus();
        endDatePicker.open();
      }, 100);
    },
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
  specificationCodesData = [];
  selectedSpecificationCodeIds = [];
  vat = null;
  if (activeDisciplineId) {
    $(".discipline-filter")
      .filter(function () {
        return $(this).data("discipline-id") == activeDisciplineId;
      })
      .addClass("active");
  }

  if (activeCode) {
    $(".code-filter")
      .filter(function () {
        return $(this).data("code") == activeCode;
      })
      .addClass("active");
  }
  //for descrease loading time
  //search bar functionality
  url = new URL(window.location.href);
  if (url) {
    // console.log("url is here", url.searchParams.get("tab"));
    var tab = url.searchParams.get("tab");
    var code = url.searchParams.get("code");
    var search = url.searchParams.get("search");
    if (code) {
      $("#search-field-code").val(search);
    } else if (tab == "weeks") {
      $("#search-field-weeks").val(search);
    } else {
      $("#search-field-employee-scheduling").val(search);
    }

    if (tab == "SpecificationCode") {
      getSpecficationCodeData();
    }
  }

  $(".btn-new-resource").on("click", function (e) {
    $(".create-project-container").addClass("disabled");
    $(".create-project-container .modal").css("display", "block");
    localStorage.setItem("create-project-modal", "true");
  });

  $(".nav-item").click(function (e) {
    activeCode = "open";
    activeDisciplineId = "all";
    localStorage.setItem("activeButtonState", "");
    let localCodesData = localStorage.getItem("myData");

    const location = e.target.href.split("#")[1];
    if (location.substring(4) === "SpecificationCode") {
      let parsedData = [];
      let codeIds = "";
      if (localCodesData) {
        parsedData = JSON.parse(localCodesData);
        var pathArray = window.location.pathname.split("/");
        var projectId = pathArray[3];
        parsedData = parsedData.filter((item) => item.project_id == projectId);
        codeIds = parsedData.map((item) => item.code_id).join(",");
      }

      Turbolinks.visit(
        `${window.location.pathname}?tab=${location.substring(
          4
        )}&code=active&discipline=${activeDisciplineId}&codes=${codeIds}#!${location}`,
        { action: "replace" }
      );
    } else {
      Turbolinks.visit(
        `${window.location.pathname}?tab=${location.substring(4)}#!${location}`,
        { action: "replace" }
      );
    }
  });

  // $("#all-codes").on("click", function (e) {
  //   var routeName = $("#all-codes").data("route");
  //   if (routeName === "weeks") {
  //     Turbolinks.visit(
  //       `${window.location.pathname}?tab=weeks&code=allcodes#!tab-weeks`,
  //       { action: "replace" }
  //     );
  //   } else if (routeName === "tkc") {
  //     Turbolinks.visit(
  //       `${window.location.pathname}?tab=Tkc&code=allcodes#!tab-Tkc`,
  //       { action: "replace" }
  //     );
  //   }

  //   localStorage.setItem("activeButtonState", "all-codes");
  //   $(this).addClass("active-button");
  // });

  // $("#tkc-pdf-send").on("click", function (e) {
  //   Turbolinks.visit(
  //     `${window.location.pathname}?tab=Tkc&code=tkcsend#!tab-Tkc`,
  //     { action: "replace" }
  //   );
  //   localStorage.setItem("activeButtonState", "tkc-send");
  //   $(this).addClass("active-button");
  // });
  // $("#tkc-pdf-approved").on("click", function (e) {
  //   Turbolinks.visit(
  //     `${window.location.pathname}?tab=Tkc&code=tkcapproved#!tab-Tkc`,
  //     { action: "replace" }
  //   );
  //   localStorage.setItem("activeButtonState", "tkc-approved");
  //   $(this).addClass("active-button");
  // });
  // $("#pdf-send").on("click", function (e) {
  //   Turbolinks.visit(
  //     `${window.location.pathname}?tab=weeks&code=pdfsend#!tab-weeks`,
  //     { action: "replace" }
  //   );
  //   localStorage.setItem("activeButtonState", "pdf-send");
  //   $(this).addClass("active-button");
  // });
  // $("#pdf-approved").on("click", function (e) {
  //   Turbolinks.visit(
  //     `${window.location.pathname}?tab=weeks&code=pdfapproved#!tab-weeks`,
  //     { action: "replace" }
  //   );
  //   localStorage.setItem("activeButtonState", "pdf-approved");
  //   $(this).addClass("active-button");
  // });

  $("#inactive-spec-code-button").on("click", function (e) {
    if (activeDisciplineId) {
      Turbolinks.visit(
        `${window.location.pathname}?tab=SpecificationCode&code=inactive&discipline=${activeDisciplineId}#!tab-SpecificationCode`,
        { action: "replace" }
      );
    } else {
      Turbolinks.visit(
        `${window.location.pathname}?tab=SpecificationCode&code=inactive#!tab-SpecificationCode`,
        { action: "replace" }
      );
    }
    localStorage.setItem("activeButtonState", "inactive");
    $(this).addClass("active-button");
  });
  $("#active-spec-code-button").on("click", function (e) {
    let localCodesData = localStorage.getItem("myData");
    let parsedData = [];
    let codeIds = "";
    if (localCodesData) {
      parsedData = JSON.parse(localCodesData);
      var pathArray = window.location.pathname.split("/");
      var projectId = pathArray[3];
      parsedData = parsedData.filter((item) => item.project_id == projectId);
      codeIds = parsedData.map((item) => item.code_id).join(",");
    }
    if (activeDisciplineId) {
      Turbolinks.visit(
        `${window.location.pathname}?tab=SpecificationCode&code=active&discipline=${activeDisciplineId}&codes=${codeIds}#!tab-SpecificationCode`,
        { action: "replace" }
      );
    } else {
      Turbolinks.visit(
        `${window.location.pathname}?tab=SpecificationCode&code=active&codes=${codeIds}#!tab-SpecificationCode`,
        { action: "replace" }
      );
    }

    localStorage.setItem("activeButtonState", "active");
    $(this).addClass("active-button");
  });

  // Add a click event listener to the modal overlay
  // modalOverlay.addEventListener("click", function (event) {

  // });

  const activeButtonState = localStorage.getItem("activeButtonState");
  if (activeButtonState === "active") {
    $("#active-spec-code-button").addClass("active-button");
    $("#inactive-spec-code-button").removeClass("active-button");
  } else if (activeButtonState === "inactive") {
    $("#inactive-spec-code-button").addClass("active-button");
    $("#active-spec-code-button").removeClass("active-button");
  }

  // else if (activeButtonState === "tkc-send") {
  //   $("#tkc-pdf-send").addClass("active-button");
  //   $("#tkc-pdf-approved").removeClass("active-button");
  //   $("#pdf-send").removeClass("active-button");
  //   $("#pdf-approved").removeClass("active-button");
  //   $("#all-codes").removeClass("active-button");
  // } else if (activeButtonState === "tkc-approved") {
  //   $("#tkc-pdf-send").removeClass("active-button");
  //   $("#tkc-pdf-approved").addClass("active-button");
  //   $("#pdf-send").removeClass("active-button");
  //   $("#pdf-approved").removeClass("active-button");
  //   $("#all-codes").removeClass("active-button");
  // } else if (activeButtonState === "pdf-send") {
  //   $("#tkc-pdf-send").removeClass("active-button");
  //   $("#tkc-pdf-approved").removeClass("active-button");
  //   $("#pdf-send").addClass("active-button");
  //   $("#pdf-approved").removeClass("active-button");
  //   $("#all-codes").removeClass("active-button");
  // } else if (activeButtonState === "pdf-approved") {
  //   $("#tkc-pdf-send").removeClass("active-button");
  //   $("#tkc-pdf-approved").removeClass("active-button");
  //   $("#pdf-send").removeClass("active-button");
  //   $("#pdf-approved").addClass("active-button");
  //   $("#all-codes").removeClass("active-button");
  // } else if (activeButtonState === "all-codes") {
  //   $("#tkc-pdf-send").removeClass("active-button");
  //   $("#tkc-pdf-approved").removeClass("active-button");
  //   $("#pdf-send").removeClass("active-button");
  //   $("#pdf-approved").removeClass("active-button");
  //   $("#all-codes").addClass("active-button");
  // }

  //disable total overview table
  $(".total-overview-table tr").each(function () {
    $(this).removeAttr("data-url");
    $(this).css("cursor", "default"); // Change the cursor style to indicate that the row is not clickable
  });

  $(".employee-scheduling-table tr").each(function () {
    $(this).removeAttr("data-url");
    $(this).css("cursor", "default"); // Change the cursor style to indicate that the row is not clickable
  });

  $("#project-specification-code-table tr").each(function () {
    $(this).removeAttr("data-url");
    $(this).css("cursor", "default"); // Change the cursor style to indicate that the row is not clickable
  });

  var modalButton = $(".modal").find(".btn");
  modalButton.on("click", function () {});

  // for update the excel file for client
  var label = $("#import-specification-codes");
  var fileInput = $("#excel-file");

  label.on("click", function () {
    fileInput.click();
  });

  fileInput.on("change", function (e) {
    var disciplineId = label.data("discipline-id");
    var file = e.target.files[0];
    var formData = new FormData();
    formData.append("excel_file", file);
    $("#loader-overlay").show();

    $.ajax({
      url: "/admin/disciplines/" + disciplineId + "/import_specification_codes",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        $("#loader-overlay").hide();
      },
      error: function (error) {
        label.text("Importeer Specificatiecodes");
      },
    });
  });

  //for the specificaion code in tkc cost

  //for select specificaiton code in employee scheduling
  const includeSpecificationCodeCheckbox = $(
    "input[name='employee_scheduling[include_specification_code]']"
  );
  const specificationCodeSelect = $(
    ".col-sm-4:has(#employee_scheduling_specification_code_id)"
  );

  if (includeSpecificationCodeCheckbox) {
    if (includeSpecificationCodeCheckbox.is(":checked")) {
      specificationCodeSelect.show();
    } else {
      specificationCodeSelect.hide();
    }
  }

  $(document).on(
    "change",
    "input[name='employee_scheduling[include_specification_code]']",
    function () {
      const includeSpecificationCodeCheckbox = $(
        "input[name='employee_scheduling[include_specification_code]']"
      );
      const specificationCodeSelect = $(
        ".col-sm-4:has(#employee_scheduling_specification_code_id)"
      );
      if ($(includeSpecificationCodeCheckbox).is(":checked")) {
        specificationCodeSelect.show();
      } else {
        specificationCodeSelect.hide();
      }
    }
  );
  $(document).on("change", "input[name='project[tbs]']", function () {
    const tbsProject = $("input[name='project[tbs]']");
    let projectFieldHide = $(".project-field-hide");
    const contractSumField = $(".col-class-project-contract-sum-hide");

    const contractSum = $("input[name='project[contract_sum]']");
    if ($(tbsProject).is(":checked")) {
      projectFieldHide.css("display", "none");
      contractSumField.css("display", "none");
      contractSum.prop("checked", false);
    } else {
      projectFieldHide.css("display", "flex");
      contractSumField.css("display", "none");
    }
  });

  $(document).on("change", "input[name='project[contract_sum]']", function () {
    const tbsProject = $("input[name='project[tbs]']");
    const contractSum = $("input[name='project[contract_sum]']");
    let projectFieldHide = $(".project-field-hide");
    const contractSumField = $(".col-class-project-contract-sum-hide");

    if ($(contractSum).is(":checked")) {
      tbsProject.prop("checked", false);
      projectFieldHide.css("display", "flex");
      contractSumField.css("display", "block");
    } else {
      projectFieldHide.css("display", "flex");
      contractSumField.css("display", "none");
    }
  });

  const selectAllCheckbox = document.querySelector(".select-all-checkbox");
  let checkboxes = document.querySelectorAll(".select-checkbox");
  const deleteButton = document.getElementById("delete-specification-codes");

  function updateDeleteButtonVisibility() {
    if (document.querySelectorAll(".select-checkbox:checked").length > 0) {
      deleteButton.style.display = "inline-block";
    } else {
      deleteButton.style.display = "none";
    }
  }

  selectAllCheckbox.addEventListener("change", () => {
    checkboxes = document.querySelectorAll(".select-checkbox");
    checkboxes.forEach((checkbox) => {
      checkbox.checked = selectAllCheckbox.checked;
    });
    updateDeleteButtonVisibility();
    addEveentListnerToEveryCheckBox();
  });

  function addEveentListnerToEveryCheckBox() {
    checkboxes.forEach((checkbox) => {
      checkbox.addEventListener("change", () => {
        const allChecked = Array.from(checkboxes).every((cb) => cb.checked);
        selectAllCheckbox.checked = allChecked;
        updateDeleteButtonVisibility();
      });
    });
  }

  $(document).on(
    "click",
    ".edit_discipline .pagination .page-link",
    function () {
      setTimeout(() => {
        checkboxes = document.querySelectorAll(".select-checkbox");
        checkboxes.forEach((checkbox) => {
          checkbox.checked = selectAllCheckbox.checked;
        });
        addEveentListnerToEveryCheckBox();
        updateDeleteButtonVisibility();
      }, [500]);
    }
  );
  addEveentListnerToEveryCheckBox();

  $(document).on("click", "#delete-specification-codes", function () {
    let selectedCodes = $(".select-checkbox:checked")
      .map(function () {
        return $(this).val();
      })
      .get();

    if (selectedCodes.length > 0) {
      let buttonOffset = $(this).offset();
      let buttonHeight = $(this).outerHeight();

      $("#delete-confirmation-popover").css({
        top: 25,
        left: -211,
        display: "block",
        opacity: 1,
      });
    }
    $(".trestle-table tbody tr").css("pointer-events", "none");
  });

  $(document).on(
    "click",
    "#confirm-delete-specificaion-codes",
    function (event) {
      event.preventDefault();
      event.stopPropagation();
      let selectedCodes = $(".select-checkbox:checked")
        .map(function () {
          return $(this).val();
        })
        .get();

      let disciplineId = $("#delete-specification-codes").data("discipline-id");
      let clientId = $("#delete-specification-codes").data("client-id");
      // let selectAllCheckbox = $("#select-all-checkbox").is(":checked");

      $("#loader-overlay").show();

      $.ajax({
        url:
          "/admin/disciplines/" +
          disciplineId +
          "/delete_multiple_specification_codes",
        type: "POST",
        data: {
          specification_codes: selectedCodes,
          select_all_codes: selectAllCheckbox.checked,
        },
        success: function (response) {
          location.reload();
        },
        error: function (error) {
          console.log("error is here", error);
        },
      });

      // Hide the confirmation popover
      $("#delete-confirmation-popover").hide();
      $(".trestle-table tbody tr").css("pointer-events", "");
    }
  );

  $(document).on(
    "click",
    "#cancel-delete-specificaion-codes",
    function (event) {
      event.preventDefault(); // Prevent the default behavior of the button
      event.stopPropagation(); // Stop the event from bubbling up the DOM
      // Hide the confirmation popover
      $("#delete-confirmation-popover").hide();
      $(".trestle-table tbody tr").css("pointer-events", "");
    }
  );

  // correct code
  // $(document).on("click", "#delete-specification-codes", function () {
  //   let selectedCodes = $(".select-checkbox:checked")
  //     .map(function () {
  //       return $(this).val();
  //     })
  //     .get();
  //   if (selectedCodes.length > 0) {
  //     $("#loader-overlay").show();
  //     let disciplineId = $("#delete-specification-codes").data("discipline-id");
  //     let clientId = $("#delete-specification-codes").data("client-id");

  //     $.ajax({
  //       url:
  //         "/admin/disciplines/" +
  //         disciplineId +
  //         "/delete_multiple_specification_codes",
  //       type: "POST",
  //       data: {
  //         specification_codes: selectedCodes,
  //         select_all_codes: selectAllCheckbox.checked,
  //       },
  //       success: function (response) {
  //         location.reload();
  //       },
  //       error: function (error) {
  //         console.log("error is here", error);
  //         // label.text("Importeer Specificatiecodes");
  //       },
  //     });
  //   }
  // });
});
$(document).on(
  "click",
  ".modal #edit_contractor .create_contractor_finance",
  function (event) {
    event.preventDefault();
    const vat_number = $("#finance_vat_number").val();
    const kvk_number = $("#finance_kvk_number").val();
    const finance_vat = $("#finance_vat").val();
    const finance_c_account_percentage = $(
      "#finance_c_account_percentage"
    ).val();
    const finance_g_account_percentage = $(
      "#finance_g_account_percentage"
    ).val();
    const finance_payment_term_value = $("#finance_payment_term_value").val();
    const finace_g_account_percentage_hidden = $(
      "#g_account_percentage_hidden"
    ).val();
    const finance_vat_reversed = $("#finance_vat_reversed").is(":checked");
    const iban = $("#finance_iban").val();
    const data = {
      vat_number,
      kvk_number,
      finance_vat,
      finance_c_account_percentage,
      finance_g_account_percentage,
      finance_payment_term_value,
      finace_g_account_percentage_hidden,
      finance_vat_reversed,
      iban,
    };
    $.ajax({
      url: "/admin/invoices/create_contractor_finance",
      type: "GET",
      data: data,
      dataType: "json",
      success: function (response) {
        if (response.status === "error") {
          showAlertErrorInModal(response.message);
        } else {
          $(".modal.fade.show").modal("hide");
        }
      },
      error: function (error) {
        showAlertErrorInModal(response.message);
        console.log("Error retrieving weeks: " + error);
      },
    });
  }
);

$(document).on(
  "click",
  ".modal #edit_client .btn-modal-finance",
  function (event) {
    event.preventDefault();
    const vat_number = $("#finance_vat_number").val();
    const kvk_number = $("#finance_kvk_number").val();
    const finance_vat = $("#finance_vat").val();
    const finance_c_account_percentage = $(
      "#finance_c_account_percentage"
    ).val();
    const finance_g_account_percentage = $(
      "#finance_g_account_percentage"
    ).val();
    const finance_payment_term_value = $("#finance_payment_term_value").val();
    const finace_g_account_percentage_hidden = $(
      "#g_account_percentage_hidden"
    ).val();
    const finance_vat_reversed = $("#finance_vat_reversed").is(":checked");
    const data = {
      vat_number,
      kvk_number,
      finance_vat,
      finance_c_account_percentage,
      finance_g_account_percentage,
      finance_payment_term_value,
      finace_g_account_percentage_hidden,
      finance_vat_reversed,
    };
    $.ajax({
      url: "/admin/invoices/create_finance",
      type: "GET",
      data: data,
      dataType: "json",
      success: function (response) {
        if (response.status === "error") {
          showAlertErrorInModal(response.message);
        } else {
          $(".modal.fade.show").modal("hide");
        }
      },
      error: function (error) {
        showAlertErrorInModal(response.message);
        console.log("Error retrieving weeks: " + error);
      },
    });
  }
);

$(document).on(
  "click",
  ".modal .edit_contractor a[href='#tab-modal-Finance']",
  function (event) {
    $(".tab-modal-Finance add-finance-button").css("display", "none");
    $(".tab-modal-Finance table-container").css("display", "none");

    $("#edit_contractor .btn-toolbar").css("display", "none");
    var newContent = `<div class="row">
  <div class="col-sm-4">
    <div class="form-group">
    <label class="control-label" for="finance_vat_number">BTW-nummer</label>
    <input class="form-control" type="text" name="finance[vat_number]" id="finance_vat_number"></div>
  </div>
  <div class="col-sm-4">
    <div class="form-group">
    <label class="control-label" for="finance_kvk_number">Kvk-nummer</label>
    <input class="form-control" min="0" type="number" name="finance[kvk_number]" id="finance_kvk_number"></div>
  </div>
  <div class="col-sm-4">
    <div class="form-group"><label class="control-label" for="finance_vat">BTW</label>
    <input class="form-control" min="0" type="number" value="21.0" name="finance[vat]" id="finance_vat"></div>
  </div>
</div>
<div class="row">
  <div class="col-sm-4">
    <div class="form-group"><label class="control-label" for="finance_c_account_percentage">C-Rekening</label>
    <input class="form-control" min="0" type="number" value="0.0" name="finance[c_account_percentage]" id="finance_c_account_percentage"></div>
  </div>
  <div class="col-sm-4">
    <div class="form-group"><label class="control-label" for="finance_g_account_percentage">G-Rekening</label>
    <input class="form-control" min="0" disabled="disabled" type="number" value="0.0" name="finance[g_account_percentage]" id="finance_g_account_percentage"></div>
  </div>
  <div class="col-sm-4">
    <div class="form-group"><label class="control-label" for="finance_payment_term_value">Betaaltermijn</label>
    <input class="form-control" min="0" type="number" value="30" name="finance[payment_term_value]" id="finance_payment_term_value"></div>
  </div>
  <input id="g_account_percentage_hidden" autocomplete="off" type="hidden" value="0.0" name="finance[g_account_percentage]">
</div>
<div class="row">
<div class="col-sm-4">
    <div class="form-group">
    <label class="control-label" for="finance_vat_number">IBAN</label>
    <input class="form-control" type="text" name="finance[iban]" id="finance_iban"></div>
  </div>
</div>
<div class="row">
  <div class="col-sm-12">
    <div><strong>BTW verlegd</strong> <i class="fas fa-question-circle" style="color:blue;"></i></div>
  </div>
</div>
<div class="row">
  <div class="col-sm-4">
    <div class="custom-control custom-checkbox">
    <input name="finance[vat_reversed]" type="hidden" value="0" autocomplete="off"><input label="Ja" class="custom-control-input" type="checkbox" value="1" name="finance[vat_reversed]" id="finance_vat_reversed"><label class="custom-control-label" for="finance_vat_reversed">Ja</label></div>
  </div>
</div>
<div class="modal-footer">
  <div class="btn-toolbar secondary-toolbar" role="toolbar">
    
    
  </div>

  <div class="btn-toolbar primary-toolbar" role="toolbar">
    <button name="button" type="submit" class="btn btn-success create_contractor_finance"><span class="btn-label">Bankgegeven opslaan</span></button>
    
  </div>
</div>
  `;

    $("#tab-modal-Finance").html(newContent);
  }
);

$(document).on(
  "click",
  ".modal .edit_client a[href='#tab-modal-Finance']",
  function (event) {
    $(".tab-modal-Finance add-finance-button").css("display", "none");
    $(".tab-modal-Finance table-container").css("display", "none");

    $("#edit_client .btn-toolbar").css("display", "none");
    var newContent = `<div class="row">
  <div class="col-sm-4">
    <div class="form-group">
    <label class="control-label" for="finance_vat_number">BTW-nummer</label>
    <input class="form-control" type="text" name="finance[vat_number]" id="finance_vat_number"></div>
  </div>
  <div class="col-sm-4">
    <div class="form-group">
    <label class="control-label" for="finance_kvk_number">Kvk-nummer</label>
    <input class="form-control" min="0" type="number" name="finance[kvk_number]" id="finance_kvk_number"></div>
  </div>
  <div class="col-sm-4">
    <div class="form-group"><label class="control-label" for="finance_vat">BTW</label>
    <input class="form-control" min="0" type="number" value="21.0" name="finance[vat]" id="finance_vat"></div>
  </div>
</div>
<div class="row">
  <div class="col-sm-4">
    <div class="form-group"><label class="control-label" for="finance_c_account_percentage">C-Rekening</label>
    <input class="form-control" min="0" type="number" value="0.0" name="finance[c_account_percentage]" id="finance_c_account_percentage"></div>
  </div>
  <div class="col-sm-4">
    <div class="form-group"><label class="control-label" for="finance_g_account_percentage">G-Rekening</label>
    <input class="form-control" min="0" disabled="disabled" type="number" value="0.0" name="finance[g_account_percentage]" id="finance_g_account_percentage"></div>
  </div>
  <div class="col-sm-4">
    <div class="form-group"><label class="control-label" for="finance_payment_term_value">Betaaltermijn</label>
    <input class="form-control" min="0" type="number" value="30" name="finance[payment_term_value]" id="finance_payment_term_value"></div>
  </div>
  <input id="g_account_percentage_hidden" autocomplete="off" type="hidden" value="0.0" name="finance[g_account_percentage]">
</div>
<div class="row">
  <div class="col-sm-12">
    <div><strong>BTW verlegd</strong> <i class="fas fa-question-circle" style="color:blue;"></i></div>
  </div>
</div>
<div class="row">
  <div class="col-sm-4">
    <div class="custom-control custom-checkbox">
    <input name="finance[vat_reversed]" type="hidden" value="0" autocomplete="off"><input label="Ja" class="custom-control-input" type="checkbox" value="1" name="finance[vat_reversed]" id="finance_vat_reversed"><label class="custom-control-label" for="finance_vat_reversed">Ja</label></div>
  </div>
</div>
<div class="modal-footer">
  <div class="btn-toolbar secondary-toolbar" role="toolbar">
    
    
  </div>

  <div class="btn-toolbar primary-toolbar" role="toolbar">
    <button name="button" type="submit" class="btn btn-success btn-modal-finance"><span class="btn-label">Bankgegeven opslaan</span></button>
    
  </div>
</div>
  `;

    $("#tab-modal-Finance").html(newContent);
  }
);

$(document).on(
  "click",
  "a[href='#tab-modal-client_details']",
  function (event) {
    $("#edit_client .btn-toolbar").css("display", "block");
  }
);

$(document).on("click", ".modal #new_project .btn", function (event) {
  try {
    event.preventDefault();
    const tbs = $("input[name='project[tbs]']").is(":checked");
    const project_archived = $("input[name='project[archived]']").is(
      ":checked"
    );
    const projectnumber = $("#project_projectnumber").val();
    const projectleader = $("#project_projectleader").val();
    const projectperformer = $("#project_projectperformer").val();
    const contactpersoon = $("#project_contactpersoon").val();
    const place = $("#project_place").val();
    const supervisor = $("#project_supervisor").val();
    const address = $("#project_address").val();
    const zip_code = $("#project_zip_code").val();
    const project_start_date = $("#project_start_date").val();
    const project_end_date = $("#project_end_date").val();
    const client_id = $("#project_client_id").val();
    const discipline_ids = $("#project_discipline_ids").val();
    const data = {
      projectnumber,
      projectleader,
      projectperformer,
      contactpersoon,
      place,
      supervisor,
      address,
      zip_code,
      project_start_date,
      project_end_date,
      client_id,
      tbs,
      project_archived,
      discipline_ids,
    };
    $("#loader-overlay").show();
    $.ajax({
      url: "/admin/employee_schedulings/create_projects",
      type: "GET",
      data: data,
      dataType: "json",
      success: function (response) {
        project = response.project;
        if (project && response.status) {
          const project_select_box = $("#employee_scheduling_project_id");
          project_select_box.append(
            $("<option>", {
              value: project.id,
              text: project.projectnumber,
            })
          );
          $("#loader-overlay").hide();
          $(".modal.fade.show").modal("hide");
        } else {
          $("#loader-overlay").hide();
          showAlertErrorInModal(response.message);
        }
      },
      error: function (error) {
        $("#loader-overlay").hide();
        showAlertErrorInModal(error);
        console.log("Error retrieving weeks: " + error);
      },
    });
  } catch (error) {
    console.log("error in creating project===>", error);
  }
});

//for employee scheduling

$(document).on("change", "#employee_scheduling_project_id", function () {
  var selected_project = $("#employee_scheduling_project_id");
  var selected_project_id = selected_project.val();
  getWeeks(selected_project_id);
});

$(document).on("change", "#employee_scheduling_week_id", function () {
  var selected_week = $("#employee_scheduling_week_id");
  var selected_week_id = selected_week.val();
  getDays(selected_week_id);
  verificationSchedulingOtherProject();
});

$(document).on("change", "#employee_scheduling_employee_id", function () {
  var selected_employee = $("#employee_scheduling_employee_id");
  var selected_employee_id = selected_employee.val();
  getRate(selected_employee_id);
  verificationSchedulingOtherProject();
});

// for week status
var modal = $(".modal");
var modalOverlay = $(".modal.fade.show");
$(document).on("click", ".modal", function (event) {
  event.stopPropagation();
});

$(document).on("change", "select[id^='week-status-select-']", function () {
  var selected_status = $(this);
  var selected_status_value = selected_status.val();
  var weekId = selected_status.attr("id").split("-").pop();

  if (
    selected_status_value === "pending" ||
    selected_status_value === "In afwachting"
  ) {
    // Show the modal associated with the specific week using weekId
    $(".week-status-note-" + weekId + " .modal").css("display", "block");
  }
});

$(document).on(
  "click",
  "button[id^='week-status-note-confirm-modal-']",
  function (event) {
    var selected_status = $(this);
    var weekId = selected_status.attr("id").split("-").pop();
    var weekNote = selected_status
      .closest(".week-note")
      .find("input[id^='week-note-']")
      .val();

    if (weekNote && weekId) {
      $.ajax({
        url: `/admin/projects/update_pending_status`,
        type: "POST",
        data: {
          note: weekNote,
          id: weekId,
        },
        dataType: "json",
        success: function (response) {
          if (response) {
            hideDialogBox();
          }
        },
        error: function (error) {
          console.log("Error retrieving weeks: " + error);
        },
      });
    }

    // event.stopPropagation();
  }
);

$(document).on(
  "click",
  "button[id^='close-week-status-note-']",
  function (event) {
    // event.stopPropagation();
    hideDialogBox();
  }
);

// $(document).on("change", "#week-status-select", function () {
//   var selected_status = $("#week-status-select");
//   var selected_status = selected_status.val();
//   if (selected_status === "pending") {
//     $(".week-status-note .modal").css("display", "block");
//   }
// });

// $(document).on("click", "#week-status-note-confirm-modal", function (event) {
//   event.stopPropagation()
//   hideDialogBox();
// });

// $(document).on("click", ".close-week-status-note", function (event) {
//   event.stopPropagation()
//   hideDialogBox();
// });

function verificationSchedulingOtherProject() {
  var selected_employee = $("#employee_scheduling_employee_id");
  var selected_week = $("#employee_scheduling_week_id");
  var selected_employee_id = selected_employee.val();
  var selected_week_id = selected_week.val();
  if (selected_week_id && selected_employee_id) {
    $.ajax({
      url: "/admin/employee_schedulings/varificaion_scheduling_other_projects",
      type: "GET",
      data: {
        week_id: selected_week_id,
        employee_id: selected_employee_id,
      },
      dataType: "json",
      success: function (response) {
        if (response.conflict) {
          localStorage.setItem("create-project-modal", "");
          $(".warning .modal").css("display", "block");
        }
      },
      error: function (error) {
        console.log("Error retrieving weeks: " + error);
      },
    });
  }
}

function getWeeks(id) {
  var weekSelect = document.getElementById("employee_scheduling_week_id");
  var place = document.getElementById("employee_scheduling_place");
  var executor = document.getElementById("employee_scheduling_executor");
  var client = document.getElementById("employee_scheduling_client");
  var projectAddress = document.getElementById(
    "employee_scheduling_project_address"
  );

  var selectSelectedCode = document.getElementById(
    "employee_scheduling_specification_code_id"
  );
  $.ajax({
    url: "/admin/employee_schedulings/fetch_weeks_and_codes",
    type: "GET",
    data: {
      id: id,
    },
    dataType: "json",
    success: function (response) {
      var project = response.project;
      let projectFieldHide = $(".col-class-project-field-hide");
      if (project.tbs) {
        projectFieldHide.css("display", "none");
      } else {
        projectFieldHide.css("display", "block");
      }
      var clientDetails = response.client;
      place.value = project.place;
      executor.value = project.projectperformer;
      client.value = clientDetails.client_name;
      projectAddress.value = project.address;
      var weeks = response.weeks || [];
      var codes = response.specification_codes;
      weekSelect.innerHTML = "";
      weeks.forEach((week) => {
        const option = document.createElement("option");
        option.value = week.id;
        option.textContent = week.week_number;
        weekSelect.appendChild(option);
      });
      selectSelectedCode.innerHTML = "";

      codes.forEach((code) => {
        const option = document.createElement("option");
        option.value = code.id;
        option.textContent = `${code.specification_code} - ${code.description}`;
        selectSelectedCode.appendChild(option);
      });
      days = response.days;
      sortDays(days);
    },
    error: function (error) {
      console.log("Error retrieving weeks: " + error);
    },
  });
}

function getDays(id) {
  var current_language = $("#week-project-field").data("local");
  const dayOrder = [
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
    "sunday",
  ];
  let dayNames = {};
  if (current_language == "nl") {
    dayNames = {
      sunday: "Zondag",
      monday: "Maandag",
      tuesday: "Dinsdag",
      wednesday: "Woensdag",
      thursday: "Donderdag",
      friday: "Vrijdag",
      saturday: "Zaterdag",
    };
  } else {
    dayNames = {
      sunday: "sunday",
      monday: "monday",
      tuesday: "tuesday",
      wednesday: "wednesday",
      thursday: "thursday",
      friday: "friday",
      saturday: "saturday",
    };
  }

  $.ajax({
    url: "/admin/employee_schedulings/fetch_days",
    type: "GET",
    data: {
      id: id,
    },
    dataType: "json",
    success: function (response) {
      var days = response.days;
      if (days) {
        sortDays(days);
      }
    },
    error: function (error) {
      console.log("Error retrieving weeks: " + error);
    },
  });
}

function getRate(id) {
  $.ajax({
    url: "/admin/employee_schedulings/get_rate",
    type: "GET",
    data: {
      id: id,
    },
    dataType: "json",
    success: function (response) {
      var rate = response.rate;
      var employeeRole = response.employee_role;
      if (rate) {
        var employee_rate = $("#employee_scheduling_rate");

        employee_rate.val(rate);
        var rateHiddenField = $("#employee_scheduling_rate_hidden");
        rateHiddenField.val(rate);
      }
      if (employeeRole) {
        var employee_role = $("#employee_scheduling_employee_role");
        employee_role.val(employeeRole);
      }
    },
    error: function (error) {
      console.log("Error retrieving weeks: " + error);
    },
  });
}

function sortDays(days) {
  var current_language = $("#week-project-field").data("local");
  const dayOrder = [
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
    "sunday",
  ];
  let dayNames = {};
  if (current_language == "nl") {
    dayNames = {
      sunday: "Zondag",
      monday: "Maandag",
      tuesday: "Dinsdag",
      wednesday: "Woensdag",
      thursday: "Donderdag",
      friday: "Vrijdag",
      saturday: "Zaterdag",
    };
  } else {
    dayNames = {
      sunday: "sunday",
      monday: "monday",
      tuesday: "tuesday",
      wednesday: "wednesday",
      thursday: "thursday",
      friday: "friday",
      saturday: "saturday",
    };
  }
  if (days && days.length !== 0) {
    const sortedDays = days.sort((a, b) => {
      const dayIndexA = dayOrder.indexOf(a.day_name.toLowerCase());
      const dayIndexB = dayOrder.indexOf(b.day_name.toLowerCase());

      if (dayIndexA === -1) {
        return 1; // Move missing day to the end
      }
      if (dayIndexB === -1) {
        return -1; // Move missing day to the end
      }

      return dayIndexA - dayIndexB;
    });
    var daysRow = "<div class='days-row'>";
    sortedDays.forEach(function (day) {
      var formattedDate = formatDate(new Date(day.date));
      daysRow += `
            <div class='day-field'>
              <label class='day-label'>${dayNames[day.day_name]}</label>
              <div class='input-container'>
                <input type='number' name='days[${
                  day.day_name
                }][hours]' value='0' class='form-control hours-input' min='0'>
              </div>
              <input type='hidden' name='days[${
                day.day_name
              }][date]' value='${formattedDate}'>
            </div>`;
    });
    daysRow += "</div>";
    $("#days-container").html(daysRow);
  }
}

function formatDate(date) {
  var year = date.getFullYear();
  var month = String(date.getMonth() + 1).padStart(2, "0");
  var day = String(date.getDate()).padStart(2, "0");
  return year + "-" + month + "-" + day;
}

function createExpirationDate(invoiceDateValue, daysAdded) {
  console.log("invoice date===>", invoiceDateValue, daysAdded);
  var dateParts = invoiceDateValue.split("/");
  var day = parseInt(dateParts[0], 10);
  var month = parseInt(dateParts[1], 10) - 1; // Months are zero-indexed
  var year = parseInt(dateParts[2], 10);

  var invoiceDate = new Date(year, month, day);
  invoiceDate.setDate(invoiceDate.getDate() + daysAdded);
  var newDate =
    ("0" + invoiceDate.getDate()).slice(-2) +
    "/" +
    ("0" + (invoiceDate.getMonth() + 1)).slice(-2) +
    "/" +
    invoiceDate.getFullYear();

  console.log("New date after adding 30 days:", newDate);
  return newDate;
}

//for invoices

// $(document).on("ajax:success", ".modal #new_client", function (event){
//   const firstDigit = parseInt(event.detail[2].status.toString()[0]);
//   if (firstDigit == 2) {
//     var intervalId = setInterval(function() {
//       var isClientSelected = $("input[type='radio'][value='client']").prop("checked");
//       if (!isClientSelected) {
//         console.log('Resetting radio button');
//         $("input[type='radio'][value='client']").prop("checked", true);
//         // var selected_contractor = $("#invoice_contractor_id");
//         // selected_contractor.val(null);
//         // selected_contractor.trigger("change.select2");
//         $(".col-class-contractor-select").hide();
//         $(".col-class-client-select").show();

//         $(".create-client-button-invoice-display-none").show();
//         $(".create-contractor-button-invoice-display-none").hide();
//         let invoiceDateValue = $("#invoice_invoice_date").val();

//         $("#invoice_expiration_date").val(invoiceDateValue);
//         $("#invoice_expiration_date_hidden").val(invoiceDateValue);
//       } else {
//         console.log('Radio button is already set to client, stopping interval');
//         clearInterval(intervalId);
//       }
//     }, 100);
//   }
// })
$(document).on("change", ".type-selector", function () {
  $("#invoice-details-table .new-row").remove();
  vat = null;
  vatReversed = null;
  selectTypeInvoice = "contractor";
  selectedVatValue = 0;
  totalAmountInvoice = 0;
  if ($(this).val() === "contractor") {
    var selected_client = $("#invoice_client_id");
    selected_client.val(null);
    selected_client.trigger("change.select2");
    $(".col-class-contractor-select").show();
    $(".col-class-client-select").hide();
    $(".create-client-button-invoice-display-none").hide();
    $(".create-contractor-button-invoice-display-none").show();

    let invoiceDateValue = $("#invoice_invoice_date").val();

    $("#invoice_expiration_date").val(invoiceDateValue);
    $("#invoice_expiration_date_hidden").val(invoiceDateValue);
    $(".col-class-other-select").hide();
    $(".col-class-invoice-description").show();
  } else if ($(this).val() === "client") {
    var selected_contractor = $("#invoice_contractor_id");
    selected_contractor.val(null);
    selected_contractor.trigger("change.select2");
    $(".col-class-contractor-select").hide();
    $(".col-class-client-select").show();

    $(".create-client-button-invoice-display-none").show();
    $(".create-contractor-button-invoice-display-none").hide();
    let invoiceDateValue = $("#invoice_invoice_date").val();

    $("#invoice_expiration_date").val(invoiceDateValue);
    $("#invoice_expiration_date_hidden").val(invoiceDateValue);
    $(".col-class-other-select").hide();
    $(".col-class-invoice-description").show();
  } else {
    var selected_client = $("#invoice_client_id");
    selected_client.val(null);
    selected_client.trigger("change.select2");
    $(".col-class-client-select").hide();
    $(".create-client-button-invoice-display-none").hide();
    var selected_contractor = $("#invoice_contractor_id");
    selected_contractor.val(null);
    selected_contractor.trigger("change.select2");
    $(".col-class-contractor-select").hide();
    $(".create-contractor-button-invoice-display-none").hide();
    let invoiceDateValue = $("#invoice_invoice_date").val();
    $("#invoice_expiration_date").val(invoiceDateValue);
    $("#invoice_expiration_date_hidden").val(invoiceDateValue);
    $(".col-class-other-select").show();
    $(".col-class-invoice-description").hide();
  }
});
$(document).on("change", "#invoice_contractor_id", function () {
  var selected_contractor = $("#invoice_contractor_id");
  var vatValue = $(".vat-hidden-field").val();

  var selected_contractor_id = selected_contractor.val();
  $.ajax({
    url: "/admin/invoices/fetch_finances",
    type: "GET",
    data: {
      contractor_id: selected_contractor_id,
    },
    dataType: "json",
    success: function (response) {
      var financeData = response.finance;
      if (financeData) {
        vat = financeData.vat;
        vatReversed = financeData.vat_reversed;
        paymentTermValue = financeData.payment_term_value;
        let invoiceDateValue = $("#invoice_invoice_date").val();

        let newDate = createExpirationDate(invoiceDateValue, paymentTermValue);
        $("#invoice_expiration_date_hidden").val(newDate);
        $("#invoice_expiration_date").val(newDate);
        $("#vat_display_invoice").text(parseFloat(vat));
        $("#payment_term_value_display_invoice").val(
          parseFloat(paymentTermValue)
        );
        $("#g_account_percentage_display").text(
          financeData.g_account_percentage
        );
        $("#c_account_percentage_display").text(
          financeData.c_account_percentage
        );
      } else {
        vat = null;
        vatReversed = null;
      }
    },
    error: function (error) {
      console.log("Error retrieving projects: " + error);
    },
  });
});

$(document).on("change", "#invoice_client_id", function () {
  var selected_client = $("#invoice_client_id");
  var vatValue = $(".vat-hidden-field").val();

  var selected_client_id = selected_client.val();
  $.ajax({
    url: "/admin/invoices/fetch_finances",
    type: "GET",
    data: {
      id: selected_client_id,
    },
    dataType: "json",
    success: function (response) {
      var financeData = response.finance;
      if (financeData) {
        vat = financeData.vat;
        vatReversed = financeData.vat_reversed;
        paymentTermValue = financeData.payment_term_value;
        let invoiceDateValue = $("#invoice_invoice_date").val();

        let newDate = createExpirationDate(invoiceDateValue, paymentTermValue);
        $("#invoice_expiration_date_hidden").val(newDate);
        $("#invoice_expiration_date").val(newDate);
        $("#vat_display_invoice").text(parseFloat(vat));
        $("#payment_term_value_display_invoice").val(
          parseFloat(paymentTermValue)
        );
        $("#g_account_percentage_display").text(
          financeData.g_account_percentage
        );
        $("#c_account_percentage_display").text(
          financeData.c_account_percentage
        );
      } else {
        vat = null;
        vatReversed = null;
      }
    },
    error: function (error) {
      console.log("Error retrieving projects: " + error);
    },
  });
});

// for debit invoice

$(document).on("change", "#debit_invoice_client_id", function () {
  var selected_client = $("#debit_invoice_client_id");
  var vatValue = $(".vat-hidden-field").val();

  var selected_client_id = selected_client.val();
  $.ajax({
    url: "/admin/debit_invoices/fetch_finances",
    type: "GET",
    data: {
      id: selected_client_id,
    },
    dataType: "json",
    success: function (response) {
      var financeData = response.finance;
      vatReversed = financeData.vat_reversed;

      if (financeData) {
        vat = financeData.vat;
        paymentTermValue = financeData.payment_term_value;
        let invoiceDateValue = $("#invoice_invoice_date").val();

        let newDate = createExpirationDate(invoiceDateValue, paymentTermValue);
        $("#invoice_expiration_date_hidden").val(newDate);
        $("#invoice_expiration_date").val(newDate);
        $("#vat_display_invoice").text(parseFloat(vat));
        $("#payment_term_value_display_invoice").val(
          parseFloat(paymentTermValue)
        );

        $("#g_account_percentage_display").text(
          financeData.g_account_percentage
        );
        $("#c_account_percentage_display").text(
          financeData.c_account_percentage
        );
      } else {
        vat = null;
        vatReversed = null;
      }
    },
    error: function (error) {
      console.log("Error retrieving projects: " + error);
    },
  });
});

$(document).on("change", "#debit_invoice_quote_client_id", function () {
  var selected_client = $("#debit_invoice_quote_client_id");
  var vatValue = $(".vat-hidden-field").val();

  var selected_client_id = selected_client.val();
  $.ajax({
    url: "/admin/debit_invoices/fetch_finances",
    type: "GET",
    data: {
      id: selected_client_id,
    },
    dataType: "json",
    success: function (response) {
      var financeData = response.finance;
      vatReversed = financeData.vat_reversed;

      if (financeData) {
        vat = financeData.vat;
        paymentTermValue = financeData.payment_term_value;
        let invoiceDateValue = $("#invoice_invoice_date").val();

        let newDate = createExpirationDate(invoiceDateValue, paymentTermValue);
        $("#invoice_expiration_date_hidden").val(newDate);
        $("#invoice_expiration_date").val(newDate);
        $("#vat_display_invoice").text(parseFloat(vat));
        $("#payment_term_value_display_invoice").val(
          parseFloat(paymentTermValue)
        );

        // $("#g_account_percentage_display").text(
        //   financeData.g_account_percentage
        // );
        // $("#c_account_percentage_display").text(
        //   financeData.c_account_percentage
        // );
      } else {
        vat = null;
        vatReversed = null;
      }
    },
    error: function (error) {
      console.log("Error retrieving projects: " + error);
    },
  });
});

//for add rows in invoice

$(document).on("click", ".invoice-delete-button", function (e) {
  e.stopPropagation();
  let url = "";
  var invoiceDetailId = $(this).data("invoice-detail-id");
  var source = $(this).data("source");
  if (source == "debit-invoice-quote") {
    url = "/admin/debit_invoice_quote_details/delete_invoice_detail";
  } else {
    url = "/admin/invoice_details/delete_invoice_detail";
  }
  if (invoiceDetailId) {
    $.ajax({
      url: url,
      type: "POST",
      data: {
        invoice_id: invoiceDetailId,
        source: source,
      },
      success: function (response) {},
      error: function (error) {},
    });
  }
  $(this).closest("tr").remove();
});

$(document).on("keydown", "#invoice-details-table input", function (e) {
  if (e.which === 9) {
    // 'TAB' key
    var focusedElement = $(document.activeElement);
    if (!focusedElement.val()) {
      e.preventDefault();
    } else {
      var lastInputInRow = focusedElement.closest("tr").find("input").last();
      if (focusedElement.is(lastInputInRow)) {
        e.preventDefault();
        addInvoiceRow();
      }
    }
  }
});

$(document).on("click", "#add-invoice", addInvoiceRow);

function addInvoiceRow() {
  selectedVatValue = 0;
  totalAmountInvoice = 0;
  var table = $("#invoice-details-table");
  var newRowId = "row-" + (table.find("tr").length + 1);
  var newRow = createInvoiceRow(newRowId);
  if (newRow) {
    table.append(newRow);
    $("#invoice-details-table tr:last input:first").focus();
  }
}
function createInvoiceRow(newRowId) {
  selectTypeInvoice = $(".type-selector:checked").val();

  var newRow = $("<tr>").addClass("new-row");

  var invoiceDescription = $("<td>").append(
    $("<input>")
      .addClass("invoice-detail-description")
      .addClass("form-control")
      .attr("type", "text")
      .attr("name", "invoice_details[" + newRowId + "][description]")
      .attr("value", "")
  );

  var unitCell = $("<td>").append(
    $("<input>")
      .addClass("invoice-detail-unit")
      .addClass("form-control")
      .attr("type", "text")
      .attr("name", "invoice_details[" + newRowId + "][unit]")
      .attr("value", "")
  );

  var invoiceAmount = $("<td>").append(
    $("<div>").append(
      $("<input>")
        .addClass("amount-field-invoice-detail")
        .addClass("form-control text-currency")
        .attr("type", "number")
        .attr("name", "invoice_details[" + newRowId + "][amount]")
        .attr("value", "0")
    )
  );

  var invoicePrice = $("<td>").append(
    $("<div>")
      .addClass("currency-wrap")
      .append(
        $("<span>").addClass("currency-code").text("€"),
        $("<input>")
          .addClass("price-field-invoice-detail")
          .addClass("form-control text-currency")
          .attr("type", "number")
          .attr("name", "invoice_details[" + newRowId + "][price]")
          .attr("value", "0")
          .attr("step", "any")
      )
  );

  var vatCell;

  if (selectTypeInvoice == "other") {
    vatCell = $("<td>").append(
      $("<select>")
        .addClass("vat-column-invoice-detail-select")
        .addClass("form-control")
        .attr("name", "invoice_details[" + newRowId + "][vat_percentage]")
        .append(
          $("<option>").attr("value", 0).text("0%"),
          $("<option>").attr("value", 9).text("9%"),
          $("<option>").attr("value", 21).text("21%")
        )
    );
  } else {
    vatCell = $("<td>").append(
      $("<div>").append(
        $("<span>")
          .addClass("vat-column-invoice-detail")
          .text(`${vat ? vat : 21}%`)
      )
    );
  }

  var invoiceTotal = $("<td>").append(
    $("<div>").append(
      $("<span>").addClass("total-column-invoice-detail").text(0)
    )
  );

  var ActionCell = $("<button>")
    .addClass("btn")
    .addClass("btn-danger")
    .addClass("invoice-delete-button created-delete-button")
    .text("Delete");

  newRow.append(
    invoiceAmount,
    invoiceDescription,
    unitCell,
    invoicePrice,
    vatCell,
    invoiceTotal,
    ActionCell
  );

  return newRow;
}

$(document).on("click", ".vat-column-invoice-detail-select", function (event) {
  event.stopPropagation();
});
$(document).on("change", ".vat-column-invoice-detail-select", function (event) {
  var row = $(this).closest("tr");
  selectedVatValue = $(this).val();
  let createdInvoiceAmountValue = $(this).data("total-amount");

  if (createdInvoiceAmountValue) {
    totalAmountInvoice = parseFloat(createdInvoiceAmountValue);
  }
  let vatForInvoice = selectedVatValue / 100;

  let totalAmount = 0;
  totalAmount = totalAmountInvoice + totalAmountInvoice * vatForInvoice;
  var formattedTotalAmount = euroFormat(totalAmount.toFixed(2));
  if (totalAmount) {
    row.find(".total-column-invoice-detail").text(formattedTotalAmount);
  } else {
    row.find(".total-column-invoice-detail").text(euroFormat(0));
  }
});

$(document).on("input", ".amount-field-invoice-detail", function () {
  let testVat = $(this).data("vat");
  let testVatReversed = $(this).data("vat-reversed");
  // console.log("test vat and vat reversed===>",testVat, testVatReversed)
  let vatForInvoice;
  if (selectTypeInvoice === "other") {
    vatForInvoice = selectedVatValue / 100;
  } else {
    vatForInvoice = vat ? vat / 100 : 0.21;
  }

  var row = $(this).closest("tr");
  var invoicePrice = row
    .find("input[type='number'].price-field-invoice-detail")
    .val();
  var invoiceAmount = parseFloat($(this).val());
  invoicePrice = parseFloat(invoicePrice);
  var totalAmount = invoiceAmount * invoicePrice;
  totalAmountInvoice = totalAmount;
  if (vatReversed == null || vatReversed == false) {
    totalAmount = totalAmount + totalAmount * vatForInvoice;
  }
  var formattedTotalAmount = euroFormat(totalAmount.toFixed(2));
  if (totalAmount) {
    row.find(".total-column-invoice-detail").text(formattedTotalAmount);
  } else {
    row.find(".total-column-invoice-detail").text(euroFormat(0));
  }
});

$(document).on("input", ".price-field-invoice-detail", function () {
  let vatForInvoice;
  if (selectTypeInvoice === "other") {
    vatForInvoice = selectedVatValue / 100;
  } else {
    vatForInvoice = vat ? vat / 100 : 0.21;
  }

  var row = $(this).closest("tr");
  var invoiceAmount = parseFloat(
    row.find("input[type='number'].amount-field-invoice-detail").val()
  );
  var invoicePrice = parseFloat($(this).val());
  invoiceAmount = parseFloat(invoiceAmount);

  var totalAmount = invoiceAmount * invoicePrice;
  totalAmountInvoice = totalAmount;
  if (vatReversed == null || vatReversed == false) {
    totalAmount = totalAmount + totalAmount * vatForInvoice;
  }

  var formattedTotalAmount = euroFormat(totalAmount.toFixed(2));

  if (totalAmount) {
    row.find(".total-column-invoice-detail").text(formattedTotalAmount);
  } else {
    row.find(".total-column-invoice-detail").text(euroFormat(0));
  }
});

// for invoice_code

$(document).on("input", ".amount-field-invoice-code", function () {
  var invoiceCodeAmount = $(this).closest("tr");
  var amountInput = parseFloat($(this).val());
  var priceText = invoiceCodeAmount
    .find(".price-column-invoice-code")
    .text()
    .replace(/[^\d.,-]/g, "");
  var price = parseFloat(priceText.replace(/\./g, "").replace(",", "."));
  var totalAmount = amountInput * price;
  var formattedTotalAmount = euroFormat(totalAmount.toFixed(2));
  invoiceCodeAmount
    .find(".total-column-invoice-detail")
    .text(formattedTotalAmount);
});

//for project selecting disciplines according to clients
$(document).on("change", "#project_client_id", function () {
  var selected_client = $("#project_client_id");

  var selected_client_id = selected_client.val();
  getDisciplines(selected_client_id);
});

function getDisciplines(id) {
  var disciplineSelect = document.getElementById("project_discipline_ids");

  $.ajax({
    url: "/admin/projects/fetch_disciplines",
    type: "GET",
    data: {
      id: id,
    },
    dataType: "json",
    success: function (response) {
      var disciplines = response.disciplines || [];
      disciplineSelect.innerHTML = "";
      disciplines.forEach((discipline) => {
        const option = document.createElement("option");
        option.value = discipline.id;
        option.textContent = discipline.name;
        disciplineSelect.appendChild(option);
      });
    },
    error: function (error) {
      console.log("Error retrieving weeks: " + error);
    },
  });
}

// for add the dates in projects and employee certificate

// $(document).on("focus", "#date-field", function () {
//   var dateFieldStartDate = $("#date-field");

//   flatpickr(dateFieldStartDate, {
//     dateFormat: "d/m/Y",
//     allowInput: true,
//     clickOpens: true,
//     locale: {
//       firstDayOfWeek: 1,
//       weekdays: {
//         shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
//         longhand: [
//           "Zondag",
//           "Maandag",
//           "Dinsdag",
//           "Woensdag",
//           "Donderdag",
//           "Vrijdag",
//           "Zaterdag",
//         ],
//       },
//       months: {
//         shorthand: [
//           "Jan",
//           "Feb",
//           "Mrt",
//           "Apr",
//           "Mei",
//           "Jun",
//           "Jul",
//           "Aug",
//           "Sep",
//           "Okt",
//           "Nov",
//           "Dec",
//         ],
//         longhand: [
//           "Januari",
//           "Februari",
//           "Maart",
//           "April",
//           "Mei",
//           "Juni",
//           "Juli",
//           "Augustus",
//           "September",
//           "Oktober",
//           "November",
//           "December",
//         ],
//       },
//     },
//   });
// });

$(document).on("focus", "#employee_date_of_birth", function () {
  var dateFieldStartDate = $("#employee_date_of_birth");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});
$(document).on("focus", "#employee_certificate_end_date", function () {
  var dateFieldStartDate = $("#employee_certificate_end_date");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

$(document).on("focus", "#employee_certificate_date_achieved", function () {
  var dateFieldStartDate = $("#employee_certificate_date_achieved");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

$(document).on("focus", "#material_construction_date", function () {
  var dateFieldStartDate = $("#material_construction_date");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

$(document).on("focus", "#equipment_material_construction_date", function () {
  var dateFieldStartDate = $("#equipment_material_construction_date");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

$(document).on(
  "click",
  ".new_employee_scheduling .btn-new-resource",
  function () {
    setTimeout(function () {
      dateFieldStartDate = $("#project_start_date");
      startDatePicker = flatpickr(dateFieldStartDate, {
        dateFormat: "d/m/Y",
        allowInput: true,
        clickOpens: true,
        weekNumbers: true,
        onChange: function (selectedDates, dateStr, instance) {
          // dateFieldEndDate.focus();
          setTimeout(function () {
            dateFieldEndDate.focus();
            endDatePicker.open();
          }, 100);
        },
        locale: {
          firstDayOfWeek: 1,
          weekdays: {
            shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
            longhand: [
              "Zondag",
              "Maandag",
              "Dinsdag",
              "Woensdag",
              "Donderdag",
              "Vrijdag",
              "Zaterdag",
            ],
          },
          months: {
            shorthand: [
              "Jan",
              "Feb",
              "Mrt",
              "Apr",
              "Mei",
              "Jun",
              "Jul",
              "Aug",
              "Sep",
              "Okt",
              "Nov",
              "Dec",
            ],
            longhand: [
              "Januari",
              "Februari",
              "Maart",
              "April",
              "Mei",
              "Juni",
              "Juli",
              "Augustus",
              "September",
              "Oktober",
              "November",
              "December",
            ],
          },
        },
      });
      dateFieldEndDate = $("#project_end_date");
      endDatePicker = flatpickr(dateFieldEndDate, {
        dateFormat: "d/m/Y",
        allowInput: true,
        clickOpens: true,
        weekNumbers: true,
        onChange: function (selectedDates, dateStr, instance) {
          // Re-open the date picker after a date is selected
          // instance.open();
        },
        locale: {
          firstDayOfWeek: 1,
          weekdays: {
            shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
            longhand: [
              "Zondag",
              "Maandag",
              "Dinsdag",
              "Woensdag",
              "Donderdag",
              "Vrijdag",
              "Zaterdag",
            ],
          },
          months: {
            shorthand: [
              "Jan",
              "Feb",
              "Mrt",
              "Apr",
              "Mei",
              "Jun",
              "Jul",
              "Aug",
              "Sep",
              "Okt",
              "Nov",
              "Dec",
            ],
            longhand: [
              "Januari",
              "Februari",
              "Maart",
              "April",
              "Mei",
              "Juni",
              "Juli",
              "Augustus",
              "September",
              "Oktober",
              "November",
              "December",
            ],
          },
        },
      });
    }, 1000);
  }
);

$(document).on("click", "#project_start_date", function () {
  console.log("clicked", startDatePicker, dateFieldStartDate.length);
  startDatePicker.open();
  dateFieldStartDate.focus();
});

// $(document).on("click", "#project_end_date", function () {
//   console.log("enddatepicker",endDatePicker)
//   console.log("enddatefield",dateFieldEndDate)
//   // const inputOffset = $(this).offset();
//   // startDatePicker.open();
//   // startDatePicker.calendarContainer.style.top = inputOffset.top + $(this).outerHeight() + "px";
//   // startDatePicker.calendarContainer.style.left = inputOffset.left + "px";
//   // dateFieldStartDate.focus()
//   // startDatePicker.open();
// });

// $(document).on("click", "#project_start_date", function () {
//   console.log("clicked");
//   var dateFieldStartDate = $("#project_start_date");
//   dateFieldStartDate.focus();

//   flatpickr(dateFieldStartDate, {
//     dateFormat: "d/m/Y",
//     allowInput: true,
//     clickOpens: true,
//     weekNumbers: true,
//     onChange: function (selectedDates, dateStr, instance) {
//       dateFieldEndDate.focus();
//       // setTimeout(function () {
//       //   dateFieldEndDate.focus();
//       //   endDatePicker.open();
//       // }, 100);
//     },
//     locale: {
//       firstDayOfWeek: 1,
//       weekdays: {
//         shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
//         longhand: [
//           "Zondag",
//           "Maandag",
//           "Dinsdag",
//           "Woensdag",
//           "Donderdag",
//           "Vrijdag",
//           "Zaterdag",
//         ],
//       },
//       months: {
//         shorthand: [
//           "Jan",
//           "Feb",
//           "Mrt",
//           "Apr",
//           "Mei",
//           "Jun",
//           "Jul",
//           "Aug",
//           "Sep",
//           "Okt",
//           "Nov",
//           "Dec",
//         ],
//         longhand: [
//           "Januari",
//           "Februari",
//           "Maart",
//           "April",
//           "Mei",
//           "Juni",
//           "Juli",
//           "Augustus",
//           "September",
//           "Oktober",
//           "November",
//           "December",
//         ],
//       },
//     },
//   });
// });

// $(document).on("focus", "#project_end_date", function () {
//   var dateFieldEndDate = $("#project_end_date");

//   flatpickr(dateFieldEndDate, {
//     dateFormat: "d/m/Y",
//     allowInput: true,
//     clickOpens: true,
//     locale: {
//       firstDayOfWeek: 1,
//       weekdays: {
//         shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
//         longhand: [
//           "Zondag",
//           "Maandag",
//           "Dinsdag",
//           "Woensdag",
//           "Donderdag",
//           "Vrijdag",
//           "Zaterdag",
//         ],
//       },
//       months: {
//         shorthand: [
//           "Jan",
//           "Feb",
//           "Mrt",
//           "Apr",
//           "Mei",
//           "Jun",
//           "Jul",
//           "Aug",
//           "Sep",
//           "Okt",
//           "Nov",
//           "Dec",
//         ],
//         longhand: [
//           "Januari",
//           "Februari",
//           "Maart",
//           "April",
//           "Mei",
//           "Juni",
//           "Juli",
//           "Augustus",
//           "September",
//           "Oktober",
//           "November",
//           "December",
//         ],
//       },
//     },
//   });
// });

$(document).on("focus", "#insurance_commencement_date", function () {
  var dateFieldStartDate = $("#insurance_commencement_date");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

// for dates in equipments

$(document).on("focus", "#equipment_material_purchase_date", function () {
  var dateFieldStartDate = $("#equipment_material_purchase_date");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

$(document).on("focus", "#equipment_material_inspection_date", function () {
  var dateFieldStartDate = $("#equipment_material_inspection_date");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

// for dates in invoices

$(document).on("focus", "#invoice_invoice_date", function () {
  var dateFieldStartDate = $("#invoice_invoice_date");
  let invoiceDateValue = dateFieldStartDate.val();
  let paymentTermValue = $("#payment_term_value_display_invoice").val();
  let newDate = createExpirationDate(
    invoiceDateValue,
    Number(paymentTermValue)
  );
  $("#invoice_expiration_date_hidden").val(newDate);
  $("#invoice_expiration_date").val(newDate);

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

$(document).on("focus", "#invoice_expiration_date", function () {
  var dateFieldStartDate = $("#invoice_expiration_date");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

$(document).on("focus", "#invoice_paid_date", function () {
  var dateFieldStartDate = $("#invoice_paid_date");

  flatpickr(dateFieldStartDate, {
    dateFormat: "d/m/Y",
    allowInput: true,
    clickOpens: true,
    locale: {
      firstDayOfWeek: 1,
      weekdays: {
        shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
        longhand: [
          "Zondag",
          "Maandag",
          "Dinsdag",
          "Woensdag",
          "Donderdag",
          "Vrijdag",
          "Zaterdag",
        ],
      },
      months: {
        shorthand: [
          "Jan",
          "Feb",
          "Mrt",
          "Apr",
          "Mei",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Okt",
          "Nov",
          "Dec",
        ],
        longhand: [
          "Januari",
          "Februari",
          "Maart",
          "April",
          "Mei",
          "Juni",
          "Juli",
          "Augustus",
          "September",
          "Oktober",
          "November",
          "December",
        ],
      },
    },
  });
});

//for adding purchase orders amount in weeks

$(document).on("input", ".amount-field", function () {
  var purchaseOrderRow = $(this).closest("tr");
  var amountInput = $(this).val();
  var specificationCodeField = purchaseOrderRow.find(
    ".specification-code-field"
  );
  var project_type = specificationCodeField.data("project-type");
  var constantTotalBudget = specificationCodeField.data("total-budget");
  var projectId = $("#project-number-field").data("project-id").id;
  var weekId = $("#week-number-field").data("week-id");
  console.log("project type===>")
  if (
    project_type !== null &&
    constantTotalBudget !== null &&
    constantTotalBudget !== undefined &&
    project_type !== undefined
  ) {
    checkPurchasOrderForContractProject(weekId, projectId)
    .then(function (object) {
      
      totalComulatiefWeek = object.totalComulatiefWeek;
      if (constantTotalBudget) {
        var amount = parseFloat(amountInput);
        var cumulatief = parseFloat(totalComulatiefWeek);
        var totalComulatiefAmount = euroFormat(
          parseFloat(cumulatief + amount).toFixed(2)
        );
        var totalCumulatiefWeekAmount = euroFormat(
          parseFloat(cumulatief + amount - constantTotalBudget).toFixed(2)
        );
        purchaseOrderRow
          .find(".cumulatief-week")
          .text(totalCumulatiefWeekAmount);
        purchaseOrderRow
          .find(".cumulatief-total")
          .text(totalComulatiefAmount);
      }
    })
    .catch(function (error) {
      console.log("Error retrieving price: " + error);
    });
  } else {
    var codeInput = specificationCodeField.val();
    var codeId = specificationCodeField.data("code-id");

    var price = specificationCodeField.data("price");
    var totalBudgetText = purchaseOrderRow
      .find(".total-budget")
      .text()
      .replace(/[^\d.,-]/g, "");
    var totalBudget = parseFloat(
      totalBudgetText.replace(/\./g, "").replace(",", ".")
    );

    var code = null;
    if (codeInput && codeId) {
      code = codeInput.split(" - ")[0].trim();
    }

    updateSpecificationCode(codeId, weekId, projectId, price)
      .then(function (object) {
        price = object.price;
        // totalBudget = object.totalBudget;
        measurement = object.measurement;
        totalComulatiefWeek = object.totalComulatiefWeek;
        if (price && totalBudget) {
          var roundedPrice = parseFloat(price).toFixed(2);
          var formattedPrice = euroFormat(roundedPrice);
          purchaseOrderRow.find(".measurment-column").text(measurement);
          purchaseOrderRow.find(".price-column").text(formattedPrice);

          var amount = parseFloat(amountInput);
          var cumulatief = parseFloat(totalComulatiefWeek);
          var totalComulatiefAmount = euroFormat(
            parseFloat(cumulatief + amount).toFixed(2)
          );
          var totalCumulatiefWeekAmount = euroFormat(
            parseFloat(cumulatief + amount - totalBudget).toFixed(2)
          );
          purchaseOrderRow
            .find(".cumulatief-week")
            .text(totalCumulatiefWeekAmount);
          purchaseOrderRow
            .find(".cumulatief-total")
            .text(totalComulatiefAmount);
          var total = euroFormat((parseFloat(price) * amount).toFixed(2));
          var formattedTotalBudget = euroFormat(totalBudget);
          purchaseOrderRow
            .find(".total-budget-column")
            .text(formattedTotalBudget);
          purchaseOrderRow.find(".total-column").text(total);
        }
      })
      .catch(function (error) {
        console.log("Error retrieving price: " + error);
      });
  }
});

function checkPurchasOrderForContractProject(weekId, projectId) {
  return new Promise(function (resolve, reject) {
    $.ajax({
      url: "/admin/weeks/check_purchase_orders_data",
      type: "GET",
      data: {
        week_id: weekId,
        project_id: projectId,
      },
      dataType: "json",
      success: function (response) {
        console.log("respons of api===>",response)
        // let totalBudget = response.total_budget;

        let totalComulatiefWeek = response.total_comulatief_amount;

        if (totalComulatiefWeek == 0 || totalComulatiefWeek > 0) {
          resolve({totalComulatiefWeek }); 
        } else {
          resolve(null);
        }
      },
      error: function (error) {
        reject(error); 
      },
    });
  });
}

function updateSpecificationCode(codeId, weekId, projectId, price) {
  var codeId = codeId;
  return new Promise(function (resolve, reject) {
    $.ajax({
      url: "/admin/weeks/check_specification_code",
      type: "GET",
      data: {
        code_id: codeId,
        week_id: weekId,
        project_id: projectId,
        price: price,
      },
      dataType: "json",
      success: function (response) {
        // let totalBudget = response.total_budget;
        let price = response.price;
        let totalComulatiefWeek = response.total_comulatief_amount;
        let measurement = response.measurement;
        if (price) {
          resolve({ price, measurement, totalComulatiefWeek }); // Resolve the promise with the price value
        } else {
          resolve(null); // Resolve with null if no price is found
        }
      },
      error: function (error) {
        reject(error); // Reject the promise with the error
      },
    });
  });
}

//for the custom buttons in clients
$(document).on("click", "#add-contact-person-button", function () {
  var id = $("#add-contact-person-button").data("id");
  var source = $("#add-contact-person-button").data("source");
  setRouteLocally();
  var data = {
    id: id,
  };
  $.ajax({
    url: `/admin/${source}/${data.id}/create_contact_person`,
    type: "POST",
    data: data,
    processData: false,
    contentType: false,
    success: function (response) {},
    error: function (error) {},
  });
});
// custom action buttons
$(document).on("click", "#add-discipline-button", function () {
  var clientId = $("#add-discipline-button").data("client-id");
  setRouteLocally();
  var data = {
    id: clientId,
  };
  customButtonActons("create_discipline", "clients", data);
});

$(document).on("click", "#add-finance-button", function () {
  var id = $("#add-finance-button").data("id");
  var source = $("#add-finance-button").data("source");
  setRouteLocally();
  var data = {
    id: id,
  };
  customButtonActons("create_finance", source, data);
});

$(document).on("click", "#add-specification-code-button", function () {
  var disciplineId = $("#add-specification-code-button").data("discipline-id");
  setRouteLocally();
  var data = {
    id: disciplineId,
  };
  customButtonActons("create_specification_code", "disciplines", data);
});
// for custom buttons in projects

$(document).on("click", "#add-certificate-button", function () {
  var employeeId = $("#add-certificate-button").data("employee-id");
  setRouteLocally();
  var data = {
    id: employeeId,
  };
  customButtonActons("create_certificate", "employees", data);
});
$(document).on("click", "#add-plan-button", function () {
  var projectId = $("#add-plan-button").data("project-id");
  setRouteLocally();
  var data = {
    id: projectId,
  };
  customButtonActons("create_plans", "projects", data);
});
$(document).on("click", "#add-tkc-button", function () {
  var projectId = $("#add-tkc-button").data("project-id");
  setRouteLocally();
  var data = {
    id: projectId,
  };
  customButtonActons("create_tkc_cost", "projects", data);
});
$(document).on("click", "#add-extra-cost-button", function () {
  var projectId = $("#add-extra-cost-button").data("project-id");
  setRouteLocally();
  var data = {
    id: projectId,
  };
  customButtonActons("create_extra_cost", "projects", data);
});

function customButtonActons(name, source, data) {
  $.ajax({
    url: `/admin/${source}/${data.id}/${name}`,
    type: "POST",
    data: data,
    processData: false,
    contentType: false,
    success: function (response) {},
    error: function (error) {},
  });
}

//for the pdf download
var weekIdPdf = null;

$(document).on("click", "#export-pdf-button", function (event) {
  event.stopPropagation();
  weekIdPdf = $(this).data("week-id");
  console.log(weekIdPdf);
  $(".discipline-selecter-modal .modal").css("display", "block");
});
$(document).on("change", "#discipline-select", function (event) {
  var selectedDisciplineId = $("#discipline-select").val();
  if (selectedDisciplineId) {
    var pdfLink = document.getElementById("download-pdf-button");
    if (pdfLink) {
      pdfLink.href = `/admin/weeks/${weekIdPdf}/create_pdf_generator?discipline_id=${selectedDisciplineId}&template=discipline_pdf`;
    }
  }
});

$(document).on("click", "#download-pdf-button", function (event) {
  var selectedDisciplineId = $("#discipline-select").val();
  if (selectedDisciplineId && weekIdPdf) {
    $("#discipline-select").val("");
    hideDialogBox();
  }
});

//for the dialog box to update flat rate
$(document).on("click", "#add-flat-rate-button", function () {
  $(".flat-rate .modal").css("display", "block");
});
$(document).on("click", "#show-flat-rate-confirm-modal", function () {
  var flatRate = $("#discipline_flat_rate").val();
  if (flatRate !== null && flatRate !== undefined && flatRate !== "") {
    $(".flat-rate-confirm-modal .modal").css("display", "block");
  }
});

$(document).on("click", ".close-flat-rate", function () {
  hideDialogBox();
});

$(document).on("click", "#save-flat-rate-button", function () {
  var disciplineId = $("#save-flat-rate-button").data("discipline-id");
  var flatRate = $("#discipline_flat_rate").val();

  $("#discipline_flat_rate").prop("disabled", true);
  $("#save-flat-rate-button").prop("disabled", true);
  $("#loader-overlay").show();

  updateFlatRate(disciplineId, flatRate)
    .then(function (object) {
      location.reload();
      $("#loader-overlay").hide();
      $(".modal").css("display", "none");
    })
    .catch(function (error) {
      $("#loader-overlay").hide();
      $(".modal").css("display", "none");
      location.reload();
    });
});

$(document).on("click", ".close-flat-rate", function () {
  hideDialogBox();
});

function updateFlatRate(disciplineId, flatRate) {
  return new Promise(function (resolve, reject) {
    $.ajax({
      url: `/admin/disciplines/${disciplineId}/add_flat_rate`,
      type: "POST",
      data: {
        discipline_id: disciplineId,
        flat_rate: parseFloat(flatRate),
      },
      dataType: "json",
      success: function (response) {
        resolve(response);
      },
      error: function (error) {
        reject(error);
      },
    });
  });
}
$(document).on("click", function (event) {
  createProjectModal = localStorage.getItem("create-project-modal");

  if (
    !$(event.target).is("#add-flat-rate-button") &&
    !$(event.target).closest(".modal-content").length &&
    $(".modal").is(":visible") &&
    createProjectModal !== "true"
  ) {
    hideDialogBox();
  }
});

function hideDialogBox() {
  $(".modal").fadeOut("fast");
  $("#loading-overlay").hide();
}

//add client button in employee
$(document).on("click", "#add-client-button", addClientRow);

function addClientRow() {
  var employeeId = $("#add-client-button").data("employee-id");
  var table = $("#employees-clients-table");

  var newRowId = "row-" + (table.find("tr").length + 1);
  var newRow = createClientRow(newRowId, employeeId);
  table.append(newRow);
}
function createClientRow(newRowId, employeeId) {
  console.log(
    "here is the new row id and employee id===>",
    newRowId,
    employeeId
  );
  var newRow = $("<tr>").addClass("new-row");
  var employeeNumberCell = $("<td>").append(
    createEmployeeNumberField(newRowId)
  );
  var clientSelect = $("<select>", {
    class: "employee-client-name-field form-control my-select-feild",
    name: "employee_client_name[" + newRowId + "][client]",
    id: "employee-client-name-new",
  });

  newRow.append(clientSelect, employeeNumberCell);

  $.ajax({
    url: "/admin/employees/get_clients",
    type: "GET",
    data: {
      employee_id: employeeId,
    },
    dataType: "json",
    success: function (response) {
      var clients = response.clients;
      console.log("client is here===>", clients);
      // Add the options to the select field
      $.each(clients, function (index, client) {
        var option = $("<option>", {
          value: client.id,
          text: client.client_name,
        });
        clientSelect.append(option);
      });

      clientSelect.val("");
    },
    error: function (error) {
      console.log("Error retrieving specification codes: " + error);
    },
  });

  return newRow;
}
function createEmployeeNumberField(newRowId) {
  return $("<input>")
    .addClass("employee-number-field")
    .addClass("form-control")
    .attr("type", "number")
    .attr(
      "name",
      "employee_client_employee_number[" + newRowId + "][employee_number]"
    );
}

// add activity functionality in projects

$(document).on("click", "#add-activity-button", addActivityRow);

function addActivityRow() {
  var projectActivities = $("#add-activity-button").data("activities");
  var table = $("#activities-table");

  var newRowId = "row-" + (table.find("tr").length + 1);

  if (projectActivities.length === 0) {
    var newRow = createNewActivityRow(newRowId);
    table.append(newRow);
  } else {
    var lastRow = table.find("tr").last();
    var newRow = lastRow.clone();

    newRow.find("input").val("");
    newRow.find(".activity-name-field").val("");
    newRow.find(".activity-color-field").val("");
    newRow.find(".actions").remove();

    // Generate a unique identifier for the new row
    var newRowId = "row-" + (table.find("tr").length + 1);

    // Set names and IDs for select and amount fields in the new row

    newRow
      .find(".activity-name-field")
      .attr("name", "activity_name[" + newRowId + "][activity_name]")
      .attr("id", "activity_name_" + newRowId + "_activity_name");
    newRow
      .find(".activity-color-field")
      .attr("name", "activity_color[" + newRowId + "][color]")
      .attr("id", "activity_color_" + newRowId + "_color");

    // Add a custom class to the new row
    newRow.addClass("new-row");

    // Append the new row to the table
    table.append(newRow);
  }
}

function createNewActivityRow(newRowId) {
  var project = $("#add-activity-button").data("project-id");
  var newRow = $("<tr>").addClass("new-row");
  var activityNameCell = $("<td>").append(createActivityNameField(newRowId));
  var activityColorCell = $("<td>").append(createAcitivityColorField(newRowId));

  newRow.append(activityNameCell);
  newRow.append(activityColorCell);
  return newRow;
}

function createActivityNameField(newRowId) {
  return $("<input>")
    .addClass("activity-name-field")
    .addClass("form-control")
    .attr("type", "text")
    .attr("name", "activity_name[" + newRowId + "][activity_name]");
}
function createAcitivityColorField(newRowId) {
  return $("<input>")
    .addClass("activity-color-field")
    .addClass("form-control")
    .attr("type", "color")
    .attr("name", "activity_color[" + newRowId + "][color]");
}

// search bar functionality

$(document).on("click", "#clear-input", function () {
  var code = "";
  var tab = "";
  let localCodesData = localStorage.getItem("myData");
  let parsedData = [];
  let codeIds = "";

  if (localCodesData) {
    parsedData = JSON.parse(localCodesData);
    var pathArray = window.location.pathname.split("/");
    var projectId = pathArray[3];
    parsedData = parsedData.filter((item) => item.project_id == projectId);
    codeIds = parsedData.map((item) => item.code_id).join(",");
  }
  var url = new URL(window.location.href);
  if (url) {
    code = url.searchParams.get("code");
    tab = url.searchParams.get("tab");
    discipline = url.searchParams.get("discipline");
  }
  if (code || discipline) {
    $("#search-field-code").val("");
    Turbolinks.visit(
      `${window.location.pathname}?tab=SpecificationCode&code=${code}&discipline=${discipline}&codes=${codeIds}&search=#!tab-SpecificationCode`
    );
  } else if (tab == "weeks") {
    $("#search-field-weeks").val("");
    Turbolinks.visit(
      `${window.location.pathname}?tab=weeks&search=#!tab-weeks`
    );
  } else {
    $("#search-field-employee-scheduling").val("");
    Turbolinks.visit(
      `${window.location.pathname}?tab=employees&search=#!tab-employees`
    );
  }
});

$(document).on("keypress", "#search-field-code", function (e) {
  if (e.key == "Enter") {
    const searchTerm = $(this).val().toLowerCase();
    let localCodesData = localStorage.getItem("myData");
    var code = "";
    let parsedData = [];
    let codeIds = "";
    if (localCodesData) {
      parsedData = JSON.parse(localCodesData);
      var pathArray = window.location.pathname.split("/");
      var projectId = pathArray[3];
      parsedData = parsedData.filter((item) => item.project_id == projectId);
      codeIds = parsedData.map((item) => item.code_id).join(",");
    }
    var url = new URL(window.location.href);
    if (url) {
      code = url.searchParams.get("code");
      discipline = url.searchParams.get("discipline");
    }
    Turbolinks.visit(
      `${window.location.pathname}?tab=SpecificationCode&code=${code}&discipline=${discipline}&search=${searchTerm}#!tab-SpecificationCode`
    );
  }
});

$(document).on("keypress", "#search-field-weeks", function (e) {
  if (e.key == "Enter") {
    const searchTerm = $(this).val().toLowerCase();

    Turbolinks.visit(
      `${window.location.pathname}?tab=weeks&search=${searchTerm}#!tab-weeks`
    );
  }
});

$(document).on("keypress", "#search-field-employee-scheduling", function (e) {
  if (e.key == "Enter") {
    const searchTerm = $(this).val().toLowerCase();

    Turbolinks.visit(
      `${window.location.pathname}?tab=employees&search=${searchTerm}#!tab-employees`
    );
  }
});

// for specificaion code in tkc cost
// if (tkcCostAmounts && tkcCostAmounts.length === 0) {
//   var tkcCostProject = $("#tkc-cost-project-field").data("project-id");
//   addTkcAmountCostRow(tkcCostProject);
// }

// for adding codes in specification codes in projects
$(document).on("click", "#add-specification-code", function () {
  var projectId = $("#add-specification-code").data("project-id");
  if (projectId) {
    $.ajax({
      url: "/admin/projects/get_specification_codes",
      type: "GET",
      data: {
        project_id: projectId,
        discipline_id: activeDisciplineId,
      },
      dataType: "json",
      success: function (response) {
        specificationCodesData = response.specification_codes;

        var table = $("#project-specification-code-table");
        var newRowId = "row-" + (table.find("tr").length + 1);
        var newRow = $("<tr>").addClass("new-row");

        var codeCell = $("<td>")
          .addClass("select-box-code")
          .append(
            $("<select>")
              .addClass("form-control")
              .attr(
                "name",
                "active_specificaion_codes[" +
                  newRowId +
                  "][specification_code]"
              )
              .append(
                $("<option>")
                  .attr("value", "")
                  .text("Selecteer specificatiecode"),
                specificationCodesData.map(function (specificationCode) {
                  let text =
                    specificationCode.specification_code +
                    "-" +
                    specificationCode.description +
                    "-" +
                    specificationCode.measurement +
                    "-" +
                    parseFloat(specificationCode.price);
                  return $("<option>")
                    .attr("value", specificationCode.id)
                    .text(text);
                })
              )
          );
        var descriptionCell = $("<td>")
          .addClass("table-font-description")
          .text("-");

        var unitCell = $("<td>").text("-");
        var priceCell = $("<td>").addClass("table-font-code").text("€ 0,00");
        var totalBudgetCell = $("<td>").append(
          $("<input>").attr({
            type: "number",
            name: "selected_specification_code[" + newRowId + "][total_budget]",
            id: "selected_specification_code_" + newRowId + "_total_budget",
            class: "total-budget-field",
            "data-project-id": projectId,
            "data-code-id": newRowId,
            step: 0.01,
          }),
          $("<span>").addClass("asterisk").text("*")
        );
        newRow.append(
          codeCell,
          descriptionCell,
          unitCell,
          priceCell,
          totalBudgetCell
        );
        table.append(newRow);

        // Initialize Select2 on the new select box
        $(".form-control").select2();
      },
      error: function (error) {
        console.log("Error retrieving specification codes: " + error);
      },
    });
  }
});

$(document).on(
  "change",
  "select[name^='active_specificaion_codes']",
  function () {
    let selectedRow = $(this).closest("tr");
    let selectedSpecificationCodeId = $(this).val();

    $.ajax({
      url: "/admin/projects/get_specification_code",
      type: "GET",
      data: {
        id: selectedSpecificationCodeId,
      },
      dataType: "json",
      success: function (response) {
        let specificationCode = response.specification_code;
        var descriptionCell = selectedRow.find("td:eq(1)");
        var unitCell = selectedRow.find("td:eq(2)");
        var priceCell = selectedRow.find("td:eq(3)");
        descriptionCell.text(specificationCode.description);
        unitCell.text(specificationCode.measurement);
        priceCell.text(euroFormat(specificationCode.price));
        var totalBudgetField = selectedRow.find(".total-budget-field");

        totalBudgetField.attr("data-code-id", specificationCode.id);
      },
      error: function (error) {
        console.log("Error retrieving specification codes: " + error);
      },
    });
  }
);

$(document).on("click", "#add-tkc-cost-amount", function () {
  var tkcCostProjectId = $("#tkc-cost-project-field").data("project-id");

  addTkcAmountCostRow(tkcCostProjectId);
});

$(document).on("click", ".custom-tkc-const-amount-delete-button", function (e) {
  e.stopPropagation();
  var tkcCostAmountId = $(this).data("tkc-cost-amount-id");

  if (tkcCostAmountId) {
    $.ajax({
      url: `/admin/tkc_cost_amounts/delete_tkc_cost_amount`,
      type: "POST",
      data: {
        tkc_cost_amount_id: tkcCostAmountId,
      },
      success: function (response) {},
      error: function (error) {},
    });
  }
  $(this).closest("tr").remove();
});

function addTkcAmountCostRow(tkcCostProjectId) {
  var table = $("#tkc-cost-amount-table");
  var newRowId = "row-" + (table.find("tr").length + 1);
  if (specificationCodesData.length === 0) {
    $.ajax({
      url: "/admin/weeks/get_specification_code",
      type: "GET",
      data: {
        project_id: tkcCostProjectId,
      },
      dataType: "json",
      success: function (response) {
        specificationCodesData = response.specification_codes;
        createNewRowTkcAmount(newRowId, table);
      },
      error: function (error) {
        console.log("Error retrieving specification codes: " + error);
      },
    });
  } else {
    createNewRowTkcAmount(newRowId, table);
  }
}

function createNewRowTkcAmount(newRowId, table) {
  var newRow = $("<tr>").addClass("new-row");

  var amountCell = $("<td>").append(createAmountField(newRowId));
  var priceCell = $("<td>")
    .addClass("price-column-tkc-cost table-font-code")
    .html(euroFormat(0));
  var totalCell = $("<td>")
    .addClass("total-column-tkc-cost table-font-code")
    .html(euroFormat(0.0));
  var codeIdHiddenField = $("<input>")
    .attr("type", "hidden")
    .attr(
      "name",
      "tkc_cost_amount_codes[" + newRowId + "][specification_code_id]"
    )
    .attr("value", "");

  let removeSelectedCodes = [...specificationCodesData];
  removeSelectedCodes = removeSelectedCodes.filter(function (item) {
    return !selectedSpecificationCodeIds.includes(String(item.id));
  });

  var descriptionCell = $("<td>")
    .addClass("select-box-code")
    .append(
      $("<select>")
        .addClass("form-control")
        .addClass("select-field-tkc")
        .attr(
          "name",
          "tkc_cost_amount_codes[" + newRowId + "][specification_code]"
        )
        .append(
          $("<option>").attr("value", "").text("Selecteer specificatiecode"),
          removeSelectedCodes.map(function (specificationCode) {
            let text =
              specificationCode.specification_code +
              "-" +
              specificationCode.description +
              "-" +
              specificationCode.measurement +
              "-" +
              parseFloat(specificationCode.price);
            return $("<option>").attr("value", specificationCode.id).text(text);
          })
        )
    );

  var ActionCell = $("<div>")
    .addClass("btn")
    .addClass("btn-danger")
    .addClass("custom-tkc-const-amount-delete-button")
    .addClass("created-delete-button")
    .text("Verwijderen");

  newRow.append(
    descriptionCell,
    codeIdHiddenField,
    amountCell,
    priceCell,
    totalCell,
    ActionCell
  );

  table.append(newRow);
  $(".select-field-tkc").select2();
}

function createAmountField(newRowId) {
  return $("<input>")
    .addClass("amount-field-tkc-cost")
    .attr("type", "number")
    .attr("name", "tkc_cost_amount_codes[" + newRowId + "][amount]")
    .attr("min", "0")
    .attr("value", "0");
}

$(document).on("change", "select[name^='tkc_cost_amount_codes']", function () {
  const previouslySelectedValue = $(this).data("previouslySelectedValue"); // Store the previously selected value
  const newlySelectedValue = $(this).val(); // Get the newly selected value
  let deselected = null;

  // Update the data-previouslySelectedValue attribute with the newly selected value
  $(this).data("previouslySelectedValue", newlySelectedValue);

  // Use previouslySelectedValue to access the deselected value

  if (previouslySelectedValue) {
    deselected = specificationCodesData.filter(function (item) {
      return String(item.id) == previouslySelectedValue;
    });
  }

  var selectedSpecificationCodeId = $(this).val();

  $("select[name^='tkc_cost_amount_codes']")
    .not(this)
    .each(function () {
      $(this)
        .find("option[value='" + selectedSpecificationCodeId + "']")
        .remove();
    });

  if (deselected) {
    $("select[name^='tkc_cost_amount_codes']")
      .not(this)
      .each(function () {
        $(this).append(
          "<option value='" +
            deselected[0].id +
            "'>" +
            deselected[0].name +
            "</option>"
        );
      });
    const index = selectedSpecificationCodeIds.indexOf(previouslySelectedValue);
    selectedSpecificationCodeIds.splice(index, 1);
  }

  if (selectedSpecificationCodeId) {
    selectedSpecificationCodeIds.push(selectedSpecificationCodeId);
  } else {
    var index = selectedSpecificationCodeIds.indexOf(
      selectedSpecificationCodeId
    );
    if (index !== -1) {
      selectedSpecificationCodeIds.splice(index, 1);
    }
  }

  var selectedRow = $(this).closest("tr"); // Find the closest <tr> element
  var data = null;
  if (selectedRow) {
    $.ajax({
      url: "/admin/tkc_costs/specification_code",
      type: "GET",
      data: { specification_code_id: selectedSpecificationCodeId },
      dataType: "json",
      success: function (response) {
        data = response.specification_code;

        updateRowData(selectedRow, data);
      },
      error: function (error) {
        // console.log("Error retrieving weeks: " + error);
      },
    });
  }
});

function updateRowData(selectedRow, codeData) {
  if (codeData) {
    var codeIdHiddenField = selectedRow.find("input[type='hidden']");
    var quantityFieldValue = selectedRow.find("input[type='number']").val();

    var priceCell = selectedRow.find("td:eq(2)");

    var total = selectedRow.find("td:eq(3)");
    codeIdHiddenField.val(codeData.id);

    priceCell.html(euroFormat(codeData.price));
    total.html(
      euroFormat(parseFloat(quantityFieldValue) * parseFloat(codeData.price))
    );
  }
}
// for handling calculation of total tkc cost amount
$(document).on("input", ".amount-field-tkc-cost", function () {
  var totalAmount = 0;
  var tkcCostAmount = $(this).closest("tr");
  var amountInput = parseFloat($(this).val());
  var priceText = tkcCostAmount
    .find(".price-column-tkc-cost")
    .text()
    .replace(/[^\d.,-]/g, "");
  var price = parseFloat(priceText.replace(/\./g, "").replace(",", "."));
  if (amountInput && price) {
    totalAmount = amountInput * price;
  } else {
    totalAmount = 0;
  }

  var formattedTotalAmount = euroFormat(totalAmount.toFixed(2));
  tkcCostAmount.find(".total-column-tkc-cost").text(formattedTotalAmount);
});

function euroFormat(amount) {
  return new Intl.NumberFormat("nl-NL", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: 2,
  }).format(amount);
}

// for the unique cost in tkc_cost

$(document).on("click", ".unique-cost-delete-button", function (e) {
  e.stopPropagation();
  var uniqueCostId = $(this).data("unique-cost-id");

  if (uniqueCostId) {
    $.ajax({
      url: `/admin/unique_costs/delete_unique_cost`,
      type: "POST",
      data: {
        id: uniqueCostId,
      },
      success: function (response) {},
      error: function (error) {},
    });
  }
  $(this).closest("tr").remove();
});

$(document).on("click", "#add-unique-cost", addUniqueCostRow);

function addUniqueCostRow() {
  var table = $("#unique-cost-table");
  var newRowId = "row-" + (table.find("tr").length + 1);
  var newRow = createUniqueCostRow(newRowId);
  if (newRow) {
    table.append(newRow);
    // $("#invoice-details-table tr:last input:first").focus();
  }
}
function createUniqueCostRow(newRowId) {
  var newRow = $("<tr>").addClass("new-row");

  var description = $("<td>").append(
    $("<input>")
      .addClass("unique-cost-description")
      .addClass("form-control")
      .attr("type", "text")
      .attr("name", "unique_costs[" + newRowId + "][description]")
      .attr("value", "")
  );

  var amount = $("<td>").append(
    $("<div>").append(
      $("<input>")
        .addClass("amount-field-unique-cost")
        .addClass("form-control text-currency")
        .attr("type", "number")
        .attr("name", "unique_costs[" + newRowId + "][amount]")
        .attr("value", "0")
    )
  );

  var price = $("<td>").append(
    $("<div>")
      .addClass("currency-wrap")
      .append(
        $("<span>").addClass("currency-code").text("€"),
        $("<input>")
          .addClass("price-unique-cost")
          .addClass("form-control text-currency")
          .attr("type", "number")
          .attr("name", "unique_costs[" + newRowId + "][price]")
          .attr("value", "0")
          .attr("step", "any")
      )
  );

  var total = $("<td>").append(
    $("<div>").append($("<span>").addClass("total-column-unique-cost").text(0))
  );

  var ActionCell = $("<button>")
    .addClass("btn")
    .addClass("btn-danger")
    .addClass("unique-cost-delete-button created-delete-button")
    .text("Verwijderen");

  newRow.append(description, amount, price, total, ActionCell);

  return newRow;
}

$(document).on("input", ".amount-field-unique-cost", function () {
  var row = $(this).closest("tr");
  var price = row.find("input[type='number'].price-unique-cost").val();
  var amount = parseFloat($(this).val());
  price = parseFloat(price);
  var total = amount * price;
  var formattedTotalAmount = euroFormat(total.toFixed(2));
  if (total) {
    row.find(".total-column-unique-cost").text(formattedTotalAmount);
  } else {
    row.find(".total-column-unique-cost").text(euroFormat(0));
  }
});

$(document).on("input", ".price-unique-cost", function () {
  var row = $(this).closest("tr");
  var amount = parseFloat(
    row.find("input[type='number'].amount-field-unique-cost").val()
  );
  var price = parseFloat($(this).val());
  amount = parseFloat(amount);

  var total = amount * price;

  var formattedTotalAmount = euroFormat(total.toFixed(2));

  if (total) {
    row.find(".total-column-unique-cost").text(formattedTotalAmount);
  } else {
    row.find(".total-column-unique-cost").text(euroFormat(0));
  }
});

//for add multiple employee scheduling

$(document).on("click", ".entity-delete-button", function () {
  $(this).closest("tr").remove();
});

$(document).on("click", "#add-es-button", addSchedulingRow);

function addSchedulingRow() {
  var selected_project = $("#employee_scheduling_project_id");
  var selected_project_id = selected_project.val();
  var select_project_innerHtml = selected_project.find(":selected").text();
  var selected_week = $("#employee_scheduling_week_id");
  var selected_week_id = selected_week.val();
  var select_week_innerHtml = selected_week.find(":selected").text();
  var selected_employee = $("#employee_scheduling_employee_id");
  var selected_employee_id = selected_employee.val();
  var select_employee_innerHtml = selected_employee.find(":selected").text();
  var selected_spec_code = $("#employee_scheduling_specification_code_id");
  var selected_spec_code_id = selected_spec_code.val();

  if (selected_project_id && selected_week_id && selected_employee_id) {
    var table = $("#entity-table");

    var newRowId = "row-" + (table.find("tr").length + 1);
    var newRow = createNewSchedulingRow(
      newRowId,
      select_project_innerHtml,
      selected_project_id,
      select_week_innerHtml,
      selected_week_id,
      select_employee_innerHtml,
      selected_employee_id,
      selected_spec_code_id
    );
    table.append(newRow);
    $(".hours-input").val(0);
    // removeSelection(selected_project, selected_week, selected_employee);
  }
}
function removeSelection(project, week, employee) {
  project.val("");
  project.find(":selected").text("Select Project");
  week.val("");
  week.find(":selected").text("");
  employee.val("");
  employee.find(":selected").text("");
}

function createNewSchedulingRow(
  newRowId,
  projectInnerHTML,
  projectValue,
  weekInnerHtml,
  weekValue,
  employeeInnerHtml,
  employeeValue,
  specCodeValue
) {
  const { daysDetails, totalHours } = getDaysDetails();
  var newRow = $("<tr>").addClass("new-row");
  var ProjectNumberCell = $("<td>").append(
    createProjectSchedulingField(
      newRowId,
      projectInnerHTML,
      projectValue,
      specCodeValue
    )
  );
  var WeekNumberCell = $("<td>").append(
    createWeekSchedulingField(newRowId, weekInnerHtml, weekValue)
  );
  var EmployeeNameCell = $("<td>").append(
    createEmployeeField(newRowId, employeeInnerHtml, employeeValue)
  );

  var ActionCell = $("<div>")
    .addClass("btn")
    .addClass("btn-danger")
    .addClass("entity-delete-button")
    .text("Vervijderen");

  if (daysDetails.length > 0) {
    var TotalHoursCell = $("<td>").append(
      createHoursField(newRowId, daysDetails, totalHours)
    );
    newRow.append(
      ProjectNumberCell,
      WeekNumberCell,
      EmployeeNameCell,
      TotalHoursCell,
      ActionCell
    );
    return newRow;
  }

  var TotalHoursCell = $("<td>").append(
    $("<span>")
      .addClass("form-control")
      .text(totalHours ? totalHours : 0)
  );

  newRow.append(
    ProjectNumberCell,
    WeekNumberCell,
    EmployeeNameCell,
    TotalHoursCell,
    ActionCell
  );
  return newRow;
}

function getDaysDetails() {
  var daysDetails = [];
  let totalHours = 0;
  $(".days-row").each(function (index) {
    var dayFields = $(this).find(".day-field");
    dayFields.each(function () {
      var dayName = "";
      var hoursInput = $(this).find(".hours-input");
      var dateInput = $(this).find("input[type='hidden']");
      var nameAttribute = dateInput.attr("name");

      var matches = nameAttribute.match(/days\[(.*?)\]/);
      if (matches && matches.length > 1) {
        dayName = matches[1];
      }
      var hoursValue = parseInt(hoursInput.val());
      var dateValue = dateInput.val();
      if (hoursValue > 0) {
        totalHours += hoursValue;
        object = {
          hours: hoursValue,
          day_date: dateValue,
          day_name: dayName,
        };
        daysDetails.push(object);
      }
    });
  });

  return { daysDetails, totalHours };
}

function createProjectSchedulingField(
  newRowId,
  innerHTML,
  value,
  specCodeValue
) {
  const includeSpecificationCodeCheckbox = $(
    "input[name='employee_scheduling[include_specification_code]']"
  );
  const checkedValue = $(includeSpecificationCodeCheckbox).is(":checked");
  var div = $("<div>");
  var input = $("<input>")
    .addClass("entity-name-field")
    .attr("type", "hidden")
    .attr("name", "project_numbers[" + newRowId + "][project_number]")
    .val(value);
  var includeCode = $("<input>")
    .addClass("entity-name-field")
    .attr("type", "hidden")
    .attr(
      "name",
      "include_specification_codes[" +
        newRowId +
        "][include_specification_code]"
    )
    .val(checkedValue)
    .prop("readonly", true);
  var specCode = $("<input>")
    .addClass("entity-name-field")
    .attr("type", "hidden")
    .attr("name", "specification_codes[" + newRowId + "][specification_code]")
    .val(specCodeValue)
    .prop("readonly", true);

  var span = $("<span>").addClass("form-control").text(innerHTML);
  div.append(input, includeCode, specCode, span);

  return div;
}
function createWeekSchedulingField(newRowId, innerHTML, value) {
  var div = $("<div>");
  var input = $("<input>")
    .addClass("entity-name-field")
    .attr("type", "hidden")
    .attr("name", "week_numbers[" + newRowId + "][week_number]")
    .val(value)
    .prop("readonly", true);
  var span = $("<span>").addClass("form-control").text(innerHTML);
  div.append(input, span);

  return div;
}
function createEmployeeField(newRowId, innerHTML, value) {
  var div = $("<div>");
  var input = $("<input>")
    .addClass("entity-name-field")
    .attr("type", "hidden")
    .attr("name", "employee_names[" + newRowId + "][employee_name]")
    .val(value)
    .prop("readonly", true);
  var span = $("<span>").addClass("form-control").text(innerHTML);
  div.append(input, span);

  return div;
}
function createHoursField(newRowId, daysDetails, totalHours) {
  var div = $("<div>");
  var input = $("<input>")
    .addClass("entity-name-field")
    .attr("type", "hidden")
    .attr("name", "days_details[" + newRowId + "][day_details]")
    .val(JSON.stringify(daysDetails))
    .prop("readonly", true);
  var span = $("<span>")
    .addClass("form-control")
    .text(totalHours ? totalHours : 0);
  div.append(input, span);
  return div;
}

//for notes

$(document).on("click", ".note-header", function () {
  var $note = $(this).closest(".note");
  $note.find(".edit-note-form").toggle();
  $note.find(".note-comment").toggle();
});

$(document).on("click", ".delete-note", function () {
  var noteId = $(this).data("note-id");
  var sourceName = $(this).data("source-name");
  if (noteId) {
    if (confirm("Are you sure you want to delete this note?")) {
      $.ajax({
        url: `/admin/${sourceName}/delete_note`,
        type: "POST",
        data: {
          note_id: noteId,
        },
        dataType: "json",
        success: function (response) {
          location.reload();
        },
        error: function (error) {},
      });
    }
  }
});

$(document).on("click", ".delete-file", function (event) {
  event.stopPropagation();
  var fileId = $(this).data("file-id");
  var id = $(this).data("id");
  var source = $(this).data("source");
  console.log("id fileid source===>", id, fileId, source);
  if (fileId) {
    if (confirm("Are you sure you want to delete this file?")) {
      $.ajax({
        url: `/admin/${source}/${id}/delete_file`,
        type: "POST",
        data: {
          file_id: fileId,
        },
        dataType: "json",
        success: function (response) {
          location.reload();
        },
        error: function (error) {},
      });
    }
  }
});

//for the material custom buttons
$(document).on("click", ".material-custom-button", function () {
  var materialId = $(this).data("material-id");
  var methodName = $(this).data("method-name");
  var sourceName = $(this).data("source-name");
  var data = {
    id: materialId,
  };

  customButtonActonsMaterials(methodName, sourceName, data);
});

function customButtonActonsMaterials(actionName, source, data) {
  $.ajax({
    url: `/admin/${source}/${data.id}/${actionName}`,
    type: "POST",
    data: data,
    processData: false,
    contentType: false,
    success: function (response) {},
    error: function (error) {},
  });
}

$(document).on(
  "click",
  ".edit_project #tab-SpecificationCode .page-link",
  function () {
    event.preventDefault();
    var href = this.getAttribute("href");
    Turbolinks.visit(href + "#!tab-SpecificationCode");
  }
);

$(document).on(
  "click",
  ".edit_project #tab-SpecificationCode .discipline-filter",
  function () {
    // event.preventDefault();
    let localCodesData = localStorage.getItem("myData");
    let parsedData = [];
    let codeIds = "";
    if (localCodesData) {
      parsedData = JSON.parse(localCodesData);
      var pathArray = window.location.pathname.split("/");
      var projectId = pathArray[3];
      parsedData = parsedData.filter((item) => item.project_id == projectId);
      codeIds = parsedData.map((item) => item.code_id).join(",");
    }
    $(".discipline-filter").removeClass("active");
    $(this).addClass("active");
    var disciplineId = $(this).data("discipline-id");
    activeDisciplineId = disciplineId.toString();
    if (url.searchParams.has("discipline")) {
      url.searchParams.delete("discipline");
    }
    if (url.searchParams.has("codes")) {
      url.searchParams.delete("codes");
    }

    // Add the new "discipline" parameter
    url.searchParams.append("discipline", disciplineId);

    var pathname = url.pathname;
    var tab = `${url.search}`;
    var hash = url.hash;
    var routeUrl = `${url.pathname}${tab}&codes=${codeIds}${hash}`;

    Turbolinks.visit(routeUrl);
  }
);

$(document).on("click", ".edit_project .code-filter", function () {
  // event.preventDefault();
  $(".code-filter").removeClass("active");
  $(this).addClass("active");
  var code = $(this).data("code");
  activeCode = code.toString();
  if (url.searchParams.has("code")) {
    url.searchParams.delete("code");
  }

  // Add the new "discipline" parameter
  url.searchParams.append("code", code);
  var pathname = url.pathname;
  var tab = `${url.search}`;
  var hash = url.hash;
  var routeUrl = `${url.pathname}${tab}${hash}`;
  Turbolinks.visit(routeUrl);
});

$(document).on("click", ".app-nav li", function () {
  if (activeDisciplineId) {
    activeDisciplineId = "all";
  }
});

$(document).on(
  "click",
  ".edit_project #tab-SpecificationCode .page-link",
  function () {
    event.preventDefault();
    var href = this.getAttribute("href");
    Turbolinks.visit(href + "#!tab-SpecificationCode");
  }
);
$(document).on("ajax:error", "#new_tkc_cost", function (event) {
  const [data, status, xhr] = event.detail;

  if (data.errors.length > 0) {
    showAlertError(data.errors);
    if (
      data.errors.includes("Week heeft al Tkc") ||
      data.errors.includes("Week moet bestaan")
    ) {
      $(".select2-selection--single").removeClass("success-field");
      $('label[for="tkc_cost_week_id"]').removeClass("success-label");
      $(".select2-selection--single").addClass("error");
      $('label[for="tkc_cost_week_id"]').addClass("error-label");
    } else {
      $(".select2-selection--single").removeClass("error");
      $('label[for="tkc_cost_week_id"]').removeClass("error-label");
      $(".select2-selection--single").addClass("success-field");
      $('label[for="tkc_cost_week_id"]').addClass("success-label");
    }

    if (data.errors.includes("Omschrijving moet bestaan")) {
      $("#tkc_cost_description").removeClass("success-field");
      $('label[for="tkc_cost_description"]').removeClass("success-label");
      $("#tkc_cost_description").addClass("error");
      $('label[for="tkc_cost_description"]').addClass("error-label");
    } else {
      $("#tkc_cost_description").removeClass("error");
      $('label[for="tkc_cost_description"]').removeClass("error-label");
      $("#tkc_cost_description").addClass("success-field");
      $('label[for="tkc_cost_description"]').addClass("success-label");
    }
    if (data.errors.includes("Omschrijving TKC moet bestaan")) {
      $("#tkc_cost_tkc_description").removeClass("success-field");
      $('label[for="tkc_cost_tkc_description"]').removeClass("success-label");
      $("#tkc_cost_tkc_description").addClass("error");
      $('label[for="tkc_cost_tkc_description"]').addClass("error-label");
    } else {
      $("#tkc_cost_tkc_description").removeClass("error");
      $('label[for="tkc_cost_tkc_description"]').removeClass("error-label");
      $("#tkc_cost_tkc_description").addClass("success-field");
      $('label[for="tkc_cost_tkc_description"]').addClass("success-label");
    }
  }
});
$(document).on("ajax:error", "#new_invoice", function (event) {
  const [data, status, xhr] = event.detail;
  if (data.errors.length > 0) {
    showAlertError(data.errors);
    if (data.errors.includes("Opdrachtnemer kan niet leeg zijn")) {
      $(".select2-selection--single").removeClass("success-field");
      $('label[for="invoice_client_id"]').removeClass("success-label");
      $(".select2-selection--single").addClass("error");
      $('label[for="invoice_client_id"]').addClass("error-label");
    } else {
      $(".select2-selection--single").removeClass("error");
      $('label[for="invoice_client_id"]').removeClass("error-label");
      $(".select2-selection--single").addClass("success-field");
      $('label[for="invoice_client_id"]').addClass("success-label");
    }

    if (
      data.errors.includes("Factuurnummer moet worden toegevoegd") ||
      data.errors.includes("Factuurnummer bestaat al") ||
      data.errors.includes(
        "Factuurnummer is al in gebruik voor de geselecteerde opdrachtnemer"
      ) ||
      data.errors.includes(
        "Factuurnummer is al in gebruik voor de geselecteerde opdrachtgever"
      ) ||
      data.errors.includes("Factuurnummer al in gebruik")
    ) {
      $("#invoice_invoice_number").removeClass("success-field");
      $('label[for="invoice_invoice_number"]').removeClass("success-label");
      $("#invoice_invoice_number").addClass("error");
      $('label[for="invoice_invoice_number"]').addClass("error-label");
    } else {
      $("#invoice_invoice_number").removeClass("error");
      $('label[for="invoice_invoice_number"]').removeClass("error-label");
      $("#invoice_invoice_number").addClass("success-field");
      $('label[for="invoice_invoice_number"]').addClass("success-label");
    }
  }
});
$(document).on("ajax:error", "#new_debit_invoice", function (event) {
  const [data, status, xhr] = event.detail;
  if (data.errors.length > 0) {
    showAlertError(data.errors);
    if (data.errors.includes("Opdrachtnemer kan niet leeg zijn")) {
      $(".select2-selection--single").removeClass("success-field");
      $('label[for="debit_invoice_client_id"]').removeClass("success-label");
      $(".select2-selection--single").addClass("error");
      $('label[for="debit_invoice_client_id"]').addClass("error-label");
    } else {
      $(".select2-selection--single").removeClass("error");
      $('label[for="debit_invoice_client_id"]').removeClass("error-label");
      $(".select2-selection--single").addClass("success-field");
      $('label[for="debit_invoice_client_id"]').addClass("success-label");
    }

    if (
      data.errors.includes("Factuurnummer moet worden toegevoegd") ||
      data.errors.includes("Factuurnummer bestaat al") ||
      data.errors.includes("Factuurnummer al in gebruik")
    ) {
      $("#debit_invoice_invoice_number").removeClass("success-field");
      $('label[for="debit_invoice_invoice_number"]').removeClass(
        "success-label"
      );
      $("#debit_invoice_invoice_number").addClass("error");
      $('label[for="debit_invoice_invoice_number"]').addClass("error-label");
    } else {
      $("#debit_invoice_invoice_number").removeClass("error");
      $('label[for="debit_invoice_invoice_number"]').removeClass("error-label");
      $("#debit_invoice_invoice_number").addClass("success-field");
      $('label[for="debit_invoice_invoice_number"]').addClass("success-label");
    }
  }
});
function showAlertError(errors) {
  // Join the errors with a comma
  var errorMessage = errors.join(", ");
  var modalFlash = $(".alert-dismissable");
  var alertContentDiv = modalFlash.find(".alert-content");
  if (alertContentDiv.length > 0) {
    alertContentDiv.html(`<p>${errorMessage}</p>`);
  } else {
    var alertHtml = `
    <div class="alert alert-dismissable alert-danger" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      <i class="alert-icon far fa-times-circle"></i>
      <div class="alert-content">
        <p>${errorMessage}</p>
      </div>
    </div>
  `;

    // Prepend the alert to the main-content-area
    $(".main-content-area").prepend(alertHtml);
  }
  // Create the alert HTML
}
function showAlertErrorInModal(error) {
  var modalFlash = $(".modal-flash");

  // Text you want to add
  var alertText = error;

  // Check if alert-content div already exists
  var alertContentDiv = modalFlash.find(".alert-content");
  var alertDiv = modalFlash.find(".alert-danger");
  if (alertContentDiv.length > 0 && alertDiv.length > 0) {
    // If it exists, overwrite its content
    alertContentDiv.text(alertText);
  } else {
    // If it doesn't exist, create a new alert div
    var alertDiv = $("<div>").addClass(
      "alert alert-dismissible alert-danger modal-flash-alert-content"
    );
    var closeButton = $("<button>")
      .addClass("close modal-flash-close-button")
      .attr("type", "button")
      .attr("data-dismiss", "alert");
    closeButton.append($("<span>").attr("aria-hidden", "true").html("&times;"));
    alertDiv.append(closeButton); // Appending close button
    alertContentDiv = $("<div>").addClass("alert-content").text(alertText); // Appending alert content div with text
    alertDiv.append(alertContentDiv);
    modalFlash.append(alertDiv);
  }
}
// $(document).on("ajax:success", "#new_project", function (event) {
//   const firstDigit = parseInt(event.detail[2].status.toString()[0]);
//   if (firstDigit == 2) {
//     if (url) {
//       var pathname = url.pathname;
//       var tab = url.search;
//       var hash = url.hash;
//       routeUrl = `${url.pathname}${tab}${hash}`;
//       console.log("route url===>", routeUrl);
//       location.reload();
//     }
//   }
// });
$(document).on("ajax:error", "#edit_project", function (event) {
  const [data, status, xhr] = event.detail;

  if (data.errors.length > 0) {
    showAlertError(data.errors);
    if (data.errors.includes("Opdrachtgever moet worden geselecteerd")) {
      $("#project_client_id + .select2 .select2-selection--single").removeClass(
        "success-field"
      );
      $('label[for="project_client_id"]').removeClass("success-label");
      $("#project_client_id + .select2 .select2-selection--single").addClass(
        "error"
      );
      $('label[for="project_client_id"]').addClass("error-label");
    } else {
      $("#project_client_id + .select2 .select2-selection--single").removeClass(
        "error"
      );
      $('label[for="project_client_id"]').removeClass("error-label");
      $("#project_client_id + .select2 .select2-selection--single").addClass(
        "success-field"
      );
      $('label[for="project_client_id"]').addClass("success-label");
    }

    if (
      data.errors.includes("Projectnummer moet bestaan") ||
      data.errors.includes("Projectnummer Bestaat al met hetzelfde nummer")
    ) {
      $("#project_projectnumber").removeClass("success-field");
      $('label[for="project_projectnumber"]').removeClass("success-label");
      $("#project_projectnumber").addClass("error");
      $('label[for="project_projectnumber"]').addClass("error-label");
    } else {
      $("#project_projectnumber").removeClass("error");
      $('label[for="project_projectnumber"]').removeClass("error-label");
      $("#project_projectnumber").addClass("success-field");
      $('label[for="project_projectnumber"]').addClass("success-label");
    }
    if (data.errors.includes("Startdatum moet bestaan")) {
      $("#project_start_date").removeClass("success-field");
      $('label[for="project_start_date"]').removeClass("success-label");
      $("#project_start_date").addClass("error");
      $('label[for="project_start_date"]').addClass("error-label");
    } else {
      $("#project_start_date").removeClass("error");
      $('label[for="project_start_date"]').removeClass("error-label");
      $("#project_start_date").addClass("success-field");
      $('label[for="project_start_date"]').addClass("success-label");
    }
    if (data.errors.includes("Einddatum moet bestaan")) {
      $("#project_end_date").removeClass("success-field");
      $('label[for="project_end_date"]').removeClass("success-label");
      $("#project_end_date").addClass("error");
      $('label[for="project_end_date"]').addClass("error-label");
    } else {
      $("#project_end_date").removeClass("error");
      $('label[for="project_end_date"]').removeClass("error-label");
      $("#project_end_date").addClass("success-field");
      $('label[for="project_end_date"]').addClass("success-label");
    }
  }
});
$(document).on("ajax:error", "#new_project", function (event) {
  const [data, status, xhr] = event.detail;

  if (data.errors.length > 0) {
    showAlertError(data.errors);
    if (data.errors.includes("Opdrachtgever moet worden geselecteerd")) {
      $("#project_client_id + .select2 .select2-selection--single").removeClass(
        "success-field"
      );
      $('label[for="project_client_id"]').removeClass("success-label");
      $("#project_client_id + .select2 .select2-selection--single").addClass(
        "error"
      );
      $('label[for="project_client_id"]').addClass("error-label");
    } else {
      $("#project_client_id + .select2 .select2-selection--single").removeClass(
        "error"
      );
      $('label[for="project_client_id"]').removeClass("error-label");
      $("#project_client_id + .select2 .select2-selection--single").addClass(
        "success-field"
      );
      $('label[for="project_client_id"]').addClass("success-label");
    }

    if (
      data.errors.includes("Projectnummer moet bestaan") ||
      data.errors.includes("Projectnummer Bestaat al met hetzelfde nummer")
    ) {
      $("#project_projectnumber").removeClass("success-field");
      $('label[for="project_projectnumber"]').removeClass("success-label");
      $("#project_projectnumber").addClass("error");
      $('label[for="project_projectnumber"]').addClass("error-label");
    } else {
      $("#project_projectnumber").removeClass("error");
      $('label[for="project_projectnumber"]').removeClass("error-label");
      $("#project_projectnumber").addClass("success-field");
      $('label[for="project_projectnumber"]').addClass("success-label");
    }
    if (data.errors.includes("Startdatum moet bestaan")) {
      $("#project_start_date").removeClass("success-field");
      $('label[for="project_start_date"]').removeClass("success-label");
      $("#project_start_date").addClass("error");
      $('label[for="project_start_date"]').addClass("error-label");
    } else {
      $("#project_start_date").removeClass("error");
      $('label[for="project_start_date"]').removeClass("error-label");
      $("#project_start_date").addClass("success-field");
      $('label[for="project_start_date"]').addClass("success-label");
    }
    if (data.errors.includes("Einddatum moet bestaan")) {
      $("#project_end_date").removeClass("success-field");
      $('label[for="project_end_date"]').removeClass("success-label");
      $("#project_end_date").addClass("error");
      $('label[for="project_end_date"]').addClass("error-label");
    } else {
      $("#project_end_date").removeClass("error");
      $('label[for="project_end_date"]').removeClass("error-label");
      $("#project_end_date").addClass("success-field");
      $('label[for="project_end_date"]').addClass("success-label");
    }
  }
});
$(document).on("ajax:success", "#edit_project", function (event) {
  const firstDigit = parseInt(event.detail[2].status.toString()[0]);
  if (firstDigit == 2) {
    var dataArray = localStorage.getItem("myData") || [];
    var routeUrl = null;
    if (url) {
      var pathname = url.pathname;
      var tab = url.search;
      var hash = url.hash;
    }

    if (tab && pathname && hash) {
      routeUrl = `${url.pathname}${tab}${hash}`;
    }
    var data = {
      specification_codes: dataArray,
    };

    if (dataArray.length !== 0) {
      $("#loader-overlay").show();
      $.ajax({
        url: `${url.pathname}/create_spec_codes`,
        type: "POST",
        data: data,
        dataType: "json",
        success: function (response) {
          let parsedData = JSON.parse(dataArray);
          var pathArray = window.location.pathname.split("/");
          var projectId = pathArray[3];
          if (parsedData && parsedData.length > 0) {
            parsedData = parsedData.filter(
              (item) => item.project_id != projectId
            );
            localStorage.setItem("myData", JSON.stringify(parsedData));
          } else {
            localStorage.removeItem("myData");
          }

          $("#loader-overlay").hide();

          Turbolinks.visit(routeUrl);
        },
        error: function (error) {
          Turbolinks.visit(routeUrl);
        },
      });
    } else {
      Turbolinks.visit(routeUrl);
    }
  }
});

//for clients warning
$(document).on("click", "#confirm-button", function () {
  let inputFieldForClientWarning = $("#client_warning_text");
  if (inputFieldForClientWarning.length > 0) {
    existingValues = inputFieldForClientWarning.val();
    let newValues = existingValues ? existingValues.split(",") : [];
    let clientName = null;
    if ($("#client_client_name").length > 0) {
      clientName = $("#client_client_name").val();
    }
    if ($("#contractor_contractor_name").length > 0) {
      clientName = $("#contractor_contractor_name").val();
    }

    if (!newValues.includes(clientName)) {
      newValues.push(clientName);
    }

    $("#client_warning_text").val(newValues.join(","));
  }

  $(".warning .modal").css("display", "none");
});

$(document).on("ajax:error", "#new_client", function (event) {
  let checkModalExist = $(".modal");

  const [data, status, xhr] = event.detail;

  if (data.errors.length > 0) {
    if (data.errors.includes("client already exist")) {
      $(".warning .modal").css("display", "block");
    }
  }

  if (data.errors.length > 0 && !data.errors.includes("client already exist")) {
    if (checkModalExist.length > 1) {
      showAlertErrorInModal(data.errors);
    } else {
      showAlertError(data.errors);
    }
    if (
      data.errors.includes("E-mail al in gebruik") ||
      data.errors.includes("E-mail moet worden toegevoegd")
    ) {
      $("#client_email").removeClass("success-field");
      $('label[for="client_email"]').removeClass("success-label");
      $("#client_email").addClass("error");
      $('label[for="client_email"]').addClass("error-label");
    } else {
      $("#client_email").removeClass("error");
      $('label[for="client_email"]').removeClass("error-label");
      $("#client_email").addClass("success-field");
      $('label[for="client_email"]').addClass("success-label");
    }

    if (
      data.errors.includes("ID/Nummer al in gebruik") ||
      data.errors.includes("ID/Nummer moet worden toegevoegd")
    ) {
      $("#client_client_id").removeClass("success-field");
      $('label[for="client_client_id"]').removeClass("success-label");
      $("#client_client_id").addClass("error");
      $('label[for="client_client_id"]').addClass("error-label");
    } else {
      $("#client_client_id").removeClass("error");
      $('label[for="client_client_id"]').removeClass("error-label");
      $("#client_client_id").addClass("success-field");
      $('label[for="client_client_id"]').addClass("success-label");
    }

    if (data.errors.includes("Opdrachtgevernaam moet worden toegevoegd")) {
      $("#client_client_name").removeClass("success-field");
      $('label[for="client_client_name"]').removeClass("success-label");
      $("#client_client_name").addClass("error");
      $('label[for="client_client_name"]').addClass("error-label");
    } else {
      $("#client_client_name").removeClass("error");
      $('label[for="client_client_name"]').removeClass("error-label");
      $("#client_client_name").addClass("success-field");
      $('label[for="client_client_name"]').addClass("success-label");
    }
  }
});

$(document).on("ajax:error", "#new_contractor", function (event) {
  let checkModalExist = $(".modal");

  const [data, status, xhr] = event.detail;

  if (data.errors.length > 0) {
    if (data.errors.includes("contractor already exist")) {
      $(".warning .modal").css("display", "block");
    }
  }

  if (
    data.errors.length > 0 &&
    !data.errors.includes("contractor already exist")
  ) {
    if (checkModalExist.length > 1) {
      showAlertErrorInModal(data.errors);
    } else {
      showAlertError(data.errors);
    }
    if (
      data.errors.includes("E-mail al in gebruik") ||
      data.errors.includes("E-mail moet worden toegevoegd")
    ) {
      $("#contractor_email").removeClass("success-field");
      $('label[for="contractor_email"]').removeClass("success-label");
      $("#contractor_email").addClass("error");
      $('label[for="contractor_email"]').addClass("error-label");
    } else {
      $("#contractor_email").removeClass("error");
      $('label[for="contractor_email"]').removeClass("error-label");
      $("#contractor_email").addClass("success-field");
      $('label[for="contractor_email"]').addClass("success-label");
    }

    if (
      data.errors.includes("ID/Nummer al in gebruik") ||
      data.errors.includes("ID/Nummer moet worden toegevoegd")
    ) {
      $("#contractor_contractor_id").removeClass("success-field");
      $('label[for="contractor_contractor_id"]').removeClass("success-label");
      $("#contractor_contractor_id").addClass("error");
      $('label[for="contractor_contractor_id"]').addClass("error-label");
    } else {
      $("#contractor_contractor_id").removeClass("error");
      $('label[for="contractor_contractor_id"]').removeClass("error-label");
      $("#contractor_contractor_id").addClass("success-field");
      $('label[for="contractor_contractor_id"]').addClass("success-label");
    }

    if (data.errors.includes("Opdrachtnemer moet worden toegevoegd")) {
      $("#contractor_contractor_name").removeClass("success-field");
      $('label[for="contractor_contractor_name"]').removeClass("success-label");
      $("#contractor_contractor_name").addClass("error");
      $('label[for="contractor_contractor_name"]').addClass("error-label");
    } else {
      $("#contractor_contractor_name").removeClass("error");
      $('label[for="contractor_contractor_name"]').removeClass("error-label");
      $("#contractor_contractor_name").addClass("success-field");
      $('label[for="contractor_contractor_name"]').addClass("success-label");
    }
  }
});

$(document).on("blur", ".total-budget-field", function () {
  var inputValue = $(this).val();
  var projectId = $(this).data("project-id");
  var codeId = $(this).data("code-id");
  var dataArray = JSON.parse(localStorage.getItem("myData")) || [];
  var index = findIndexByProjectCode(dataArray, projectId, codeId);

  if (index !== -1) {
    // Update the total_budget for an existing entry
    dataArray[index].total_budget = inputValue;
  } else {
    // Add a new entry to the array
    var dataObject = {
      project_id: projectId,
      code_id: codeId,
      total_budget: inputValue,
    };
    dataArray.push(dataObject);
  }

  localStorage.setItem("myData", JSON.stringify(dataArray));
});

function findIndexByProjectCode(dataArray, projectId, codeId) {
  for (var i = 0; i < dataArray.length; i++) {
    if (
      dataArray[i].project_id === projectId &&
      dataArray[i].code_id === codeId
    ) {
      return i;
    }
  }
  return -1;
}

function getSpecficationCodeData() {
  var dataArray = JSON.parse(localStorage.getItem("myData")) || [];
  dataArray.forEach(function (dataObject) {
    var projectId = dataObject.project_id;
    var codeId = dataObject.code_id;
    var totalBudget = dataObject.total_budget;
    var $inputField = $(
      `.total-budget-field[data-project-id="${projectId}"][data-code-id="${codeId}"]`
    );
    if ($inputField.length > 0) {
      $inputField.after('<span class="asterisk">*</span>');
      $inputField.val(totalBudget);
    }
  });
}

//for attachments in materials
$(document).on("click", "#add-dynamic-attachment-button", addDynamicAttachment);

function addDynamicAttachment() {
  var container = $("#dynamic-attachments-container");
  var index = new Date().getTime();

  var newRow = createDynamicAttachmentRow(index);
  container.append(newRow);
}

function createDynamicAttachmentRow(index) {
  var newRow = $("<div>").addClass("dynamic-attachment-fields");

  var titleField = createDynamicTitleField(index);
  var fileInput = createDynamicFileInput(index);
  // var deleteButton = createDeleteButton()

  newRow.append(titleField, fileInput);

  // newRow.append(titleField, fileInput);
  return newRow;
}

function createDynamicTitleField(index) {
  var titleField = $("<div>").addClass("form-group");
  titleField.append(
    $("<label>")
      .attr({
        for: "material_material_attachments_attributes_" + index + "_title",
      })
      .css("font-weight", "bold")
      .text("Titel"),
    $("<input>")
      .addClass("form-control attachment-title-field")
      .attr({
        type: "text",
        name: "material[material_attachments_attributes][" + index + "][title]",
        id: "material_material_attachments_attributes_" + index + "_title",
        placeholder: "Title",
      })
  );

  return titleField;
}

function createDynamicFileInput(index) {
  var fileInput = $("<div>")
    .addClass("form-group")
    .addClass("attachment-field-gap");
  var inputContainer = $("<div>").addClass("custom-file");

  var inputFile = $("<input>")
    .addClass("custom-file-input")
    .attr({
      type: "file",
      name:
        "material[material_attachments_attributes][" +
        index +
        "][attachment][]",
      id: "material_material_attachments_attributes_" + index + "_attachment",
      onchange: "displayFileName(this)",
    });

  var fileNameLabel = $("<label>")
    .addClass("custom-file-label")
    .attr({
      "data-browse": "Browse",
      for: "material_material_attachments_attributes_" + index + "_attachment",
    })
    .text("Choose file...");

  inputContainer.append(inputFile, fileNameLabel);
  fileInput.append(
    $("<label>")
      .attr({
        for:
          "material_material_attachments_attributes_" + index + "_attachment",
      })
      .css("font-weight", "bold")
      .text("Bijlagen"),
    inputContainer
  );

  return fileInput;
}

function createDeleteButton() {
  var deleteButton = $("<button>")
    .addClass("btn btn-danger delete-attachment-button")
    .text("Delete");
  deleteButton.on("click", function () {
    $(this).closest(".dynamic-attachment-fields").remove();
  });

  return deleteButton;
}

function displayFileName(input) {
  var fileName = $(input).val().split("\\").pop();
  var fileNameLabel = $(input).next(".custom-file-label");
  fileNameLabel.text(fileName);
}

//for dynamically set g_account_value in finance

$(document).on("input", "#finance_c_account_percentage", function () {
  var total = 100;
  let cAccountValue = parseFloat($(this).val());
  // let percentageAddValue = parseFloat(exclueValue + exclueValue * 0.21);
  if (cAccountValue > 0) {
    $("#finance_g_account_percentage").val(total - cAccountValue);
    $("#g_account_percentage_hidden").val(total - cAccountValue);
  } else {
    $("#finance_g_account_percentage").val(0.0);
    $("#g_account_percentage_hidden").val(0.0);
  }
});

$(document).on(
  "input",
  "#contractor_finance_c_account_percentage",
  function () {
    var total = 100;
    let cAccountValue = parseFloat($(this).val());
    // let percentageAddValue = parseFloat(exclueValue + exclueValue * 0.21);
    if (cAccountValue > 0) {
      $("#contractor_finance_g_account_percentage").val(total - cAccountValue);
      $("#g_account_percentage_hidden").val(total - cAccountValue);
    } else {
      $("#contractor_finance_g_account_percentage").val(0.0);
      $("#g_account_percentage_hidden").val(0.0);
    }
  }
);

//for smooth navigation
window.addEventListener("popstate", function () {
  const routeName = sessionStorage.getItem("routeName");
  if (routeName) {
    removeRouteLocally();
    Turbolinks.visit(routeName);
  }
});

function setRouteLocally() {
  var pathname = url.pathname;
  var tab = url.search;
  var hash = url.hash;
  var routeUrl = `${url.pathname}${tab}${hash}`;
  // sessionStorage.setItem("id", id);
  sessionStorage.setItem("routeName", routeUrl);
}
function removeRouteLocally() {
  sessionStorage.setItem("routeName", "");
}
