import * as React from "react";
import { createRoot } from "react-dom/client";
import SettingList from "../components/SettingList";

export default function Setting() {
  return <SettingList />;
}

createRoot(document.getElementById("main")).render(<Setting />);
