import * as React from "react";
import { createRoot } from "react-dom/client";
import EmployeesDetails from "../components/EmployeesDetails/EmployeesDetails";

export default function Employees() {
  return <EmployeesDetails />;
}

createRoot(document.getElementById("main")).render(<Employees />);
