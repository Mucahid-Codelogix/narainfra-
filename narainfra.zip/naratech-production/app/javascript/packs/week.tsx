import * as React from "react";
import { createRoot } from "react-dom/client";
import WeekOverview from "../components/WeekOverview";

export default function Week() {
  return <WeekOverview />;
}

createRoot(document.getElementById("main")).render(<Week />);
