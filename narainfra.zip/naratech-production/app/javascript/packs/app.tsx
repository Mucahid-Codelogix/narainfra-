import * as React from "react";
import { createRoot } from "react-dom/client";
import GanttChart from "../components/GanttChart";

export default function App() {
  return <GanttChart />;
}

createRoot(document.getElementById("main")).render(<App />);
