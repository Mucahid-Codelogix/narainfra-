import * as React from "react";
import { createRoot } from "react-dom/client";
import InvoiceList from "../components/InvoiceList";

export default function Invoice() {
  return <InvoiceList source={"invoice"} />;
}

createRoot(document.getElementById("main")).render(<Invoice />);
