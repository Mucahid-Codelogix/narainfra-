import * as React from "react";
import { createRoot } from "react-dom/client";
import EmployeeSchedulingList from "../components/EmployeeSchedulingList";

export default function Employeecheduling() {
  return <EmployeeSchedulingList/>;
}

createRoot(document.getElementById("main")).render(<Employeecheduling />);