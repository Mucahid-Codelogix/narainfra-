import * as React from "react";
import { createRoot } from "react-dom/client";
import InvoiceQuoteList from "../components/InvoiceQuoteList";

export default function DebitInvoiceQuote() {
  return <InvoiceQuoteList />;
}

createRoot(document.getElementById("main")).render(<DebitInvoiceQuote />);
