import * as React from "react";
import { createRoot } from "react-dom/client";
import TotalWeekOverviewList from "../components/TotalWeekOverviewList"

export default function TotalWeekOverview() {
  console.log("TotalWeekOverview")
  return <TotalWeekOverviewList />;
}

createRoot(document.getElementById("main")).render(<TotalWeekOverview />);
