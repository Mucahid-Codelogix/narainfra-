import * as React from "react";
import { createRoot } from "react-dom/client";
import ContractorContactPersonList from "../components/ContractorContactPerson/ContractorContactPersonList";

export default function ContractorContactPersons() {
  return <ContractorContactPersonList />;
}

createRoot(document.getElementById("main")).render(<ContractorContactPersons />);
