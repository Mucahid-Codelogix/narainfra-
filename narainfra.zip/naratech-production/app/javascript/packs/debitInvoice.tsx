import * as React from "react";
import { createRoot } from "react-dom/client";
import InvoiceList from "../components/InvoiceList";

export default function DebitInvoice() {
  return <InvoiceList source={"debitinvoice"}/>;
}

createRoot(document.getElementById("main")).render(<DebitInvoice />);
