require("@rails/activestorage").start()

require("trix")
require("@rails/actiontext")