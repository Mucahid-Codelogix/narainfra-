import Activity from "./Activity";
import Project from "./Project";

export default interface Data {
  project: Project;
  activities: Activity[];
}
