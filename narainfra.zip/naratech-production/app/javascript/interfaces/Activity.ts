export default interface Activity {
  plan_start_date: string;
  plan_end_date: string;
  activity_name: string;
  id: number;
  activity_color: string;
  teams: string[];
}
