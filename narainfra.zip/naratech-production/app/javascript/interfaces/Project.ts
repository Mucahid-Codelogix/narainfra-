export default interface Project {
  id: number;
  client_id: number;
  user_id: number;
  projectnumber: string;
  projectleader: string;
  projectperformer: string;
  contactpersoon: string;
  place: string;
  supervisor: string;
  address: string;
  zip_code: string;
  start_date: string;
  end_date: string;
  archived: boolean;
  created_at: string;
  updated_at: string;
  tbs:boolean
}
