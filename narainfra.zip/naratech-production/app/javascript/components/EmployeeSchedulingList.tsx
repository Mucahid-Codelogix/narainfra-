import React, { useEffect, useState } from "react";
import axios from "axios";
const EmployeeSchedulingList = () => {
  const [schedulings, setSchedulings] = useState([]);
  const [projects, setProjects] = useState([]);
  const [expandedProjectIds, setExpandedProjectIds] = useState([]);
  const [count, setCount] = useState(null);
  const getSchedlingData = () => {
    axios
      .get(`/admin/employee_schedulings/fetch_employee_schedulings`)
      .then((res) => {
        if (res.data.projects.length > 0) {
          setProjects(res.data.projects);
        }
        if (res.data.schedulings.length > 0) {
          setSchedulings(res.data.schedulings);
        }
        setCount(res.data.count);
      });
  };

  useEffect(() => {
    getSchedlingData();
  }, []);

  const calculateHours = (employeeScheduling, week) => {
    let totalHours = 0;
    let scheduleDates = employeeScheduling.schedule_dates;
    let weekDays = week.days;
    if (scheduleDates && scheduleDates.length > 0) {
      scheduleDates.forEach((schedule) => {
        const dayName = schedule.day_name.toLowerCase();
        if (weekDays.some((day) => day.day_name.toLowerCase() === dayName)) {
          totalHours += parseInt(schedule.hours);
        }
      });
    }

    return totalHours;
  };
  const toggleProjectDetails = (projectId) => {
    setExpandedProjectIds((prevIds) =>
      prevIds.includes(projectId)
        ? prevIds.filter((id) => id !== projectId)
        : [...prevIds, projectId]
    );
  };
  return (
    <main className="app-main" data-context="/admin/employee_schedulings">
      <header className="content-header">
        <div className="content-header-title">
          <h1>Lijst van Urenregistratie</h1>
        </div>
        <div className="content-header-toolbars">
          <div className="btn-toolbar primary-toolbar" role="toolbar">
            <a
              className="btn-new-resource btn btn-light has-icon"
              href="/admin/employee_schedulings/new"
            >
              <i className="fa fa-plus"></i>{" "}
              <span className="btn-label">New Urenregistratie</span>
            </a>
          </div>
          <div className="btn-toolbar secondary-toolbar" role="toolbar"></div>
        </div>
      </header>
      <div className="main-content-area">
        <div className="main-content-container">
          <div className="main-content">
            <div className="table-container">
              <table className="trestle-table">
                <thead>
                  <tr>
                    <th className="">Projecten</th>
                    <th className="">Plaats</th>
                    <th className="">Uitvoerder</th>
                  </tr>
                </thead>
                <tbody>
                  {projects.map((project, index) => (
                    <React.Fragment key={project.id}>
                      <tr
                        style={{
                          cursor: "pointer",
                        }}
                        onClick={() => toggleProjectDetails(project.id)}
                      >
                        <td style={{ fontWeight: "bold" }}>
                          {expandedProjectIds.includes(project.id)
                            ? "▼ "
                            : "► "}
                          {project.projectnumber}
                        </td>
                        <td>{project.place}</td>
                        <td>{project.projectperformer}</td>
                      </tr>
                      {expandedProjectIds.includes(project.id) && (
                        <tr>
                          <td colSpan={3}>
                            <div className="table-container inner-table">
                              <table
                                className="trestle-table"
                                style={{ width: "100%" }}
                              >
                                <thead>
                                  <tr>
                                    <th>Werknemer</th>
                                    <th>Week</th>
                                    <th>Gewerkte uren</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {schedulings
                                    .filter((s) => s.project.id === project.id)
                                    .sort((a, b) => {
                                      const dateA: any = new Date(
                                        a.week.start_date
                                      );
                                      const dateB: any = new Date(
                                        b.week.start_date
                                      );

                                      // Handle cases where start_date is null or not a valid date
                                      if (isNaN(dateA.getTime())) return -1;
                                      if (isNaN(dateB.getTime())) return 1;

                                      return dateA - dateB;
                                    })
                                    .map((s) => (
                                      <tr
                                        key={s.id}
                                        data-url={`/admin/employee_schedulings/${s.id}`}
                                      >
                                        <td>
                                          {s.employee.first_name}{" "}
                                          {s.employee.last_name}
                                        </td>
                                        <td>{s.week.week_number}</td>
                                        <td>{calculateHours(s, s.week)}</td>
                                        {/* <td className="actions">
                                          <a
                                            data-toggle="confirm-delete"
                                            data-placement="left"
                                            className="btn btn-danger has-icon"
                                            rel="nofollow"
                                            data-method="delete"
                                            href={`/admin/employee_schedulings/${s.id}`}
                                            data-original-title=""
                                            title=""
                                          >
                                            <i className="fa fa-trash"></i>{" "}
                                            <span className="btn-label">
                                              Urenregistratie verwijderen
                                            </span>
                                          </a>
                                        </td> */}
                                      </tr>
                                    ))}
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
            <footer className="main-content-footer">
              <nav className="pagination-container">
                <p>
                  <strong>Alle {count}</strong> Urenregistratie worden weergeven
                </p>
              </nav>
            </footer>
          </div>
        </div>
      </div>
    </main>
  );
};
export default EmployeeSchedulingList;
