import React from "react";
const InvoiceSetting = ({ data }) => {
  function wordToNumber(word) {
    const wordToNumberMap = {
      one: 1,
      two: 2,
      three: 3,
      four: 4,
      five: 5,
      six: 6,
      seven: 7,
      eight: 8,
      nine: 9,
      ten: 10,
    };

    return wordToNumberMap[word];
  }
  return (
    <>
      {data && data?.length === 0 && (
        <button
          id="add-invoice-setting-button"
          className="btn btn-primary custom_buttons_settings"
          type="button"
          data-project-id="27"
          onClick={() => (window.location.href = "/admin/invoice_settings/new")}
        >
          Factuurinstelling toevoegen
        </button>
      )}

      <div className="table-container setting-table">
        <table className="trestle-table">
          <thead>
            <tr>
              <th className="">
                <a
                //   className="sort"
                //   href="/admin/invoice_settings?order=asc&amp;sort=year"
                >
                  Jaar
                </a>
              </th>
              <th className="">
                <a
                //   className="sort"
                //   href="/admin/invoice_settings?order=asc&amp;sort=characters"
                >
                  Voorloopteken(s)
                </a>
              </th>
              <th className="">Aantal cijfers</th>
              <th className="actions"></th>
            </tr>
          </thead>

          <tbody>
            {data.map((invoiceSetting) => (
              <tr
                style={{
                  cursor: "pointer",
                }}
                key={invoiceSetting.id}
                onClick={() => {
                  return (window.location.href = `/admin/invoice_settings/${invoiceSetting.id}`);
                }}
              >
                <td className="">{invoiceSetting.year}</td>
                <td className="">{invoiceSetting.characters}</td>
                <td className="">
                  {wordToNumber(invoiceSetting.digits_length)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};
export default InvoiceSetting;
