import React from "react";
const InvoiceSetting = ({ data }) => {
  return (
    <>
      {data && data?.length === 0 && (
        <button
          id="add-invoice-setting-button"
          className="btn btn-primary custom_buttons_settings"
          type="button"
          data-project-id="27"
          onClick={() => (window.location.href = "/admin/project_settings/new")}
        >
          Projectinstelling toevoegen
        </button>
      )}

      <div className="table-container setting-table">
        <table className="trestle-table">
          <thead>
            <tr>
              <th className="">
                <a
                //   className="sort"
                //   href="/admin/invoice_settings?order=asc&amp;sort=year"
                >
                  Ak cost
                </a>
              </th>
            </tr>
          </thead>

          <tbody>
            {data.map((projectSetting) => (
              <tr
                style={{
                  cursor: "pointer",
                }}
                key={projectSetting.id}
                onClick={() => {
                  return (window.location.href = `/admin/project_settings/${projectSetting.id}`);
                }}
              >
                <td className="">{projectSetting.ak_cost}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};
export default InvoiceSetting;
