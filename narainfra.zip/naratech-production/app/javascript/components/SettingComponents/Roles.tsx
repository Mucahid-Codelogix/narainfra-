import React from "react";
const Roles = ({ data, count }) => {
  return (
    <>
      <button
        id="add-invoice-setting-button"
        className="btn btn-primary custom_buttons_settings"
        type="button"
        data-project-id="27"
        onClick={() => (window.location.href = "/admin/roles/new")}
      >
        Functies toevoegen
      </button>

      <div className="table-container setting-table">
        <table className="trestle-table">
          <thead>
            <tr>
              <th className="">
                <a
                //   className="sort"
                //   href="/admin/roles?order=asc&amp;sort=role_title"
                >
                  Functietitel
                </a>
              </th>
            </tr>
          </thead>

          <tbody>
            {data.map((role) => (
              <tr
                style={{
                  cursor: "pointer",
                }}
                key={role.id}
                onClick={() => {
                  return (window.location.href = `/admin/roles/${role.id}`);
                }}
              >
                <td className="">{role.role_title}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <footer className="main-content-footer">
        <nav className="pagination-container">
          <p>
            <strong>Alle {count}</strong> Functies worden weergeven
          </p>
        </nav>
      </footer>
    </>
  );
};
export default Roles;
