import React, { useEffect, useState } from "react";
import InvoiceSetting from "./SettingComponents/InvoiceSetting";
import Roles from "./SettingComponents/Roles";
import CertificateType from "./SettingComponents/CertificateType";
import ProjectSetting from "./SettingComponents/ProjectSetting"
import axios from "axios";

const SettingList = () => {
  const [activeTab, setActiveTab] = useState("invoice_setting");
  const [invoiceSetting, setInvoiceSetting] = useState([]);
  const [projectSetting, setProjectSetting] = useState([]);
  const [certificateTypes, setCertificateTypes] = useState([]);
  const [count, setCount] = useState(0);
  const [roles, setRoles] = useState([]);
  const getData = (tab) => {
    const timestamp = Date.now();
    axios
      .get(
        `/admin/invoice_settings/fetch_invoice_settings?type=${tab}&_=${timestamp}`
      )
      .then((res) => {
        console.log("res===>",res)
        if (res.data.invoice_settings.length > 0) {
          setInvoiceSetting(res.data.invoice_settings);
        } else if (res.data.project_settings.length > 0) {
          setProjectSetting(res.data.project_settings);
        } else if (res.data.certificate_types.length > 0) {
          setCertificateTypes(res.data.certificate_types);
          setCount(res.data.count);
        } else if (res.data.roles.length > 0) {
          setRoles(res.data.roles);
          setCount(res.data.count);
        } else {
          setCount(0);
        }
      });
  };
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get("type");
    if (type) {
      setActiveTab(type);
    } else {
      setActiveTab("invoice_setting"); // Set default tab
    }
  }, []);

  useEffect(() => {
    console.log("active tab--->",activeTab)
    getData(activeTab);
  }, [activeTab]);
  const updateActiveTab = (tabName: string) => {
    setActiveTab(tabName);
    window.history.pushState({}, "", `?type=${tabName}`);
  };
  return (
    <main className="app-main" data-context="/admin/invoice_settings">
      <header className="content-header">
        <div className="content-header-title">
          <h1>Instellingen</h1>
        </div>
      </header>

      <div className="main-content-area">
        <ul className="nav nav-tabs">
          <li
            className="nav-item"
            onClick={() => updateActiveTab("invoice_setting")}
          >
            <a
              className={`nav-link ${
                activeTab === "invoice_setting" ? "active" : ""
              }`}
              role="tab"
              data-toggle="tab"
              style={{ cursor: "pointer" }}
            >
              Factuurinstellingen
            </a>
          </li>
          <li
            className="nav-item"
            onClick={() => updateActiveTab("certificate")}
          >
            <a
              className={`nav-link ${
                activeTab === "certificate" ? "active" : ""
              }`}
              role="tab"
              data-toggle="tab"
              style={{ cursor: "pointer" }}
            >
              Certificaten
            </a>
          </li>
          <li className="nav-item" onClick={() => updateActiveTab("roles")}>
            <a
              className={`nav-link ${activeTab === "roles" ? "active" : ""}`}
              role="tab"
              data-toggle="tab"
              style={{ cursor: "pointer" }}
            >
              Functies
            </a>
          </li>
          <li
            className="nav-item"
            onClick={() => updateActiveTab("project_setting")}
          >
            <a
              className={`nav-link ${
                activeTab === "project_setting" ? "active" : ""
              }`}
              role="tab"
              data-toggle="tab"
              style={{ cursor: "pointer" }}
            >
              Project
            </a>
          </li>
        </ul>
        <div className="main-content-container">
          <div className="main-content">
            {
              {
                invoice_setting: <InvoiceSetting data={invoiceSetting} />,
                certificate: (
                  <CertificateType data={certificateTypes} count={count} />
                ),
                roles: <Roles data={roles} count={count} />,
                project_setting: <ProjectSetting data={projectSetting} />
              }[activeTab]
            }
          </div>
        </div>
      </div>
    </main>
  );
};

export default SettingList;
