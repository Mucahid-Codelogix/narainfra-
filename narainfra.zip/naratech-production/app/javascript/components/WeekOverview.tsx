import React, { useEffect, useState } from "react";
import Overlay from "./InvoiceComponents/Overlay";
import PendingStatusNotModal from "./WeekOverview/PendingStatusNoteModal";
import DisciplineSelectModal from "./WeekOverview/DisciplineSelectModal";
import axios from "axios";
const WeekOverview = () => {
  const [weeks, setWeeks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [count, setCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [sortField, setSortField] = useState(null);
  const [sortDirection, setSortDirection] = useState(null);
  const [selectedStatuses, setSelectedStatuses] = useState([]);
  const [showPendingModal, setShowPendingModal] = useState(false);
  const [pendingWeekId, setPendingWeekId] = useState(null);
  const [pendingNote, setPendingNote] = useState("");
  const [showDisciplineModal, setShowDisciplineModal] = useState(false);
  const [selectedWeekId, setSelectedWeekId] = useState(null);
  const [disciplines, setDisciplines] = useState([]);
  const [selectedDisciplineId, setSelectedDisciplineId] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const statusTranslations = {
    open: "Open",
    pending: "In afwachting",
    send: "Ingediend",
    approved: "Goedgekeurd",
  };
  const getWeeksData = (pageNumber) => {
    console.log("get weeks functions")
    setLoading(true);
    setSortDirection(null);
    setSortField(null);
    axios
      .get(`/admin/weeks/get_weeks?page=${pageNumber}&status=${statusFilter}`)
      .then((res) => {
        console.log("res===>",res)
        if (res.data.weeks.length > 0) {
          setWeeks(res.data.weeks);
          setCount(res.data.count);
          setCurrentPage(pageNumber);
          setTotalPages(Math.ceil(res.data.count / 10));
          setLoading(false);
        } else {
          setCount(0);
          setCurrentPage(0);
          setTotalPages(0);
          setWeeks([]);
          setLoading(false);
        }
      });
  };

  const renderPageButtons = () => {
    const maxVisiblePages = 5;
    const halfMaxVisiblePages = Math.floor(maxVisiblePages / 2);

    const startPage =
      currentPage <= halfMaxVisiblePages
        ? 1
        : Math.min(
            currentPage - halfMaxVisiblePages,
            totalPages - maxVisiblePages + 1
          );

    const endPage = Math.min(startPage + maxVisiblePages - 1, totalPages);

    const pageButtons = [];

    for (let i = startPage; i <= endPage; i++) {
      pageButtons.push(
        <li
          key={i}
          className={`page-item ${currentPage === i ? "active" : ""}`}
        >
          <button
            className="page-link"
            onClick={() => {
              getWeeksData(i);
            }}
          >
            {i}
          </button>
        </li>
      );
    }

    return pageButtons;
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const getSortOrderFunc = () => {
    if (sortField === "weeknumber") {
      return (a, b) =>
        sortDirection == "asc"
          ? a.week_number - b.week_number
          : b.week_number - a.week_number;
    }

    if (sortField === "projectnumber") {
      return (a, b) => {
        // Handle sorting for project numbers
        const projectNumberA = isNaN(parseInt(a.project.projectnumber))
          ? a.project.projectnumber
          : parseInt(a.project.projectnumber);
        const projectNumberB = isNaN(parseInt(b.project.projectnumber))
          ? b.project.projectnumber
          : parseInt(b.project.projectnumber);

        if (sortDirection === "asc") {
          return projectNumberA > projectNumberB ? 1 : -1;
        } else {
          return projectNumberA < projectNumberB ? 1 : -1;
        }
      };
    }

    if (sortField === "projectperformer") {
      return (a, b) =>
        sortDirection == "asc"
          ? a.project.projectperformer.localeCompare(b.project.projectperformer)
          : b.project.projectperformer.localeCompare(
              a.project.projectperformer
            );
    }

    if (sortField === "turnover_week") {
      return (a, b) =>
        sortDirection == "asc"
          ? a.total_overview_turn_over - b.total_overview_turn_over
          : b.total_overview_turn_over - a.total_overview_turn_over;
    }
  };

  const handleStatusChange = (weekId, status) => {
    if (status === "pending") {
      setPendingWeekId(weekId);
      setShowPendingModal(true);
    }
    setSelectedStatuses((prevStatuses) => ({
      ...prevStatuses,
      [weekId]: status,
    }));
  };

  const handleSave = () => {
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

    axios
      .post(
        "/admin/weeks/update_statuses",
        { status: selectedStatuses, week_id: null, note: null },
        {
          headers: {
            "X-CSRF-Token": csrfToken,
          },
        }
      )
      .then((response) => {
        console.log("Statuses updated successfully");
        getWeeksData(currentPage);
      })
      .catch((error) => {
        console.error("There was an error updating the statuses!", error);
      });
  };

  const handlePendingSave = () => {
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
    if (!pendingNote.trim()) {
      alert("Opmerking is vereist voor de status In behandeling");
      return;
    }
    axios
      .post(
        "/admin/weeks/update_statuses",
        { status: [], week_id: pendingWeekId, note: pendingNote },
        {
          headers: {
            "X-CSRF-Token": csrfToken,
          },
        }
      )
      .then((response) => {
        console.log("Statuses updated successfully");
        getWeeksData(currentPage);
      })
      .catch((error) => {
        console.error("There was an error updating the statuses!", error);
      });

    setShowPendingModal(false);
    setPendingNote("");
    setPendingWeekId(null);
  };

  const handleExportPdfClick = (weekId) => {
    setSelectedWeekId(weekId);
    setShowDisciplineModal(true);
    let disciplines = weeks.filter((item) => item.id === weekId)[0]?.project
      ?.project_disciplines;
    if (disciplines.length > 0) {
      setDisciplines(disciplines);
    } else {
      setDisciplines([]);
    }
  };

  const handleDisciplineDownload = () => {
    if (selectedDisciplineId) {
      const pdfLink = document.createElement("a");
      pdfLink.href = `/admin/weeks/${selectedWeekId}/create_pdf_generator?discipline_id=${selectedDisciplineId}&template=discipline_pdf`;
      pdfLink.setAttribute("data-method", "post");
      pdfLink.click();
      console.log("clicked");
      setShowDisciplineModal(false);
    } else {
      alert("Selecteer een discipline.");
    }
  };

  useEffect(() => {
    let filterWeeks = [...weeks];
    if (sortField && sortDirection) {
      filterWeeks = [...filterWeeks].sort(getSortOrderFunc());
    }

    setWeeks(filterWeeks);
  }, [sortField, sortDirection]);
  const handleStatusFilterChange = (status) => {
    setStatusFilter(status);
  };

  useEffect(() => {
    getWeeksData(1);
  }, [statusFilter]);

  const filteredWeeks = weeks.filter((week) => {
    return (
      week.week_number.toString().includes(searchTerm) ||
      week.project.projectnumber.toString().includes(searchTerm) ||
      week.project.projectperformer
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      statusTranslations[week.status]
        ?.toLowerCase()
        .includes(searchTerm.toLowerCase())
    );
  });
  if (loading) {
    return <Overlay />;
  }
  return (
    <main className="app-main" data-context="/admin/employee_schedulings">
      <header className="content-header">
        <div className="content-header-title">
          <h1>Controle productie</h1>
        </div>
        <div className="btn-toolbar primary-toolbar" role="toolbar">
          <button
            name="button"
            className="btn btn-success"
            onClick={handleSave}
          >
            <span className="btn-label">Opslaan</span>
          </button>
        </div>
      </header>
      <div className="main-content-area">
        <div className="searchbox">
          <div className="input-group">
            <div className="input-group-prepend">
              <span className="input-group-text">
                <i className="fa fa-search"></i>
              </span>
            </div>

            <input
              type="text"
              className="form-control"
              placeholder="Zoeken"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <ul className="scope-list" style={{ marginBottom: 20, marginTop: 20 }}>
          <li>
            <span
              className={`scope ${
                statusFilter === "all" ? "active" : ""
              } cursor-pointer`}
              onClick={() => handleStatusFilterChange("all")}
            >
              <strong>Alle</strong>
            </span>
          </li>
          <li>
            <span
              className={`scope ${
                statusFilter === "open" ? "active" : ""
              } cursor-pointer`}
              onClick={() => handleStatusFilterChange("open")}
            >
              <strong>Open</strong>
            </span>
          </li>
          <li>
            <span
              className={`scope ${
                statusFilter === "pending" ? "active" : ""
              } cursor-pointer`}
              onClick={() => handleStatusFilterChange("pending")}
            >
              <strong>In afwachting</strong>
            </span>
          </li>
          <li>
            <span
              className={`scope ${
                statusFilter === "send" ? "active" : ""
              } cursor-pointer`}
              onClick={() => handleStatusFilterChange("send")}
            >
              <strong>Ingediend</strong>
            </span>
          </li>
          <li>
            <span
              className={`scope ${
                statusFilter === "approved" ? "active" : ""
              } cursor-pointer`}
              onClick={() => handleStatusFilterChange("approved")}
            >
              <strong>Goedgekeurd</strong>
            </span>
          </li>
        </ul>
        <div className="main-content-container">
          <div className="main-content">
            <div className="table-container">
              <table className="trestle-table">
                <thead>
                  <tr>
                    <th onClick={() => handleSort("weeknumber")}>
                      <span
                        className={
                          sortField === "weeknumber"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Weeknummer
                      </span>
                    </th>
                    <th onClick={() => handleSort("projectnumber")}>
                      <span
                        className={
                          sortField === "projectnumber"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Projectnummer
                      </span>
                    </th>
                    <th onClick={() => handleSort("projectperformer")}>
                      <span
                        className={
                          sortField === "projectperformer"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Uitvoerder
                      </span>
                    </th>
                    <th onClick={() => handleSort("turnover_week")}>
                      <span
                        className={
                          sortField === "turnover_week"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Omzet week
                      </span>
                    </th>

                    <th className="text-center">Status</th>
                    <th className=""></th>
                    <th className="actions"></th>
                    <th className="actions"></th>
                    <th className="actions"></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredWeeks.map((week) => (
                    <tr key={week.id}>
                      <td className="text-center">{week.week_number}</td>
                      <td className="text-center">
                        {week.project.projectnumber}
                      </td>
                      <td className="">{week.project.projectperformer}</td>
                      <td className="">{week.turnover_week}</td>
                      <td className="text-center">
                        <select
                          className="form-control"
                          value={selectedStatuses[week.id] || week.status}
                          onChange={(e) =>
                            handleStatusChange(week.id, e.target.value)
                          }
                        >
                          <option value="open">Open</option>
                          <option value="pending">In afwachting</option>
                          <option value="send">Ingediend</option>
                          <option value="approved">Goedgekeurd</option>
                        </select>
                      </td>

                      <td className="actions">
                        <div>
                          <a
                            href={`/admin/weeks/${week.id}/create_pdf_generator?preview=true&template=pdf`}
                            data-method="post"
                            className="btn btn-primary"
                            target="_blank"
                            rel="nofollow"
                          >
                            <i className="fas fa-eye mr-1"></i>
                          </a>
                          <a
                            href={`/admin/weeks/${week.id}/create_pdf_generator?template=pdf`}
                            data-method="post"
                            className="btn btn-primary"
                            rel="nofollow"
                          >
                            Exporteer pdf
                          </a>
                        </div>
                      </td>
                      <td className="actions">
                        <button
                          className="btn btn-primary"
                          type="button"
                          onClick={() => handleExportPdfClick(week.id)}
                        >
                          Exporteer pdf per discipline
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {totalPages > 0 ? (
              <footer className="main-content-footer">
                <nav className="pagination-container">
                  <p>
                    <strong>
                      {(currentPage - 1) * 10 + 1} -{" "}
                      {Math.min(currentPage * 10, count)}{" "}
                    </strong>{" "}
                    van de <b>{count}</b> worden weergeven
                  </p>
                  <ul className="pagination pagination-sm">
                    <li
                      className={`page-item ${
                        currentPage === 1 ? "disabled" : ""
                      }`}
                    >
                      <button
                        className="page-link"
                        onClick={() => {
                          getWeeksData(currentPage - 1);
                        }}
                      >
                        «
                      </button>
                    </li>

                    {renderPageButtons()}

                    <li
                      className={`page-item ${
                        currentPage === totalPages ? "disabled" : ""
                      }`}
                    >
                      <button
                        className="page-link"
                        onClick={() => {
                          getWeeksData(currentPage + 1);
                        }}
                      >
                        »
                      </button>
                    </li>
                  </ul>
                </nav>
              </footer>
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
      {showPendingModal && (
        <PendingStatusNotModal
          note={pendingNote}
          setNote={setPendingNote}
          handleSave={handlePendingSave}
          handleClose={() => {
            setShowPendingModal(false);
            if (!pendingNote.trim()) {
              alert("Opmerking is vereist voor de status In behandeling");
            }
          }}
        />
      )}
      {showDisciplineModal && (
        <DisciplineSelectModal
          show={showDisciplineModal}
          disciplines={disciplines}
          selectedDisciplineId={selectedDisciplineId}
          selectedWeekId={selectedWeekId}
          setSelectedDisciplineId={setSelectedDisciplineId}
          handleDownload={handleDisciplineDownload}
          handleClose={() => {
            setSelectedWeekId(null);
            setDisciplines([]);
            setSelectedDisciplineId(null);
            setShowDisciplineModal(false);
          }}
        />
      )}
    </main>
  );
};
export default WeekOverview;
