import React, { useEffect, useState } from "react";
import { DisplayOption, Gantt, Task, ViewMode } from "gantt-task-react";
import axios from "axios";
import Data from "../interfaces/Data";
const shortMonthLabels = [
  "jan", "feb", "mar", "apr", "mei", "jun", "jul", "aug", "sep", "okt", "nov", "dec"
];

export default function GanttChart() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isChecked] = useState(true);
  const [displayOption] = useState<DisplayOption>({
    viewMode: ViewMode.Week,
    viewDate: new Date(),
    rtl: false,
  });
  const [chartColumnWidth, setChartColumnWidth] = useState(
    window.innerWidth <= 500 ? 50 : 20
  );
  const [currentZoom, setCurrentZoom] = useState(chartColumnWidth - 10);
  const [loading, setLoading] = useState<boolean>(true);

  const generateProjectsAndActivitiesData = () => {
    const options = {
      year: "numeric",
      month: "short",
      day: "numeric",
      weekday: "short",
    };
    axios.get<Data[]>("/projects").then((res) => {
      res.data.map((data, index) => {
        if (data.project.tbs === false) {
          let activities: Task[] = [];
          data.activities.forEach((activity) => {
            activities = [
              ...activities,
              {
                start: new Date(activity.plan_start_date),
                end: new Date(activity.plan_end_date),
                id: `Task ${activity.id}`,
                name: `${activity.activity_name} - ${
                  activity.teams.length > 0 ? activity.teams : "No Teams"
                }`,
                progress: 0,
                type: "task",
                project: data.project.id.toString(),
                styles: {
                  backgroundColor: activity.activity_color,
                  progressColor: activity.activity_color,
                  backgroundSelectedColor: activity.activity_color,
                },
              },
            ];
          });

          setTasks((prev) => [
            ...prev,
            {
              name: data.project.projectnumber,
              start: new Date(data.project.start_date),
              end: new Date(data.project.end_date),
              id: data.project.id.toString(),
              type: "project",
              progress: 0,
              hideChildren: false,
              styles: {
                backgroundColor: "#ffca71",
                backgroundSelectedColor: "#ffca71",
                progressColor: "#ffca71",
              },
            },
            ...activities,
          ]);
        }
      });
    });
    setLoading(false);
  };

  const fixStartWeekCoordinates = () => {
    const element = document.getElementsByClassName("_2q1Kt").item(0);
    if (Number(element?.getAttribute("x")) === 0) {
      return element?.setAttribute("x", "-40");
    }
  };

  const handleExpanderClick = (task: Task) => {
    setTasks(tasks.map((t) => (t.id === task.id ? task : t)));
  };

  const handleChartZoomIn = () => {
    setChartColumnWidth(
      chartColumnWidth + (currentZoom <= 10 ? 1 : currentZoom <= 20 ? 5 : 10)
    );
  };

  const handleChartZoomOut = () => {
    currentZoom <= 5
      ? setChartColumnWidth(chartColumnWidth)
      : setChartColumnWidth(
          chartColumnWidth - (currentZoom <= 10 ? 1 : currentZoom <= 20 ? 5 : 10)
        );
  };

  useEffect(() => {
    generateProjectsAndActivitiesData();
  }, []);

  useEffect(() => {
    setCurrentZoom(chartColumnWidth - 10);
    const elements = document.getElementsByClassName("_2q1Kt");

    if (currentZoom <= 15) {
      for (let index = 0; index < elements.length; index++) {
        const element = elements[index];
        element?.setAttribute("style", "font-size: 0.8rem;");
      }
    } else if (currentZoom >= 15) {
      for (let index = 0; index < elements.length; index++) {
        const element = elements[index];
        element?.removeAttribute("style");
      }
    }
  }, [chartColumnWidth]);

  useEffect(() => fixStartWeekCoordinates());

  return (
    <div className="chart-container">
      {loading === false ? (
        tasks.length > 0 ? (
          <>
            <Gantt
              tasks={tasks}
              listCellWidth={isChecked ? "130px" : ""}
              columnWidth={chartColumnWidth}
              onExpanderClick={handleExpanderClick}
              viewMode={displayOption.viewMode}
              locale= {"nl"}
              
            />

            <div className="buttons-container">
              <button
                onClick={handleChartZoomIn}
                className="plus-button"
              ></button>
              <div className="percentage-container">
                <input
                  className="percentage"
                  type="text"
                  value={currentZoom}
                  onChange={(e) => setCurrentZoom(Number(e.target.value))}
                  onKeyDown={(e) =>
                    e.key === "Enter" && Number(e.currentTarget.value) >= 5
                      ? setChartColumnWidth(Number(e.currentTarget.value))
                      : setChartColumnWidth(5)
                  }
                />
              </div>
              <button
                onClick={handleChartZoomOut}
                className={`minus-button ${currentZoom <= 5 ? "disabled" : ""}`}
              ></button>
            </div>
          </>
        ) : (
          <h2>No Projects to Show</h2>
        )
      ) : (
        <p>loading...</p>
      )}
    </div>
  );
}
