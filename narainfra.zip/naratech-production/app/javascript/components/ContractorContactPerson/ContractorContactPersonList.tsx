import React, { useEffect, useState } from "react";
import axios from "axios";
const ContractorContactPersonList = () => {
  const [data, setData] = useState([]);
  const [contractorId, setcontractorId] = useState(null);
  const getData = async (id) => {
    const timestamp = Date.now();
    try {
      const response = await axios.get(
        `/admin/contractors/${id}/contact_persons_data?&_=${timestamp}`
      );
      console.log(response.data.data);
      setData(response.data.data);
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    const pathSegments = window.location.pathname.split("/");
    const contractor_id = pathSegments[3]; // Adjusted index to correctly access the contractor_id

    getData(contractor_id); // Logs the contractor_id
    setcontractorId(contractor_id); // Logs the contractor_id
  }, []);
  return (
    <>
      <button
        id="add-contact-person-button"
        className="btn btn-primary custom_buttons"
        type="button"
        data-id={contractorId}
        data-source="contractors"
      >
        Contactpersoon toevoegen
      </button>
      <div className="table-container">
        <table className="trestle-table">
          <thead>
            <tr>
              <th className="">Naam</th>
              <th className="">Functie</th>
              <th className="">E-mail</th>
              <th className="">Telefoon</th>
            </tr>
          </thead>

          <tbody>
            {data &&
              data.length > 0 &&
              data.map((item, index) => {
                console.log("hello from data===>",item)
                return (
                  <tr
                    data-url={item.type =="Employee"? `/admin/employees/${item.id}`:`/admin/contractor_contact_persons/${item.id}`}
                    key={index}
                  >
                    <td className="">{item.name}</td>
                    <td className="">{item.position}</td>
                    <td className="">{item.email}</td>
                    <td className="">{item.phone}</td>
                  </tr>
                );
              })}

            {/* <tr data-url="/admin/contractor_contact_persons/1">
              <td className="">test contractor person</td>
              <td className="">test</td>
              <td className="">test@gmail.com</td>
              <td className="">+3147890345</td>
            </tr> */}
          </tbody>
        </table>
      </div>
    </>
  );
};
export default ContractorContactPersonList;
