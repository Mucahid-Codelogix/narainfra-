import React, { useEffect, useState } from "react";
import Select from "react-select";
import Overlay from "./InvoiceComponents/Overlay";
import axios from "axios";
const InvoiceQuoteList = () => {
  const [invoices, setInvoices] = useState([]);
  const defaultOption = { value: "", label: "Alle Opdrachtnemer" };
  const [selectedClient, setSelectedClient] = useState(defaultOption);
  const [clients, setClients] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [invoice, setInvoice] = useState(null);
  const [paidAmount, setPaidAmount] = useState(null);
  const [singleInvoice, setSingleInvoice] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [allInvoicesIds, setAllInvoicesIds] = useState([]);
  const [hideDetails, setHideDetails] = useState(true);
  const [cAccountPercentage, setCAccountPercentage] = useState(0);
  const [gAccountPercentage, setGAccountPercentage] = useState(0);
  const [totalCAccountPercentage, setTotalCAccountPercentage] = useState(0);
  const [totalGAccountPercentage, setTotalGAccountPercentage] = useState(0);

  const [currentDate, setCurrentDate] = useState("");
  const [open, setOpen] = useState(false);
  const [convertModalOpen, setConvertModalOpen] = useState(false);
  const [showOverlay, setShowOverlay] = useState(false);
  const [totalAmount, setTotalAmount] = useState(0);
  const [totalAmountDefault, setTotalAmountDefault] = useState(0);
  const [totalRemainingAmount, setTotalRemainingAmount] = useState(0);
  const [totalRemainingAmountDefault, setTotalRemainingAmountDefault] =
    useState<any>(0);
  const [routeUrl, setRouteUrl] = useState(null);
  const [selectedClientTotalAmount, setSelectedClientTotalAmount] =
    useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [count, setCount] = useState(0);
  const [sortField, setSortField] = useState(null);
  const [sortDirection, setSortDirection] = useState(null);
  const [paymentDate, setPaymentDate] = useState(null);
  const [pdfStartDate, setPdfStartDate] = useState(null);
  const [pdfEndDate, setPdfEndDate] = useState(null);
  const [showPdfModal, setShowPdfModal] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [errorMsgVisible, setErrorMsgVisible] = useState(false);

  const getInvoiceDataByClient = (pageNumber) => {
    setShowOverlay(true);
    let url = "debit_invoice_quotes";

    axios
      .get(
        `${url}/fetch_invoices_client?page=${pageNumber}&client_id=${selectedClient.id}`
      )
      .then((res) => {
        const sortedInvoices = res.data.invoices.sort((a, b) => a.id - b.id);
        const invoiceIds = sortedInvoices.map((invoice) => invoice.id);

        setInvoices(sortedInvoices);
        setCurrentPage(pageNumber);
        setCount(res.data.count);
        setTotalPages(Math.ceil(res.data.count / 100));
        setAllInvoicesIds(invoiceIds);
        setShowOverlay(false);
      });

    const today = new Date();
    const dd = String(today.getDate()).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    const yyyy = today.getFullYear();
    const formattedDate = `${dd}/${mm}/${yyyy}`;
    setRouteUrl(url);
    setCurrentDate(formattedDate);
  };

  const getInvoiceData = (pageNumber) => {
    setShowOverlay(true);
    let url = "debit_invoice_quotes";

    axios.get(`${url}/fetch_invoices?page=${pageNumber}`).then((res) => {
      const sortedInvoices = res.data.invoices.sort((a, b) => a.id - b.id);
      const invoiceIds = sortedInvoices.map((invoice) => invoice.id);

      const clients = res.data.clients;
      if (sortedInvoices.length > 0) {
        setClients(clients);
      }
      setInvoices(sortedInvoices);
      setCurrentPage(pageNumber);
      setCount(res.data.count);
      setTotalPages(Math.ceil(res.data.count / 100));
      setAllInvoicesIds(invoiceIds);
      setShowOverlay(false);
    });

    const today = new Date();
    const dd = String(today.getDate()).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    const yyyy = today.getFullYear();
    const formattedDate = `${dd}/${mm}/${yyyy}`;
    setRouteUrl(url);
    setCurrentDate(formattedDate);
  };
  const calculateSumOfTotalAmount = (totalAmountArray: any, invoice: any) => {
    if (totalAmountArray.length > 0) {
      let totalSum: any = totalAmountArray.reduce(
        (sum, item) => sum + parseFloat(item.total_amount),
        0
      );
      totalSum = parseFloat(totalSum);

      if (invoice?.client?.finance?.vat_reversed == false) {
        let vat =
          (parseFloat(invoice.client?.finance?.vat) * parseFloat(totalSum)) /
          100;
        totalSum = parseFloat(totalSum) + vat;
      } else if (
        invoice?.contractor?.contractor_finance?.vat_reversed == false
      ) {
        let vat =
          (parseFloat(invoice.contractor?.contractor_finance?.vat) *
            parseFloat(totalSum)) /
          100;
        totalSum = parseFloat(totalSum) + vat;
      } else if (
        (invoice.client_id == null || invoice.client_id == "") &&
        (invoice.contractor_id == null || invoice.contractor_id == "") &&
        invoice.total_included_vat
      ) {
        totalSum = parseFloat(invoice.total_included_vat);
      } else if (
        (invoice?.client?.finance == null ||
          invoice?.client?.finance == undefined) &&
        (invoice?.contractor?.contractor_finance == null ||
          invoice?.contractor?.contractor_finance == undefined)
      ) {
        let vat = (parseFloat("21.0") * parseFloat(totalSum)) / 100;
        totalSum = parseFloat(totalSum) + vat;
      }

      return totalSum;
    } else {
      return 0;
    }
  };

  const getSortOrderFunc = (field, direction) => {
    if (field === "Totaal incl") {
      return direction === "asc"
        ? (a, b) => {
            const aTotal = calculateSumOfTotalAmount(
              a.debit_invoice_quote_details,
              a
            );
            const bTotal = calculateSumOfTotalAmount(
              b.debit_invoice_quote_details,
              b
            );
            return aTotal > bTotal ? 1 : -1;
          }
        : (a, b) => {
            const aTotal = calculateSumOfTotalAmount(
              a.debit_invoice_quote_details,
              a
            );
            const bTotal = calculateSumOfTotalAmount(
              b.debit_invoice_quote_details,
              b
            );
            return aTotal < bTotal ? 1 : -1;
          };
    } else if (field === "client") {
      return direction === "asc"
        ? (a, b) =>
            (
              a.client?.client_name ||
              a.contractor?.contractor_name ||
              a.company_name ||
              ""
            )?.toLowerCase() >
            (
              b.client?.client_name ||
              b.contractor?.contractor_name ||
              a.company_name ||
              ""
            )?.toLowerCase()
              ? 1
              : -1
        : (a, b) =>
            (
              a.client?.client_name ||
              a.contractor?.contractor_name ||
              a.company_name ||
              ""
            )?.toLowerCase() <
            (
              b.client?.client_name ||
              b.contractor?.contractor_name ||
              a.company_name ||
              ""
            )?.toLowerCase()
              ? 1
              : -1;
    } else {
      return direction === "asc"
        ? (a, b) => (a[field] > b[field] ? 1 : -1)
        : (a, b) => (a[field] < b[field] ? 1 : -1);
    }
  };

  const renderPageButtons = () => {
    const maxVisiblePages = 5;
    const halfMaxVisiblePages = Math.floor(maxVisiblePages / 2);

    const startPage =
      currentPage <= halfMaxVisiblePages
        ? 1
        : Math.min(
            currentPage - halfMaxVisiblePages,
            totalPages - maxVisiblePages + 1
          );

    const endPage = Math.min(startPage + maxVisiblePages - 1, totalPages);

    const pageButtons = [];

    for (let i = startPage; i <= endPage; i++) {
      pageButtons.push(
        <li
          key={i}
          className={`page-item ${currentPage === i ? "active" : ""}`}
        >
          <button
            className="page-link"
            onClick={() => {
              if (selectedClient.value != "" && selectedClient.value != null) {
                getInvoiceDataByClient(i);
              } else {
                getInvoiceData(i);
              }
            }}
          >
            {i}
          </button>
        </li>
      );
    }

    return pageButtons;
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  useEffect(() => {
    if (selectedClient.value != "" && selectedClient.value != null) {
      getInvoiceDataByClient(1);
    } else {
      getInvoiceData(1);
    }
  }, [selectedClient]);

  let clientOptions: any = [{ value: "", label: "Alle Opdrachtnemer" }];
  if (clients.length > 0) {
    let optionsArray = clients.map((client) => ({
      value: `${client.type}-${client.id}`,
      label: client.client_name || client.contractor_name,
      type: client.type,
      id: client.id,
    }));

    clientOptions = [...clientOptions, ...optionsArray];
  }

  let filteredInvoices = invoices.filter((invoice) => {
    const descriptionMatches =
      searchTerm === "" ||
      invoice.description.toLowerCase().includes(searchTerm.toLowerCase());
    const invoiceNumberMatches =
      searchTerm === "" ||
      invoice.quote_number.toLowerCase().includes(searchTerm.toLowerCase());
    const nameMatches =
      searchTerm === "" ||
      (
        invoice.client?.client_name ||
        invoice.contractor?.contractor_name ||
        invoice.company_name ||
        ""
      )
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

    return descriptionMatches || invoiceNumberMatches || nameMatches;
  });

  if (sortField && sortDirection) {
    filteredInvoices.sort(getSortOrderFunc(sortField, sortDirection));
  }

  function formatNumber(amount) {
    const [integerPart, decimalPart] = amount.toFixed(2).toString().split(".");
    const formattedIntegerPart = integerPart.replace(/\d(?=(...)+$)/g, "$&.");
    return `${formattedIntegerPart},${decimalPart}`;
  }

  return (
    <main className="app-main" data-context={routeUrl}>
      <header className="content-header">
        <div className="content-header-title">
          <h1>Lijst van Offerte</h1>
          {/* <button onClick={()=>{createInvoice()}}>create invoice</button> */}
          <ol className="breadcrumb">
            <li className="breadcrumb-item">
              <a href="/admin">Home</a>
            </li>
            <li className="breadcrumb-item active">
              <a href={routeUrl}>Factuur</a>
            </li>
          </ol>
        </div>

        <div className="content-header-toolbars">
          <div className="btn-toolbar primary-toolbar" role="toolbar">
            <a
              className="btn-new-resource btn btn-light has-icon"
              href={`${routeUrl}/new`}
            >
              <i className="fa fa-plus"></i>{" "}
              <span className="btn-label">New Offerte</span>
            </a>
          </div>

          <div className="btn-toolbar secondary-toolbar" role="toolbar"></div>
        </div>
      </header>

      {showOverlay && <Overlay />}

      <div className="main-content-area">
        <div className="main-content-container">
          <div className="main-content">
            <header className="main-content-header">
              <div className="searchbox">
                <div className="input-group">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fa fa-search"></i>
                    </span>
                  </div>

                  <input
                    type="text"
                    className="form-control"
                    placeholder="Zoeken"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              <Select
                options={clientOptions}
                className="search-select-box-invoice"
                value={selectedClient}
                onChange={(selectedOption) => {
                  setSelectedClient(selectedOption || null);
                }}
                styles={{
                  control: (baseStyles, state) => ({
                    ...baseStyles,
                    borderColor: "grey",
                    boxShadow: state.isFocused ? 0 : 0,
                    "&:hover": {
                      borderColor: "grey",
                    },
                  }),
                }}
              />
            </header>

            <div className="table-container">
              <table className="trestle-table invoices-list-table">
                <thead>
                  <tr>
                    <th className="" onClick={() => handleSort("quote_number")}>
                      <span
                        className={
                          sortField === "quote_number"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Offertenummer
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("client")}>
                      <span
                        className={
                          sortField === "client"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Opdrachtgever
                        
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("description")}>
                      <span
                        className={
                          sortField === "description"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Omschrijving
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("invoice_date")}>
                      <span
                        className={
                          sortField === "invoice_date"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Offertedatum
                      </span>
                    </th>
                    <th
                      className=""
                      onClick={() => handleSort("expiration_date")}
                    >
                      <span
                        className={
                          sortField === "expiration_date"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Vervaldatum
                      </span>
                    </th>

                    <th className="" onClick={() => handleSort("Totaal incl")}>
                      <span
                        className={
                          sortField === "Totaal incl"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Totaal
                      </span>
                    </th>

                    <th className="actions"></th>
                  </tr>
                </thead>

                <tbody>
                  {filteredInvoices.length > 0 &&
                    filteredInvoices.map((item, index) => {
                      let url = `${routeUrl}/${item.id}`;
                      let total = parseFloat(item.total);

                      return (
                        <tr key={index}>
                          <td>
                            <a href={url}>{item.quote_number}</a>
                          </td>
                          <td>{item?.client?.client_name}</td>
                          <td>{item.description}</td>
                          <td>
                            {new Date(item.invoice_date).toLocaleDateString(
                              "en-GB"
                            )}
                          </td>
                          <td>
                            {new Date(item.expiration_date).toLocaleDateString(
                              "en-GB"
                            )}
                          </td>

                          <td>
                            €{" "}
                            {formatNumber(
                              calculateSumOfTotalAmount(
                                item.debit_invoice_quote_details,
                                item
                              )
                            )}
                          </td>

                          <td className="actions">
                            <a
                              className="btn btn-primary"
                              target="_blank"
                              rel="nofollow"
                              data-method="post"
                              href={`${routeUrl}/${item.id}/pdf_download?preview=true`}
                            >
                              <i className="fas fa-eye mr-1"></i>
                            </a>
                            <a
                              className="btn btn-primary"
                              rel="nofollow"
                              data-method="post"
                              href={`${routeUrl}/${item.id}/pdf_download`}
                            >
                              Exporteer PDF
                            </a>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
            <footer className="main-content-footer">
              <nav className="pagination-container">
                <p>
                  Offerte
                  <strong>
                    {(currentPage - 1) * 100 + 1} -{" "}
                    {Math.min(currentPage * 100, count)}{" "}
                  </strong>{" "}
                  van de <b>{count}</b> worden weergeven
                </p>
                <ul className="pagination pagination-sm">
                  <li
                    className={`page-item ${
                      currentPage === 1 ? "disabled" : ""
                    }`}
                  >
                    <button
                      className="page-link"
                      onClick={() => {
                        if (
                          selectedClient.value != "" &&
                          selectedClient.value != null
                        ) {
                          console.log("if condition running");
                          getInvoiceDataByClient(currentPage - 1);
                        } else {
                          getInvoiceData(currentPage - 1);
                        }
                      }}
                    >
                      «
                    </button>
                  </li>

                  {renderPageButtons()}

                  <li
                    className={`page-item ${
                      currentPage === totalPages ? "disabled" : ""
                    }`}
                  >
                    <button
                      className="page-link"
                      onClick={() => {
                        if (
                          selectedClient.value != "" &&
                          selectedClient.value != null
                        ) {
                          getInvoiceDataByClient(currentPage + 1);
                        } else {
                          getInvoiceData(currentPage + 1);
                        }
                      }}
                    >
                      »
                    </button>
                  </li>
                </ul>
              </nav>
            </footer>
          </div>
        </div>
      </div>
    </main>
  );
};
export default InvoiceQuoteList;
