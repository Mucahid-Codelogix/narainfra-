import React from "react";

const PendingStatusNotModal = ({ note, setNote, handleSave, handleClose }) => {
  return (
    <div className="modal fade show" role="dialog" aria-modal="true" style={{ display: 'block' }}>
      <div className="modal-dialog" role="document">
        <div className="modal-content" data-context="">
          <div className="modal-header">
            <h4 className="modal-title">Notitie toevoegen</h4>
            <button type="button" className="close" aria-label="Close" onClick={handleClose}>
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div className="modal-body">
            <div className="form-group">
              <label className="control-label">Opmerking</label>
              <input
                className="form-control"
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>
          </div>
          <div className="modal-footer">
            <div className="btn-toolbar primary-toolbar" role="toolbar">
              <button name="button" type="button" className="btn btn-success" onClick={handleSave}>
                <span className="btn-label">Opslaan</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PendingStatusNotModal;
