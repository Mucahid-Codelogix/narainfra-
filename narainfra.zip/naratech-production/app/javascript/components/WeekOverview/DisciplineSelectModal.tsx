// DisciplineSelectModal.js
import React from "react";
const DisciplineSelectModal = ({
  show,
  disciplines,
  selectedDisciplineId,
  setSelectedDisciplineId,
  selectedWeekId,
  handleDownload,
  handleClose,
}) => {
  return (
    show && (
      <div>
        <div
          className="modal fade show"
          role="dialog"
          aria-modal="true"
          style={{ display: "block" }}
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content" data-context="">
              <div className="modal-header">
                <h4 className="modal-title">PDF downloaden</h4>
                <button
                  type="button"
                  className="close"
                  aria-label="Close"
                  onClick={handleClose}
                >
                  <span aria-hidden="true">×</span>
                </button>
              </div>
              <div className="modal-body">
                <div className="discipline-selector-content">
                  <select
                    className="form-control"
                    value={selectedDisciplineId}
                    onChange={(e) => setSelectedDisciplineId(e.target.value)}
                    style={{ width: "70%" }}
                  >
                    <option value="">Selecteer Discipline</option>
                    {disciplines.map((discipline) => (
                      <option
                        key={discipline?.discipline?.id}
                        value={discipline?.discipline?.id}
                      >
                        {discipline?.discipline?.name}
                      </option>
                    ))}
                  </select>
                  <a
                    id="download-pdf-button"
                    className="btn btn-primary"
                    rel="nofollow"
                    data-method="post"
                    href={`/admin/weeks/${selectedWeekId}/create_pdf_generator?discipline_id=${selectedDisciplineId}&template=discipline_pdf`}
                    onClick={() => {
                      handleClose();
                    }}
                  >
                    PDF downloaden
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  );
};

export default DisciplineSelectModal;
