import React, { useEffect, useState } from "react";
import axios from "axios";
const EmployeesDetails = () => {
  const [schedulings, setSchedulings] = useState([]);
  const [weeks, setweeks] = useState([]);
  const [expandedWeekIds, setExpandedWeekIds] = useState([]);
  const [count, setCount] = useState(null);
  const [projectId, setProjectId] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const getSchedlingData = (project_id) => {
    axios
      .get(
        `/admin/employee_schedulings/fetch_employees?project_id=${project_id}`
      )
      .then((res) => {
        if (res.data.weeks.length > 0) {
          const sortedWeeks = res.data.weeks.sort((a, b) => {
            const dateA: any = new Date(a.start_date);
            const dateB: any = new Date(b.start_date);
            return dateA - dateB;
          });
          setweeks(sortedWeeks);
        }
        if (res.data.schedulings.length > 0) {
          setSchedulings(res.data.schedulings);
        }
        setCount(res.data.count);
      });
  };
  const calculateHours = (employeeScheduling, week) => {
    let totalHours = 0;
    let scheduleDates = employeeScheduling.schedule_dates;
    let weekDays = week.days;
    if (scheduleDates && scheduleDates.length > 0) {
      scheduleDates.forEach((schedule) => {
        const dayName = schedule.day_name.toLowerCase();
        if (weekDays.some((day) => day.day_name.toLowerCase() === dayName)) {
          totalHours += parseInt(schedule.hours);
        }
      });
    }

    return totalHours;
  };
  const toggleWeekDetails = (weekId, e) => {
    console.log("tagName", e.target.tagName);
    if (
      e.target.tagName === "I" ||
      (e.target.tagName === "A" && e.target.classList.contains("btn-primary"))
    ) {
      return;
    }
    setExpandedWeekIds((prevIds) =>
      prevIds.includes(weekId)
        ? prevIds.filter((id) => id !== weekId)
        : [...prevIds, weekId]
    );
  };
  const filteredSchedulings = schedulings.filter((scheduling) => {
    return (
      scheduling.employee.first_name
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      scheduling.employee.last_name
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      scheduling.week.week_number.toString().includes(searchTerm)
    );
  });

  useEffect(() => {
    const pathSegments = window.location.pathname.split("/");
    const projectId = pathSegments[3];
    getSchedlingData(projectId);
    setProjectId(projectId);
  }, []);
  useEffect(() => {
    // Update count based on the filtered schedulings length
    setCount(filteredSchedulings.length);
  }, [filteredSchedulings]);
  return (
    <>
      <div className="searchbox" style={{ marginBottom: 20 }}>
        <div className="input-group">
          <div className="input-group-prepend">
            <span className="input-group-text">
              <i className="fa fa-search"></i>
            </span>
          </div>

          <input
            type="text"
            className="form-control"
            placeholder="Zoeken"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      <div className="table-container">
        <table className="trestle-table">
          <thead>
            <tr>
              <th className="">Week</th>
              <th className="">Urenstaat</th>
            </tr>
          </thead>
          <tbody>
            {weeks.map((week, index) => {
              const filteredWeekSchedulings = filteredSchedulings.filter(
                (s) => s.week.id === week.id
              );
              const hasFilteredData = filteredWeekSchedulings.length > 0;
              return (
                hasFilteredData && (
                  <React.Fragment key={week.id}>
                    <tr
                      style={{
                        cursor: "pointer",
                      }}
                      onClick={(e) => toggleWeekDetails(week.id, e)}
                    >
                      <td style={{ fontWeight: "bold" }}>
                        {expandedWeekIds.includes(week.id) ? "▼ " : "► "}
                        {week.week_number}
                      </td>

                      <td>
                        <a
                          className="btn btn-primary"
                          target="_blank"
                          rel="nofollow"
                          data-method="post"
                          href={`/admin/employee_schedulings/pdf_download?week_id=${week.id}&preview=true`}
                          style={{
                            height: "32px",
                            textAlign: "center",
                            marginRight: "5px",
                            width: 38,
                          }}
                        >
                          <i
                            style={{
                              fontSize: 12,
                            }}
                            className="fas fa-eye mr-1"
                          ></i>
                        </a>
                        <a
                          className="btn btn-primary"
                          rel="nofollow"
                          data-method="post"
                          href={`/admin/employee_schedulings/pdf_download?week_id=${week.id}`}
                          style={{
                            fontSize: 12,
                          }}
                        >
                          PDF
                        </a>
                      </td>
                    </tr>
                    {expandedWeekIds.includes(week.id) && (
                      <tr>
                        <td colSpan={3}>
                          <div className="table-container inner-table">
                            <table
                              className="trestle-table"
                              style={{ width: "100%" }}
                            >
                              <thead>
                                <tr>
                                  <th>Naam</th>
                                  <th>Gewerkte uren</th>
                                </tr>
                              </thead>
                              <tbody>
                                {filteredSchedulings
                                  .filter((s) => s.week.id === week.id)
                                  .map((s) => (
                                    <tr
                                      key={s.id}
                                      data-url={`/admin/employee_schedulings/${s.id}`}
                                    >
                                      <td>
                                        {s.employee.first_name}{" "}
                                        {s.employee.last_name}
                                      </td>
                                      <td>{calculateHours(s, s.week)}</td>
                                    </tr>
                                  ))}
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                )
              );
            })}
          </tbody>
        </table>
      </div>
      <footer className="main-content-footer">
        <nav className="pagination-container">
          <p>
            <strong>Alle {count}</strong> Medewerker worden weergeven
          </p>
        </nav>
      </footer>
    </>
  );
};
export default EmployeesDetails;
