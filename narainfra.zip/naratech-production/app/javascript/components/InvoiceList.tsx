import React, { useEffect, useState } from "react";
import SelectedInvoice from "./InvoiceComponents/SelectedInvoice";
import Modal from "./InvoiceComponents/Modal";
import PdfDownloadModal from "./InvoiceComponents/PdfDownloadModal";
import ConfirmModal from "./InvoiceComponents/ConfirmModal";
import Overlay from "./InvoiceComponents/Overlay";
import Select from "react-select";
import axios from "axios";
import InvoiceSetting from "./SettingComponents/ProjectSetting";
const InvoiceList = ({ source }) => {
  const [invoices, setInvoices] = useState([]);
  const defaultOption = { value: "", label: "Alle Opdrachtnemer" };
  const [selectedClient, setSelectedClient] = useState(defaultOption);
  const [clients, setClients] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [invoice, setInvoice] = useState(null);
  const [paidAmount, setPaidAmount] = useState(null);
  const [singleInvoice, setSingleInvoice] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [allInvoicesIds, setAllInvoicesIds] = useState([]);
  const [hideDetails, setHideDetails] = useState(true);
  const [cAccountPercentage, setCAccountPercentage] = useState(0);
  const [gAccountPercentage, setGAccountPercentage] = useState(0);
  const [totalCAccountPercentage, setTotalCAccountPercentage] = useState(0);
  const [totalGAccountPercentage, setTotalGAccountPercentage] = useState(0);

  const [currentDate, setCurrentDate] = useState("");
  const [open, setOpen] = useState(false);
  const [convertModalOpen, setConvertModalOpen] = useState(false);
  const [showOverlay, setShowOverlay] = useState(false);
  const [totalAmount, setTotalAmount] = useState(0);
  const [totalAmountDefault, setTotalAmountDefault] = useState(0);
  const [totalRemainingAmount, setTotalRemainingAmount] = useState(0);
  const [totalRemainingAmountDefault, setTotalRemainingAmountDefault] =
    useState<any>(0);
  const [routeUrl, setRouteUrl] = useState(null);
  const [selectedClientTotalAmount, setSelectedClientTotalAmount] =
    useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [count, setCount] = useState(0);
  const [sortField, setSortField] = useState(null);
  const [sortDirection, setSortDirection] = useState(null);
  const [paymentDate, setPaymentDate] = useState(null);
  const [pdfStartDate, setPdfStartDate] = useState(null);
  const [pdfEndDate, setPdfEndDate] = useState(null);
  const [showPdfModal, setShowPdfModal] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [errorMsgVisible, setErrorMsgVisible] = useState(false);
  const [invoiceFilter, setInvoiceFilter] = useState([])
  const statusOptions = [
    { value: "open", label: "Open" },
    { value: "partially_paid", label: "Gedeeltelijk betaald" },
    { value: "paid", label: "Betaald" },
  ];


  const calculateInvoiceTotal = (invoice) => {
    const total = calculateSumOfTotalAmount(invoice.invoice_details, invoice);
    let totalAmountRemain = null;
    let cAccount = 0;
    let gAccount = 0;

    if (invoice) {
      totalAmountRemain = invoice?.total ? parseFloat(invoice?.total) : null;
      if (
        invoice.client?.finance?.vat_reversed === false &&
        invoice?.status != "partially_paid" &&
        invoice?.status != "paid"
      ) {
        let vat =
          (parseFloat(invoice.client?.finance?.vat) *
            parseFloat(invoice.total)) /
          100;

        totalAmountRemain = parseFloat(invoice.total) + vat;
      } else if (
        invoice.contractor?.contractor_finance?.vat_reversed === false &&
        invoice?.status != "partially_paid" &&
        invoice?.status != "paid"
      ) {
        let vat =
          (parseFloat(invoice.contractor?.contractor_finance?.vat) *
            parseFloat(invoice.total)) /
          100;

        totalAmountRemain = parseFloat(invoice.total) + vat;
      } else if (
        (invoice.client_id == null || invoice.client_id == "") &&
        (invoice.contractor_id == null || invoice.contractor_id == "") &&
        invoice.total_included_vat
      ) {
        totalAmountRemain = parseFloat(invoice?.total);
      } else if (
        (invoice?.client?.finance == null ||
          invoice?.client?.finance == undefined) &&
        (invoice?.contractor?.contractor_finance == null ||
          invoice?.contractor?.contractor_finance == undefined) &&
        invoice?.status != "partially_paid" &&
        invoice?.status != "paid"
      ) {
        let vat = (parseFloat("21.0") * parseFloat(invoice?.total)) / 100;
        totalAmountRemain = parseFloat(invoice?.total) + vat;
      }
    }

    let finance = null;
    if (invoice.client?.finance) {
      finance = invoice.client.finance;
    } else if (invoice.contractor?.contractor_finance) {
      finance = invoice.contractor.contractor_finance;
    }
    if (finance) {
      let cPercentageAmount =
        total * (parseFloat(finance.c_account_percentage) / 100) || 0;
      cPercentageAmount = parseFloat(cPercentageAmount.toFixed(2));
      let gPercentageAmount =
        total * (parseFloat(finance.g_account_percentage) / 100) || 0;
      gPercentageAmount = parseFloat(gPercentageAmount.toFixed(2));

      cAccount = cPercentageAmount;
      gAccount = gPercentageAmount;
    }

    return {
      cAccount,
      gAccount,
      remainingAmount: totalAmountRemain,
      amount: total,
    };
  };

  const calculateAllInvoicesTotal = (invoices) => {
    let totalCAccount = 0;
    let totalGAccount = 0;
    let totalRemainingAmount = 0;
    let totalAmount = 0;

    invoices.forEach((invoice) => {
      const { cAccount, gAccount, remainingAmount, amount } =
        calculateInvoiceTotal(invoice); // This function should return the totals for a single invoice

      totalCAccount += cAccount;
      totalGAccount += gAccount;
      totalRemainingAmount += remainingAmount;
      totalAmount += amount;
    });
    console.log("totalRemainaccount--->", totalRemainingAmount);
    setTotalCAccountPercentage(totalCAccount);
    setTotalGAccountPercentage(totalGAccount);
    setTotalRemainingAmountDefault(totalRemainingAmount);
    setTotalAmountDefault(totalAmount);
  };

  const calculateSumOfTotalAmount = (totalAmountArray: any, invoice: any) => {
    if (totalAmountArray.length > 0) {
      let totalSum: any = totalAmountArray.reduce(
        (sum, item) => sum + parseFloat(item.total_amount),
        0
      );
      totalSum = parseFloat(totalSum);

      if (invoice?.client?.finance?.vat_reversed == false) {
        let vat =
          (parseFloat(invoice.client?.finance?.vat) * parseFloat(totalSum)) /
          100;
        totalSum = parseFloat(totalSum) + vat;
      } else if (
        invoice?.contractor?.contractor_finance?.vat_reversed == false
      ) {
        let vat =
          (parseFloat(invoice.contractor?.contractor_finance?.vat) *
            parseFloat(totalSum)) /
          100;
        totalSum = parseFloat(totalSum) + vat;
      } else if (
        (invoice.client_id == null || invoice.client_id == "") &&
        (invoice.contractor_id == null || invoice.contractor_id == "") &&
        invoice.total_included_vat
      ) {
        totalSum = parseFloat(invoice.total_included_vat);
      } else if (
        (invoice?.client?.finance == null ||
          invoice?.client?.finance == undefined) &&
        (invoice?.contractor?.contractor_finance == null ||
          invoice?.contractor?.contractor_finance == undefined)
      ) {
        let vat = (parseFloat("21.0") * parseFloat(totalSum)) / 100;
        totalSum = parseFloat(totalSum) + vat;
      }

      return totalSum;
    } else {
      return 0;
    }
  };
  const getInvoiceData = (pageNumber, statusArray) => {
    setShowOverlay(true);
    let url = null;
    if (source === "invoice") {
      url = "/admin/invoices";
    } else {
      url = "/admin/debit_invoices";
    }

    const sortFieldParam = sortField ? `&sort_field=${sortField}` : "";
    const sortDirectionParam = sortDirection
      ? `&sort_direction=${sortDirection}`
      : "";
    const searchTermParam = searchTerm ? `&search_term=${searchTerm}` : "";

    axios
      .get(
        `${url}/fetch_invoices?page=${pageNumber}&status=${statusArray}${sortFieldParam}${sortDirectionParam}${searchTermParam}`
      )
      .then((res) => {
        let sortedInvoices = [];
        if (sortDirection == null) {
          sortedInvoices = res.data.invoices.sort((a, b) => a.id - b.id);
        } else {
          sortedInvoices = res.data.invoices;
        }
        const sortedTotalInvoices = res.data.total_invoices.sort(
          (a, b) => a.id - b.id
        );
        const invoiceIds = sortedTotalInvoices.map((invoice) => invoice.id);

        const clients = res.data.clients;
        if (sortedInvoices.length > 0) {
          setClients(clients);
        }
        setInvoices(sortedInvoices);
        setInvoiceFilter(sortedInvoices)
        setCurrentPage(pageNumber);
        setCount(res.data.count);
        setTotalPages(Math.ceil(res.data.count / 100));
        setAllInvoicesIds(invoiceIds);
        calculateAllInvoicesTotal(sortedTotalInvoices);
        setHideDetails(false);
        setShowOverlay(false);
      });

    const today = new Date();
    const dd = String(today.getDate()).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    const yyyy = today.getFullYear();
    const formattedDate = `${dd}/${mm}/${yyyy}`;
    setRouteUrl(url);
    setCurrentDate(formattedDate);
  };

  const getInvoiceDataByClient = (pageNumber, statusArray) => {
    setShowOverlay(true);
    let url = null;
    if (source === "invoice") {
      url = "/admin/invoices";
    } else {
      url = "/admin/debit_invoices";
    }

    const sortFieldParam = sortField ? `&sort_field=${sortField}` : "";
    const sortDirectionParam = sortDirection
      ? `&sort_direction=${sortDirection}`
      : "";
    const searchTermParam = searchTerm ? `&search_term=${searchTerm}` : "";

    axios
      .get(
        `${url}/fetch_invoices_client?page=${pageNumber}&client_id=${selectedClient.id}&client_type=${selectedClient.type}&status=${statusArray}${sortFieldParam}${sortDirectionParam}${searchTermParam}`
      )
      .then((res) => {
        let sortedInvoices = [];
        if (sortDirection == null) {
          sortedInvoices = res.data.invoices.sort((a, b) => a.id - b.id);
        } else {
          sortedInvoices = res.data.invoices;
        }
        const sortedTotalInvoices = res.data.total_invoices.sort(
          (a, b) => a.id - b.id
        );
        const invoiceIds = sortedTotalInvoices.map((invoice) => invoice.id);

        setInvoices(sortedInvoices);
        setInvoiceFilter(sortedInvoices)
        setCurrentPage(pageNumber);
        setCount(res.data.count);
        setTotalPages(Math.ceil(res.data.count / 100));
        setAllInvoicesIds(invoiceIds);
        calculateAllInvoicesTotal(sortedTotalInvoices);
        setHideDetails(false);
        setShowOverlay(false);
      });

    const today = new Date();
    const dd = String(today.getDate()).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    const yyyy = today.getFullYear();
    const formattedDate = `${dd}/${mm}/${yyyy}`;
    setRouteUrl(url);
    setCurrentDate(formattedDate);
  };

  const clientAmountTotal = () => {
    let data = [...invoiceFilter];
    let sum = 0;
    data.map((invoice, index) => {
      if (invoice) {
        sum = invoice?.total ? parseFloat(invoice?.total) : null;
        if (
          invoice.client?.finance?.vat_reversed === false &&
          invoice?.status != "partially_paid" &&
          invoice?.status != "paid"
        ) {
          let vat =
            (parseFloat(invoice.client?.finance?.vat) *
              parseFloat(invoice.total)) /
            100;

          sum = parseFloat(invoice.total) + vat;
        } else if (
          invoice.contractor?.contractor_finance?.vat_reversed === false &&
          invoice?.status != "partially_paid" &&
          invoice?.status != "paid"
        ) {
          let vat =
            (parseFloat(invoice.contractor?.contractor_finance?.vat) *
              parseFloat(invoice.total)) /
            100;

          sum = parseFloat(invoice.total) + vat;
        } else if (
          (invoice?.client?.finance == null ||
            invoice?.client?.finance == undefined) &&
          (invoice?.contractor?.contractor_finance == null ||
            invoice?.contractor?.contractor_finance == undefined) &&
          invoice?.status != "partially_paid" &&
          invoice?.status != "paid"
        ) {
          let vat = (parseFloat("21.0") * parseFloat(invoice?.total)) / 100;
          sum = parseFloat(invoice?.total) + vat;
        }
      }
    });
    return sum;
  };
  const calculateSumOfTotalExcludeVat = (totalAmountArray: any) => {
    if (totalAmountArray.length > 0) {
      let totalSum: any = totalAmountArray.reduce(
        (sum, item) => sum + parseFloat(item.total_amount),
        0
      );
      return (totalSum = parseFloat(totalSum));
    } else {
      return 0;
    }
  };

  const increaseTotal = (invoice) => {
    const total = calculateSumOfTotalAmount(invoice.invoice_details, invoice);

    let totalAmountRemain = null;

    if (invoice) {
      totalAmountRemain = invoice?.total ? parseFloat(invoice?.total) : null;
      if (
        invoice.client?.finance?.vat_reversed === false &&
        invoice?.status != "partially_paid" &&
        invoice?.status != "paid"
      ) {
        let vat =
          (parseFloat(invoice.client?.finance?.vat) *
            parseFloat(invoice.total)) /
          100;

        totalAmountRemain = parseFloat(invoice.total) + vat;
      } else if (
        invoice.contractor?.contractor_finance?.vat_reversed === false &&
        invoice?.status != "partially_paid" &&
        invoice?.status != "paid"
      ) {
        let vat =
          (parseFloat(invoice.contractor?.contractor_finance?.vat) *
            parseFloat(invoice.total)) /
          100;

        totalAmountRemain = parseFloat(invoice.total) + vat;
      } else if (
        (invoice.client_id == null || invoice.client_id == "") &&
        (invoice.contractor_id == null || invoice.contractor_id == "") &&
        invoice.total_included_vat
      ) {
        totalAmountRemain = parseFloat(invoice?.total);
      } else if (
        (invoice?.client?.finance == null ||
          invoice?.client?.finance == undefined) &&
        (invoice?.contractor?.contractor_finance == null ||
          invoice?.contractor?.contractor_finance == undefined) &&
        invoice?.status != "partially_paid" &&
        invoice?.status != "paid"
      ) {
        let vat = (parseFloat("21.0") * parseFloat(invoice?.total)) / 100;
        totalAmountRemain = parseFloat(invoice?.total) + vat;
      }
    }

    let finance = null;
    if (invoice.client?.finance) {
      finance = invoice.client.finance;
    } else if (invoice.contractor?.contractor_finance) {
      finance = invoice.contractor.contractor_finance;
    }
    if (finance) {
      let cPercentageAmount =
        total * (parseFloat(finance.c_account_percentage) / 100) || 0;
      cPercentageAmount = parseFloat(cPercentageAmount.toFixed(2));
      let gPercentageAmount =
        total * (parseFloat(finance.g_account_percentage) / 100) || 0;
      gPercentageAmount = parseFloat(gPercentageAmount.toFixed(2));
      let totalCAccount: any = parseFloat(
        (cAccountPercentage + cPercentageAmount).toFixed(2)
      );
      let totalGAccount: any = parseFloat(
        (gAccountPercentage + gPercentageAmount).toFixed(2)
      );

      setCAccountPercentage(totalCAccount);
      setGAccountPercentage(totalGAccount);
    }
    setTotalRemainingAmount(totalRemainingAmount + totalAmountRemain);
    setTotalAmount(parseFloat((totalAmount + total).toFixed(2)));
  };
  const decreaseTotal = (invoice) => {
    const total = calculateSumOfTotalAmount(invoice.invoice_details, invoice);
    let totalAmountRemain = null;
    if (invoice) {
      console.log("invoice", invoice);
      totalAmountRemain = invoice?.total ? parseFloat(invoice?.total) : null;
      if (
        invoice.client?.finance?.vat_reversed === false &&
        invoice?.status !== "partially_paid" &&
        invoice?.status !== "paid"
      ) {
        let vat =
          (parseFloat(invoice.client?.finance?.vat) *
            parseFloat(invoice.total)) /
          100;

        totalAmountRemain = parseFloat(invoice.total) + vat;
      } else if (
        invoice.contractor?.contractor_finance?.vat_reversed === false &&
        invoice?.status !== "partially_paid" &&
        invoice?.status !== "paid"
      ) {
        let vat =
          (parseFloat(invoice.contractor?.contractor_finance?.vat) *
            parseFloat(invoice.total)) /
          100;

        totalAmountRemain = parseFloat(invoice.total) + vat;
      } else if (
        (invoice.client_id == null || invoice.client_id == "") &&
        (invoice.contractor_id == null || invoice.contractor_id == "") &&
        invoice.total_included_vat
      ) {
        totalAmountRemain = parseFloat(invoice?.total);
      } else if (
        (invoice?.client?.finance == null ||
          invoice?.client?.finance == undefined) &&
        (invoice?.contractor?.contractor_finance == null ||
          invoice?.contractor?.contractor_finance == undefined) &&
        invoice?.status !== "partially_paid" &&
        invoice?.status !== "paid"
      ) {
        let vat = (parseFloat("21.0") * parseFloat(invoice?.total)) / 100;
        totalAmountRemain = parseFloat(invoice?.total) + vat;
      }
    }
    let finance = null;
    if (invoice.client?.finance) {
      finance = invoice.client.finance;
    } else if (invoice.contractor?.contractor_finance) {
      finance = invoice.contractor.contractor_finance;
    }
    if (finance) {
      let cPercentageAmount =
        total * (parseFloat(finance.c_account_percentage) / 100) || 0;
      cPercentageAmount = parseFloat(cPercentageAmount.toFixed(2));
      let gPercentageAmount =
        total * (parseFloat(finance.g_account_percentage) / 100) || 0;
      gPercentageAmount = parseFloat(gPercentageAmount.toFixed(2));
      let totalCAccount: any = parseFloat(
        (cAccountPercentage - cPercentageAmount).toFixed(2)
      );
      let totalGAccount: any = parseFloat(
        (gAccountPercentage - gPercentageAmount).toFixed(2)
      );
      setCAccountPercentage(totalCAccount);
      setGAccountPercentage(totalGAccount);
    }
    setTotalRemainingAmount(totalRemainingAmount - totalAmountRemain);
    setTotalAmount(parseFloat((totalAmount - total).toFixed(2)));
  };
  const handleCheckboxChange = (invoice) => {
    const newSelectedRows = [...selectedRows];

    if (newSelectedRows.includes(invoice.id)) {
      newSelectedRows.splice(newSelectedRows.indexOf(invoice.id), 1);
      decreaseTotal(invoice);
    } else {
      increaseTotal(invoice);
      newSelectedRows.push(invoice.id);
    }

    setHideDetails(false);

    setSelectedRows(newSelectedRows);
  };

  const getDefaultTotalAmount = () => {
    let total = null;
    if (invoice) {
      total = invoice?.total ? invoice?.total : null;
      if (invoice.client?.finance?.vat_reversed === false) {
        let vat =
          (parseFloat(invoice.client?.finance?.vat) *
            parseFloat(invoice.total)) /
          100;

        total = parseFloat(invoice.total) + vat;
      } else if (
        invoice.contractor?.contractor_finance?.vat_reversed === false
      ) {
        let vat =
          (parseFloat(invoice.contractor?.contractor_finance?.vat) *
            parseFloat(invoice.total)) /
          100;

        total = parseFloat(invoice.total) + vat;
      } else if (
        (invoice.client_id == null || invoice.client_id == "") &&
        (invoice.contractor_id == null || invoice.contractor_id == "") &&
        invoice.total_included_vat
      ) {
        total = parseFloat(invoice?.total);
      } else if (
        (invoice?.client?.finance == null ||
          invoice?.client?.finance == undefined) &&
        (invoice?.contractor?.contractor_finance == null ||
          invoice?.contractor?.contractor_finance == undefined)
      ) {
        let vat = (parseFloat("21.0") * parseFloat(invoice?.total)) / 100;
        total = parseFloat(invoice?.total) + vat;
      }
      return total;
    }
  };

  const downloadZip = () => {
    axios({
      method: "post",
      url: `${routeUrl}/download_pdf_zip`,
      data: {
        start_date: pdfStartDate,
        end_date: pdfEndDate,
      },
      responseType: "blob", // Important
      headers: {
        "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]')
          .content,
      },
    })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        let filename = `${pdfStartDate} - ${pdfEndDate}.zip`;
        link.setAttribute("download", filename); // Change the filename if needed
        document.body.appendChild(link);
        link.click();
        setShowPdfModal(false);
        setPdfStartDate(null);
        setPdfEndDate(null);
        setErrorMsg(null);
        setErrorMsgVisible(false);
      })
      .catch((error) => {
        if (pdfStartDate && pdfEndDate) {
          setErrorMsg(
            "Er zijn geen facturen gevonden voor het geselecteerde datumbereik."
          );
          setErrorMsgVisible(true);
        } else {
          setErrorMsg("Startdatum en einddatum niet geselecteerd");
          setErrorMsgVisible(true);
        }
      });
  };

  const handlePayment = () => {
    let postInvoice = null;
    let amountPaid = null;
    if (singleInvoice) {
      postInvoice = invoice.id;
      const total = getDefaultTotalAmount();
      amountPaid = paidAmount ? paidAmount : total;
    } else {
      if (selectedRows.length === 0) {
        postInvoice = [...allInvoicesIds];
        amountPaid = paidAmount
          ? paidAmount
          : selectedRows.length != 0
          ? totalRemainingAmount
          : parseFloat(totalRemainingAmountDefault).toFixed(2);
      } else {
        postInvoice = [...selectedRows];
        amountPaid = paidAmount ? paidAmount : totalRemainingAmount;
      }
    }

    const payload = {
      invoices: postInvoice,
      paidAmount: amountPaid,
      payment_date: paymentDate,
    };
    console.log("payload==>", payload);
    setShowOverlay(true);
    axios
      .post(`${routeUrl}/update_payment`, payload, {
        headers: {
          "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]')
            .content,
        },
      })
      .then((response) => {
        location.reload();
      })
      .catch((error) => {
        setShowOverlay(false);
      });
  };

  const createInvoice = () => {
    setShowOverlay(true);
    let payload = {};

    axios
      .post(`/admin/invoices/create_invoices`, payload, {
        headers: {
          "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]')
            .content,
        },
      })
      .then((response) => {
        console.log("Payment update successful:", response.data);
        location.reload();
      })
      .catch((error) => {
        console.error("Error updating payment:", error);
        setShowOverlay(false);
      });
  };

  const renderPageButtons = () => {
    const maxVisiblePages = 5;
    const halfMaxVisiblePages = Math.floor(maxVisiblePages / 2);

    const startPage =
      currentPage <= halfMaxVisiblePages
        ? 1
        : Math.min(
            currentPage - halfMaxVisiblePages,
            totalPages - maxVisiblePages + 1
          );

    const endPage = Math.min(startPage + maxVisiblePages - 1, totalPages);

    const pageButtons = [];

    for (let i = startPage; i <= endPage; i++) {
      pageButtons.push(
        <li
          key={i}
          className={`page-item ${currentPage === i ? "active" : ""}`}
        >
          <button
            className="page-link"
            onClick={() => {
              let values = selectedStatus.map((item) => item.value);
              if (selectedClient.value != "" && selectedClient.value != null) {
                getInvoiceDataByClient(i, values);
              } else {
                getInvoiceData(i, values);
              }
            }}
          >
            {i}
          </button>
        </li>
      );
    }

    return pageButtons;
  };

  const handleConvetDebitToCredit = () => {
    const payload = {
      invoice_id: invoice.id,
    };
    setShowOverlay(true);
    axios
      .post(`${routeUrl}/convert_invoice`, payload, {
        headers: {
          "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]')
            .content,
        },
      })
      .then((response) => {
        console.log("Payment update successful:", response.data);
        location.reload();
      })
      .catch((error) => {
        console.error("Error updating payment:", error);
        setShowOverlay(false);
      });
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };
  const calculatePercentage = (item, field) => {
    if (item?.client?.finance) {
      return parseFloat(
        (
          item.client.finance[
            field === "C-rekening"
              ? "c_account_percentage"
              : "g_account_percentage"
          ] *
          (calculateSumOfTotalAmount(item.invoice_details, item) / 100)
        ).toFixed(2)
      );
    } else if (item?.contractor?.contractor_finance) {
      return parseFloat(
        (
          item.contractor.contractor_finance[
            field === "C-rekening"
              ? "c_account_percentage"
              : "g_account_percentage"
          ] *
          (calculateSumOfTotalAmount(item.invoice_details, item) / 100)
        ).toFixed(2)
      );
    } else {
      return 0;
    }
  };

  const calculateTotalOutstanding = (item) => {
    let total = parseFloat(item.total);
    if (item.status === "paid" || item.status === "partially_paid") {
      total = parseFloat(item.total);
    } else if (item.client?.finance?.vat_reversed === false) {
      let vat =
        (parseFloat(item.client?.finance?.vat) * parseFloat(item.total)) / 100;

      total = parseFloat(item.total) + vat;
    } else if (item.contractor?.contractor_finance?.vat_reversed === false) {
      let vat =
        (parseFloat(item.contractor?.contractor_finance?.vat) *
          parseFloat(item.total)) /
        100;

      total = parseFloat(item.total) + vat;
    } else if (
      (item.client_id == null || item.client_id == "") &&
      (item.contractor_id == null || item.contractor_id == "") &&
      item.total_included_vat
    ) {
      total = parseFloat(item?.total);
    } else if (
      (item?.client?.finance == null || item?.client?.finance == undefined) &&
      (item?.contractor?.contractor_finance == null ||
        item?.contractor?.contractor_finance == undefined)
    ) {
      let vat = (parseFloat("21.0") * parseFloat(item.total)) / 100;
      total = parseFloat(item.total) + vat;
    }
    return total;
  };

  const statusToEnum = (status) => {
    switch (status) {
      case "paid":
        return 0;
      case "partially_paid":
        return 1;
      case "sent":
        return 2;
      case "open":
        return 3;
      default:
        return 4; // Handle unknown status
    }
  };

  const handleSearchKeyPress = (event) => {
    if (event.key === "Enter") {
      setSearchTerm(inputValue)
      // let filteredInvoices = invoices.filter((invoice) => {
      //   const statusMatches =
      //     selectedStatus.length === 0 ||
      //     selectedStatus.map((option) => option.value).includes(invoice.status);
      //   const descriptionMatches =
      //     searchTerm === "" ||
      //     invoice.description.toLowerCase().includes(searchTerm.toLowerCase());
      //   const invoiceNumberMatches =
      //     searchTerm === "" ||
      //     invoice.invoice_number
      //       .toLowerCase()
      //       .includes(searchTerm.toLowerCase());
      //   const nameMatches =
      //     searchTerm === "" ||
      //     (
      //       invoice.client?.client_name ||
      //       invoice.contractor?.contractor_name ||
      //       invoice.company_name ||
      //       ""
      //     )
      //       .toLowerCase()
      //       .includes(searchTerm.toLowerCase());

      //   return (
      //     statusMatches &&
      //     (descriptionMatches || invoiceNumberMatches || nameMatches)
      //   );
      // });
      // if(filteredInvoices.length > 0){
      //   setInvoiceFilter(filteredInvoices)
      // }
      // else {
      //   setInvoiceFilter(invoices)
      // }
    }
  };

  const handleClearSearch = () => {
    setSearchTerm("");
    setInputValue("")
  };

  const getSortOrderFunc = (field, direction) => {
    if (field === "status") {
      return direction === "asc"
        ? (a, b) => {
            const aStatus = statusToEnum(a.status);
            const bStatus = statusToEnum(b.status);
            return aStatus > bStatus ? 1 : -1;
          }
        : (a, b) => {
            const aStatus = statusToEnum(a.status);
            const bStatus = statusToEnum(b.status);
            return aStatus < bStatus ? 1 : -1;
          };
    } else if (field === "Totaal openstaand") {
      return direction === "asc"
        ? (a, b) => {
            const aTotal = calculateTotalOutstanding(a);
            const bTotal = calculateTotalOutstanding(b);
            return aTotal > bTotal ? 1 : -1;
          }
        : (a, b) => {
            const aTotal = calculateTotalOutstanding(a);
            const bTotal = calculateTotalOutstanding(b);
            return aTotal < bTotal ? 1 : -1;
          };
    } else if (field === "Totaal incl") {
      return direction === "asc"
        ? (a, b) => {
            const aTotal = calculateSumOfTotalAmount(a.invoice_details, a);
            const bTotal = calculateSumOfTotalAmount(b.invoice_details, b);
            return aTotal > bTotal ? 1 : -1;
          }
        : (a, b) => {
            const aTotal = calculateSumOfTotalAmount(a.invoice_details, a);
            const bTotal = calculateSumOfTotalAmount(b.invoice_details, b);
            return aTotal < bTotal ? 1 : -1;
          };
    } else if (field === "Totaal excl") {
      return direction === "asc"
        ? (a, b) => {
            const aTotal = calculateSumOfTotalExcludeVat(a.invoice_details);
            const bTotal = calculateSumOfTotalExcludeVat(b.invoice_details);
            return aTotal > bTotal ? 1 : -1;
          }
        : (a, b) => {
            const aTotal = calculateSumOfTotalExcludeVat(a.invoice_details);
            const bTotal = calculateSumOfTotalExcludeVat(a.invoice_details);
            return aTotal < bTotal ? 1 : -1;
          };
    } else if (field === "C-rekening" || field === "G-rekening") {
      return direction === "asc"
        ? (a, b) => {
            const aPercentage = calculatePercentage(a, field);
            const bPercentage = calculatePercentage(b, field);
            return aPercentage > bPercentage ? 1 : -1;
          }
        : (a, b) => {
            const aPercentage = calculatePercentage(a, field);
            const bPercentage = calculatePercentage(b, field);
            return aPercentage < bPercentage ? 1 : -1;
          };
    } else if (field === "client") {
      return direction === "asc"
        ? (a, b) =>
            (
              a.client?.client_name ||
              a.contractor?.contractor_name ||
              a.company_name ||
              ""
            )?.toLowerCase() >
            (
              b.client?.client_name ||
              b.contractor?.contractor_name ||
              a.company_name ||
              ""
            )?.toLowerCase()
              ? 1
              : -1
        : (a, b) =>
            (
              a.client?.client_name ||
              a.contractor?.contractor_name ||
              a.company_name ||
              ""
            )?.toLowerCase() <
            (
              b.client?.client_name ||
              b.contractor?.contractor_name ||
              a.company_name ||
              ""
            )?.toLowerCase()
              ? 1
              : -1;
    } else {
      console.log("else condition running");
      return direction === "asc"
        ? (a, b) => (a[field] > b[field] ? 1 : -1)
        : (a, b) => (a[field] < b[field] ? 1 : -1);
    }
  };
  let clientOptions: any = [{ value: "", label: "Alle Opdrachtnemer" }];
  if (clients.length > 0) {
    let optionsArray = clients.map((client) => ({
      value: `${client.type}-${client.id}`,
      label: client.client_name || client.contractor_name,
      type: client.type,
      id: client.id,
    }));

    clientOptions = [...clientOptions, ...optionsArray];
  }


  function formatNumber(amount) {
    const [integerPart, decimalPart] = amount.toFixed(2).toString().split(".");
    const formattedIntegerPart = integerPart.replace(/\d(?=(...)+$)/g, "$&.");
    return `${formattedIntegerPart},${decimalPart}`;
  }

  // useEffect(() => {
  //   const values = selectedStatus.map((item) => item.value);
  //   if (selectedClient.value != "" && selectedClient.value != null) {
  //     getInvoiceDataByClient(1, values);
  //   } else {
  //     getInvoiceData(1, values);
  //   }
  // }, [selectedClient, selectedStatus, searchTerm]);


  useEffect(() => {
    const values = selectedStatus.map((item) => item.value);
    if (selectedClient.value != "" && selectedClient.value != null) {
      getInvoiceDataByClient(currentPage, values);
    } else {
      getInvoiceData(currentPage, values);
    }
  }, [selectedClient, selectedStatus, searchTerm, sortDirection]);

  useEffect(() => {
    getInvoiceData(1, selectedStatus);
  }, []);

  return (
    <main className="app-main" data-context={routeUrl}>
      <header className="content-header">
        <div className="content-header-title">
          <h1>Lijst van Factuur</h1>
          {/* <button onClick={()=>{createInvoice()}}>create invoice</button> */}
          <ol className="breadcrumb">
            <li className="breadcrumb-item">
              <a href="/admin">Home</a>
            </li>
            <li className="breadcrumb-item active">
              <a href={routeUrl}>Factuur</a>
            </li>
          </ol>
        </div>

        <div className="content-header-toolbars">
          <div className="btn-toolbar primary-toolbar" role="toolbar">
            <a
              className="btn-new-resource btn btn-light has-icon"
              href={`${routeUrl}/new`}
            >
              <i className="fa fa-plus"></i>{" "}
              <span className="btn-label">New Factuur</span>
            </a>
          </div>

          <div className="btn-toolbar secondary-toolbar" role="toolbar"></div>
        </div>
      </header>

      {showPdfModal && (
        <PdfDownloadModal
          currentDate={currentDate}
          pdfStartDate={pdfStartDate}
          pdfEndDate={pdfEndDate}
          setPdfStartDate={setPdfStartDate}
          setPdfEndDate={setPdfEndDate}
          setShowPdfModal={setShowPdfModal}
          downloadZip={downloadZip}
          errorMsg={errorMsg}
          setErrorMsgVisible={setErrorMsgVisible}
          errorMsgVisible={errorMsgVisible}
        ></PdfDownloadModal>
      )}

      {open && (
        <Modal
          currentDate={currentDate}
          setOpen={setOpen}
          setPaidAmount={setPaidAmount}
          handlePayment={handlePayment}
          singleInvoice={singleInvoice}
          totalRemainingAmount={
            selectedRows.length != 0
              ? totalRemainingAmount
              : totalRemainingAmountDefault
          }
          invoice={invoice}
          setPaymentDate={setPaymentDate}
        />
      )}

      {convertModalOpen && (
        <ConfirmModal
          setOpen={setConvertModalOpen}
          handleConvetDebitToCredit={handleConvetDebitToCredit}
        />
      )}

      {showOverlay && <Overlay />}
      {selectedClient.value != "" && selectedClient.value != null && (
        <div
          style={{ marginLeft: "20px", padding: "20px", paddingBottom: "0px" }}
        >
          <div>
            <span style={{ fontWeight: "bold" }}>Totaal openstaand: </span>€{" "}
            {formatNumber(clientAmountTotal())}
          </div>
        </div>
      )}

      {hideDetails === false && (
        <SelectedInvoice
          totalAmount={
            selectedRows.length > 0 ? totalAmount : totalAmountDefault
          }
          cAccountPercentage={
            selectedRows.length > 0
              ? cAccountPercentage
              : totalCAccountPercentage
          }
          gAccountPercentage={
            selectedRows.length > 0
              ? gAccountPercentage
              : totalGAccountPercentage
          }
          setOpen={setOpen}
          setSingleInvoice={setSingleInvoice}
          formatNumber={formatNumber}
          totalRemainingAmount={
            selectedRows.length > 0
              ? totalRemainingAmount
              : totalRemainingAmountDefault
          }
          source={source}
          setShowPdfModal={setShowPdfModal}
        />
      )}

      <div className="main-content-area">
        <div className="main-content-container">
          <div className="main-content">
            <header className="main-content-header">
              <div className="searchbox">
                <div
                  className="search-box"
                  style={{ paddingTop: 0, paddingBottom: 0 }}
                >
                  <i
                    className="fa fa-search search-icon"
                    aria-hidden="true"
                  ></i>
                  <input
                    style={{ width: "100%" }}
                    type="text"
                    id="search-input"
                    placeholder="Zoek"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleSearchKeyPress}
                  />

                  <span
                    id="clear-input-invoice"
                    className="clear-button"
                    onClick={handleClearSearch}
                  >
                    ✖
                  </span>
                </div>
              </div>


              <Select
                options={clientOptions}
                className="search-select-box-invoice"
                value={selectedClient}
                onChange={(selectedOption) => {
                  setSelectedClient(selectedOption || null);
                }}
                styles={{
                  control: (baseStyles, state) => ({
                    ...baseStyles,
                    borderColor: "grey",
                    boxShadow: state.isFocused ? 0 : 0,
                    "&:hover": {
                      borderColor: "grey",
                    },
                  }),
                }}
              />

              <Select
                isMulti
                options={statusOptions}
                className="search-select-box-invoice"
                value={selectedStatus}
                placeholder="Status..."
                onChange={(selectedOptions) => {
                  setSelectedStatus([...(selectedOptions || [])]);
                }}
                styles={{
                  control: (baseStyles, state) => ({
                    ...baseStyles,
                    borderColor: "grey",
                    boxShadow: state.isFocused ? 0 : 0,
                    "&:hover": {
                      borderColor: "grey",
                    },
                  }),
                }}
              />
            </header>

            <div className="table-container">
              <table className="trestle-table invoices-list-table">
                <thead>
                  <tr>
                    <th></th>
                    <th
                      className=""
                      onClick={() => handleSort("invoice_number")}
                    >
                      <span
                        className={
                          sortField === "invoice_number"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Factuurnummer
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("client")}>
                      <span
                        className={
                          sortField === "client"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        {source == "invoice"
                          ? "Opdrachtnemer"
                          : "Opdrachtgever"}
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("description")}>
                      <span
                        className={
                          sortField === "description"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Omschrijving
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("invoice_date")}>
                      <span
                        className={
                          sortField === "invoice_date"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Factuurdatum
                      </span>
                    </th>
                    <th
                      className=""
                      onClick={() => handleSort("expiration_date")}
                    >
                      <span
                        className={
                          sortField === "expiration_date"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Vervaldatum
                      </span>
                    </th>

                    <th className="" onClick={() => handleSort("C-rekening")}>
                      <span
                        className={
                          sortField === "C-rekening"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        C-rekening
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("G-rekening")}>
                      <span
                        className={
                          sortField === "G-rekening"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        G-rekening
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("Totaal excl")}>
                      <span
                        className={
                          sortField === "Totaal excl"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Totaal excl
                      </span>
                    </th>
                    <th className="" onClick={() => handleSort("Totaal incl")}>
                      <span
                        className={
                          sortField === "Totaal incl"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Totaal incl
                      </span>
                    </th>
                    <th
                      className=""
                      onClick={() => handleSort("Totaal openstaand")}
                    >
                      <span
                        className={
                          sortField === "Totaal openstaand"
                            ? sortDirection === "asc"
                              ? "sort sort-asc active"
                              : "sort sort-desc active"
                            : "sort"
                        }
                      >
                        Totaal openstaand
                      </span>
                    </th>
                    <th className="">Status</th>

                    <th className="actions"></th>
                  </tr>
                </thead>

                <tbody>
                  {invoiceFilter.length > 0 &&
                    invoiceFilter.map((item, index) => {
                      let url = `${routeUrl}/${item.id}`;
                      let total = parseFloat(item.total);
                      if (
                        item.status === "paid" ||
                        item.status === "partially_paid"
                      ) {
                        total = parseFloat(item.total);
                      } else if (item.client?.finance?.vat_reversed === false) {
                        let vat =
                          (parseFloat(item.client?.finance?.vat) *
                            parseFloat(item.total)) /
                          100;

                        total = parseFloat(item.total) + vat;
                      } else if (
                        item.contractor?.contractor_finance?.vat_reversed ===
                        false
                      ) {
                        let vat =
                          (parseFloat(
                            item.contractor?.contractor_finance?.vat
                          ) *
                            parseFloat(item.total)) /
                          100;

                        total = parseFloat(item.total) + vat;
                      } else if (
                        (item.client_id == null || item.client_id == "") &&
                        (item.contractor_id == null ||
                          item.contractor_id == "") &&
                        item.total_included_vat
                      ) {
                        total = parseFloat(item.total);
                      } else if (
                        (item?.client?.finance == null ||
                          item?.client?.finance == undefined) &&
                        (item?.contractor?.contractor_finance == null ||
                          item?.contractor?.contractor_finance == undefined)
                      ) {
                        let vat =
                          (parseFloat("21.0") * parseFloat(item.total)) / 100;
                        total = parseFloat(item.total) + vat;
                      }

                      return (
                        <tr key={index}>
                          <td>
                            <input
                              type="checkbox"
                              checked={selectedRows.includes(item.id)}
                              onChange={(e) => {
                                handleCheckboxChange(item);
                              }}
                            />
                          </td>
                          <td>
                            <a href={url}>{item.invoice_number}</a>
                          </td>
                          <td>
                            {item?.client?.client_name ||
                              item?.contractor?.contractor_name ||
                              item.company_name}
                          </td>
                          <td>{item.description}</td>
                          <td>
                            {new Date(item.invoice_date).toLocaleDateString(
                              "en-GB"
                            )}
                          </td>
                          <td>
                            {new Date(item.expiration_date).toLocaleDateString(
                              "en-GB"
                            )}
                          </td>
                          <td>
                            €{" "}
                            {item?.client?.finance
                              ? formatNumber(
                                  parseFloat(
                                    (
                                      item.client.finance.c_account_percentage *
                                      (calculateSumOfTotalAmount(
                                        item.invoice_details,
                                        item
                                      ) /
                                        100)
                                    ).toFixed(2)
                                  )
                                )
                              : item?.contractor?.contractor_finance
                              ? formatNumber(
                                  parseFloat(
                                    (
                                      item.contractor.contractor_finance
                                        .c_account_percentage *
                                      (calculateSumOfTotalAmount(
                                        item.invoice_details,
                                        item
                                      ) /
                                        100)
                                    ).toFixed(2)
                                  )
                                )
                              : 0}
                          </td>

                          <td>
                            €{" "}
                            {item?.client?.finance
                              ? formatNumber(
                                  parseFloat(
                                    (
                                      item.client.finance.g_account_percentage *
                                      (calculateSumOfTotalAmount(
                                        item.invoice_details,
                                        item
                                      ) /
                                        100)
                                    )?.toFixed(2)
                                  )
                                )
                              : item?.contractor?.contractor_finance
                              ? formatNumber(
                                  parseFloat(
                                    (
                                      item.contractor.contractor_finance
                                        .g_account_percentage *
                                      (calculateSumOfTotalAmount(
                                        item.invoice_details,
                                        item
                                      ) /
                                        100)
                                    )?.toFixed(2)
                                  )
                                )
                              : 0}
                          </td>

                          <td>
                            €{" "}
                            {formatNumber(
                              calculateSumOfTotalExcludeVat(
                                item.invoice_details
                              )
                            )}
                          </td>

                          <td>
                            €{" "}
                            {(item.client_id == null || item.client_id == "") &&
                            (item.contractor_id == null ||
                              item.contractor_id == "") &&
                            item.total_included_vat
                              ? formatNumber(
                                  parseFloat(item.total_included_vat)
                                )
                              : formatNumber(
                                  calculateSumOfTotalAmount(
                                    item.invoice_details,
                                    item
                                  )
                                )}
                          </td>
                          <td>€ {total && formatNumber(total)}</td>
                          <td>
                            <span
                              className="badge"
                              style={{
                                backgroundColor:
                                  item.status == "open"
                                    ? "#7f77f1"
                                    : item.status == "sent"
                                    ? "#7f77f1"
                                    : item.status == "paid"
                                    ? "#7dc67d"
                                    : "#ffcc00",
                                fontSize: "12px",
                                color:
                                  item.status == "open" || item.status == "paid"
                                    ? "white"
                                    : "black",
                              }}
                            >
                              {item.status == "open"
                                ? "open"
                                : item.status == "partially_paid"
                                ? "Gedeeltelijk betaald"
                                : item.status === "sent"
                                ? "Verstuurd"
                                : "Betaald"}
                            </span>
                          </td>

                          <td className="actions">
                            <button
                              className="btn btn-primary"
                              rel="nofollow"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setOpen(true);
                                setInvoice(item);
                                setSingleInvoice(true);
                              }}
                            >
                              Betaling toevoegen
                            </button>
                          </td>
                          {source === "invoice" &&
                            item?.attachment_attached && (
                              <td className="actions">
                                <a
                                  className="btn btn-primary"
                                  target="_blank"
                                  rel="nofollow"
                                  // data-method="post"
                                  href={`${item.attachment_url}`}
                                >
                                  <i className="fas fa-eye mr-1"></i>
                                </a>
                                <a
                                  className="btn btn-primary"
                                  rel="nofollow"
                                  data-method="post"
                                  href={`${routeUrl}/${item.id}/download_file`}
                                >
                                  Download Bilage
                                </a>
                              </td>
                            )}
                          {item.invoice_type === "debit" && (
                            <td className="actions">
                              <a
                                className="btn btn-primary"
                                target="_blank"
                                rel="nofollow"
                                data-method="post"
                                href={`${routeUrl}/${item.id}/pdf_download?preview=true`}
                              >
                                <i className="fas fa-eye mr-1"></i>
                              </a>
                              <a
                                className="btn btn-primary"
                                rel="nofollow"
                                data-method="post"
                                href={`${routeUrl}/${item.id}/pdf_download`}
                              >
                                Exporteer PDF
                              </a>
                            </td>
                          )}

                          {item.invoice_type === "debit" && (
                            <td className="actions">
                              <button
                                className="btn btn-primary"
                                rel="nofollow"
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  setConvertModalOpen(true);
                                  setInvoice(item);
                                }}
                              >
                                Omzetten in krediet
                              </button>
                            </td>
                          )}
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
            <footer className="main-content-footer">
              <nav className="pagination-container">
                <p>
                  {source === "invoice" ? "Krediet" : "Debet"}{" "}
                  <strong>
                    {(currentPage - 1) * 100 + 1} -{" "}
                    {Math.min(currentPage * 100, count)}{" "}
                  </strong>{" "}
                  van de <b>{count}</b> worden weergeven
                </p>
                <ul className="pagination pagination-sm">
                  <li
                    className={`page-item ${
                      currentPage === 1 ? "disabled" : ""
                    }`}
                  >
                    <button
                      className="page-link"
                      onClick={() => {
                        let values = selectedStatus.map((item) => item.value);
                        if (
                          selectedClient.value != "" &&
                          selectedClient.value != null
                        ) {
                          console.log("if condition running");
                          getInvoiceDataByClient(currentPage - 1, values);
                        } else {
                          getInvoiceData(currentPage - 1, values);
                        }
                      }}
                    >
                      «
                    </button>
                  </li>

                  {renderPageButtons()}

                  <li
                    className={`page-item ${
                      currentPage === totalPages ? "disabled" : ""
                    }`}
                  >
                    <button
                      className="page-link"
                      onClick={() => {
                        const values = selectedStatus.map((item) => item.value);
                        if (
                          selectedClient.value != "" &&
                          selectedClient.value != null
                        ) {
                          getInvoiceDataByClient(currentPage + 1, values);
                        } else {
                          getInvoiceData(currentPage + 1, values);
                        }
                      }}
                    >
                      »
                    </button>
                  </li>
                </ul>
              </nav>
            </footer>
          </div>
        </div>
      </div>
    </main>
  );
};
export default InvoiceList;
