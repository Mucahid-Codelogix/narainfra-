import React from "react";
import Flatpickr from "react-flatpickr";
// import "flatpickr/dist/themes/material_green.css";

const PdfDownloadModal = (props) => {
  return (
    <div className="payment-modal">
      <div
        className="modal fade show"
        role="dialog"
        aria-modal="true"
        style={{ display: "block" }}
      >
        <div className="modal-dialog" role="document">
          <div className="modal-content" data-context="">
            <div className="modal-header">
              <h4 className="modal-title">Exporteer facturen</h4>
              <button
                type="button"
                data-dismiss="modal"
                aria-label="Close"
                className="close close-flat-rate"
                onClick={() => props.setShowPdfModal(false)}
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            {props.errorMsgVisible && (
              <div className="alert alert-danger alert-dismissible">
                <button
                  type="button"
                  className="close"
                  onClick={() => props.setErrorMsgVisible(false)}
                >
                  <span aria-hidden="true">&times;</span>
                </button>
                {props.errorMsg}
              </div>
            )}
            <div className="modal-body">
              <div className="form-group row align-items-center">
                <label className="col-md-4 text-md-right control-label">
                  Van:
                </label>

                <div
                  className="input-group"
                  style={{ marginLeft: "10px", width: "47%" }}
                >
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fa fa-calendar"></i>
                    </span>
                  </div>

                  <Flatpickr
                    className={`form-control flatpickr-input ${
                      props.errorMsg ? "border-danger" : ""
                    }`}
                    type="text"
                    name={"invoice_payment_date"}
                    id={"invoice_payment_date"}
                    onChange={([date]) => {
                      props.setPdfStartDate(
                        `${date.getFullYear()}-${(
                          "0" +
                          (date.getMonth() + 1)
                        ).slice(-2)}-${("0" + date.getDate()).slice(-2)}`
                      );
                    }}
                    options={{
                      allowInput: true,
                      dateFormat: "d/m/Y",
                      locale: {
                        firstDayOfWeek: 1,
                        weekdays: {
                          shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
                          longhand: [
                            "Zondag",
                            "Maandag",
                            "Dinsdag",
                            "Woensdag",
                            "Donderdag",
                            "Vrijdag",
                            "Zaterdag",
                          ],
                        },
                        months: {
                          shorthand: [
                            "Jan",
                            "Feb",
                            "Mrt",
                            "Apr",
                            "Mei",
                            "Jun",
                            "Jul",
                            "Aug",
                            "Sep",
                            "Okt",
                            "Nov",
                            "Dec",
                          ],
                          longhand: [
                            "Januari",
                            "Februari",
                            "Maart",
                            "April",
                            "Mei",
                            "Juni",
                            "Juli",
                            "Augustus",
                            "September",
                            "Oktober",
                            "November",
                            "December",
                          ],
                        },
                      },
                    }}
                  />
                </div>
              </div>
              <div className="form-group row align-items-center">
                <label className="col-md-4 text-md-right control-label">
                  Naar:
                </label>

                <div
                  className="input-group"
                  style={{ marginLeft: "10px", width: "47%" }}
                >
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fa fa-calendar"></i>
                    </span>
                  </div>

                  <Flatpickr
                    className={`form-control flatpickr-input ${
                      props.errorMsg ? "border-danger" : ""
                    }`}
                    type="text"
                    name={"invoice_payment_date"}
                    id={"invoice_payment_date"}
                    onChange={([date]) => {
                      props.setPdfEndDate(
                        `${date.getFullYear()}-${(
                          "0" +
                          (date.getMonth() + 1)
                        ).slice(-2)}-${("0" + date.getDate()).slice(-2)}`
                      );
                    }}
                    options={{
                      allowInput: true,
                      dateFormat: "d/m/Y",
                      locale: {
                        firstDayOfWeek: 1,
                        weekdays: {
                          shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
                          longhand: [
                            "Zondag",
                            "Maandag",
                            "Dinsdag",
                            "Woensdag",
                            "Donderdag",
                            "Vrijdag",
                            "Zaterdag",
                          ],
                        },
                        months: {
                          shorthand: [
                            "Jan",
                            "Feb",
                            "Mrt",
                            "Apr",
                            "Mei",
                            "Jun",
                            "Jul",
                            "Aug",
                            "Sep",
                            "Okt",
                            "Nov",
                            "Dec",
                          ],
                          longhand: [
                            "Januari",
                            "Februari",
                            "Maart",
                            "April",
                            "Mei",
                            "Juni",
                            "Juli",
                            "Augustus",
                            "September",
                            "Oktober",
                            "November",
                            "December",
                          ],
                        },
                      },
                    }}
                  />
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <div className="btn-toolbar primary-toolbar" role="toolbar">
                <button
                  className="btn btn-success"
                  onClick={() => {
                    props.downloadZip();
                  }}
                >
                  Exporteer PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PdfDownloadModal;
