import React from "react";
import Flatpickr from "react-flatpickr";
// import "flatpickr/dist/themes/material_green.css";

const Modal = (props) => {
  console.log("props===>", props);
  const currentDate = props.currentDate;
  let total: any = 0;
  // if (props.invoice) {
  //   total = props?.invoice?.total ? props?.invoice?.total : null;
  //   if (
  //     props.invoice.status === "paid" ||
  //     props.invoice.status === "partially_paid"
  //   ) {
  //     total = parseFloat(props.invoice.total);
  //   } else if (props.invoice.client?.finance?.vat_reversed === false) {
  //     let vat =
  //       (parseFloat(props.invoice.client?.finance?.vat) *
  //         parseFloat(props.invoice.total)) /
  //       100;

  //     total = parseFloat(props.invoice.total) + vat;
  //   } else if (
  //     props.invoice?.client?.finance == null ||
  //     props.invoice?.client?.finance == undefined
  //   ) {
  //     let vat = (parseFloat("21.0") * parseFloat(props?.invoice?.total)) / 100;
  //     total = parseFloat(props?.invoice?.total) + vat;
  //   }
  // }

  if (props.invoice) {
    total = props?.invoice?.total ? props?.invoice?.total : null;
    if (
      props.invoice.status === "paid" ||
      props.invoice.status === "partially_paid"
    ) {
      total = parseFloat(props.invoice.total);
    } else if (props.invoice.client?.finance?.vat_reversed === false) {
      let vat =
        (parseFloat(props.invoice.client?.finance?.vat) *
          parseFloat(props.invoice.total)) /
        100;

      total = parseFloat(props.invoice.total) + vat;
    } else if (
      props.invoice.contractor?.contractor_finance?.vat_reversed === false
    ) {
      console.log("condition running");
      let vat =
        (parseFloat(props.invoice.contractor?.contractor_finance?.vat) *
          parseFloat(props.invoice.total)) /
        100;

      total = parseFloat(props.invoice.total) + vat;
    } else if (
      (props.invoice.client_id == null || props.invoice.client_id == "") &&
      (props.invoice.contractor_id == null ||
        props.invoice.contractor_id == "") &&
      props.invoice.total_included_vat
    ) {
      total = parseFloat(props.invoice?.total);
    } else if (
      (props.invoice?.client?.finance == null ||
        props.invoice?.client?.finance == undefined) &&
      (props.invoice?.contractor?.contractor_finance == null ||
        props.invoice?.contractor?.contractor_finance == undefined)
    ) {
      let vat = (parseFloat("21.0") * parseFloat(props?.invoice?.total)) / 100;
      total = parseFloat(props?.invoice?.total) + vat;
    }
  }

  return (
    <div className="payment-modal">
      <div
        className="modal fade show"
        role="dialog"
        aria-modal="true"
        style={{ display: "block" }}
      >
        <div className="modal-dialog" role="document">
          <div className="modal-content" data-context="">
            <div className="modal-header">
              <h4 className="modal-title">Factuur/Nota betaald</h4>
              <button
                type="button"
                data-dismiss="modal"
                aria-label="Close"
                className="close close-flat-rate"
                onClick={() => props.setOpen(false)}
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group row align-items-center">
                <label className="col-md-4 text-md-right control-label">
                  Betaald datum:
                </label>

                <div
                  className="input-group"
                  style={{ marginLeft: "10px", width: "47%" }}
                >
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fa fa-calendar"></i>
                    </span>
                  </div>

                  <Flatpickr
                    className="form-control flatpickr-input"
                    type="text"
                    name={"invoice_payment_date"}
                    id={"invoice_payment_date"}
                    value={currentDate}
                    onChange={([date]) => {
                      props.setPaymentDate(
                        `${date.getFullYear()}-${(
                          "0" +
                          (date.getMonth() + 1)
                        ).slice(-2)}-${("0" + date.getDate()).slice(-2)}`
                      );
                    }}
                    options={{
                      allowInput: true,
                      dateFormat: "d/m/Y",
                      locale: {
                        firstDayOfWeek: 1,
                        weekdays: {
                          shorthand: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
                          longhand: [
                            "Zondag",
                            "Maandag",
                            "Dinsdag",
                            "Woensdag",
                            "Donderdag",
                            "Vrijdag",
                            "Zaterdag",
                          ],
                        },
                        months: {
                          shorthand: [
                            "Jan",
                            "Feb",
                            "Mrt",
                            "Apr",
                            "Mei",
                            "Jun",
                            "Jul",
                            "Aug",
                            "Sep",
                            "Okt",
                            "Nov",
                            "Dec",
                          ],
                          longhand: [
                            "Januari",
                            "Februari",
                            "Maart",
                            "April",
                            "Mei",
                            "Juni",
                            "Juli",
                            "Augustus",
                            "September",
                            "Oktober",
                            "November",
                            "December",
                          ],
                        },
                      },
                    }}
                  />
                </div>
              </div>
              <div className="form-group row align-items-center">
                <label className="col-md-4 text-md-right control-label">
                  Bedrag betaald:
                </label>
                <div className="col-md-6 currency-wrap">
                  <span className="currency-code-modal">€</span>
                  <input
                    type="number"
                    className="form-control text-currency"
                    defaultValue={
                      props.singleInvoice
                        ? parseFloat(total).toFixed(2)
                        : parseFloat(props.totalRemainingAmount).toFixed(2)
                    }
                    min="0"
                    onChange={(e) => {
                      props.setPaidAmount(e.target.value);
                    }}
                  />
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <div className="btn-toolbar primary-toolbar" role="toolbar">
                <button
                  onClick={() => {
                    props.setOpen(false);
                  }}
                  name="button"
                  type="button"
                  className="btn btn-danger"
                >
                  <span className="btn-label">Annuleer</span>
                </button>
                <button
                  onClick={() => {
                    props.handlePayment();
                  }}
                  name="button"
                  type="button"
                  className="btn btn-success"
                >
                  <span className="btn-label">Opslaan</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;
