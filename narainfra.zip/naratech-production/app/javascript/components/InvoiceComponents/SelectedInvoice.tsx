import React, { useEffect, useState } from "react";
const SelectedInvoice = (props) => {
  return (
    <div style={{ display: "flex", justifyContent: "space-between" }}>
      <div
        style={{ marginLeft: "20px", padding: "20px", paddingBottom: "0px" }}
      >
        <div>
          <span style={{ fontWeight: "bold" }}>C-renking:</span> €{" "}
          {props.formatNumber(props.cAccountPercentage)}
        </div>
        <div>
          <span style={{ fontWeight: "bold" }}>G-renking:</span> €{" "}
          {props.formatNumber(props.gAccountPercentage)}
        </div>
        <div>
          <span style={{ fontWeight: "bold" }}>Totaal:</span> €{" "}
          {props.formatNumber(props.totalAmount)}
        </div>

        <div>
          <span style={{ fontWeight: "bold" }}>Totaal openstaand:</span> €{" "}
          {props.formatNumber(props.totalRemainingAmount)}
        </div>
      </div>
      <div style={{
        marginTop: "40px"
      }}>
      <button
        style={{
          width: "173px",
          height: "36px",
          marginRight: "10px",
          // marginTop: "40px",
        }}
        className="btn btn-primary"
        onClick={() => {
          props.setShowPdfModal(true)
        }}
      >
        Exporteer facturen
      </button>
      <button
        style={{
          width: "173px",
          height: "36px",
          marginRight: "23px",
          // marginTop: "40px",
        }}
        className="btn btn-primary"
        onClick={() => {
          props.setOpen(true);
          props.setSingleInvoice(false);
        }}
      >
        Betalingen toevoegen
      </button>
        
      </div>
      
    </div>
  );
};
export default SelectedInvoice;
