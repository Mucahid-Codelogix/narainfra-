import React from "react";
const Overlay = () => {
  return (
    <div
      id="loader-overlay"
      className="loader-overlay"
      style={{ display: "block" }}
    >
      <div className="loading-spinner"></div>
    </div>
  );
};
export default Overlay;
