import React from "react";

const ConfirmModal = (props) => {
  // Get the current date in the format YYYY-MM-DD
  const currentDate = props.currentDate;

  return (
    <div className="confirm-convert-invoice-modal">
      <div
        className="modal fade show"
        role="dialog"
        aria-modal="true"
        style={{ display: "block" }}
      >
        <div className="modal-dialog" role="document">
          <div className="modal-content" data-context="">
            <div className="modal-header">
              <h4 className="modal-title">Creditnota aanmaken</h4>
              <button
                type="button"
                data-dismiss="modal"
                aria-label="Close"
                className="close close-flat-rate"
                onClick={() => props.setOpen(false)}
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
             <div>Weet u zeker dat u een creditnota wilt aanmaken?</div>
            </div>
            <div className="modal-footer">
              <div className="btn-toolbar primary-toolbar" role="toolbar">
                <button
                  onClick={() => {
                    props.setOpen(false);
                  }}
                  name="button"
                  type="button"
                  className="btn btn-danger"
                >
                  <span className="btn-label">Nee</span>
                </button>
                <button
                  onClick={() => {
                    props.handleConvetDebitToCredit();
                  }}
                  name="button"
                  type="button"
                  className="btn btn-success"
                >
                  <span className="btn-label">Ja</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
