import React, { useEffect, useState } from "react";
import axios from "axios";

const TotalWeekOverviewList = () => {
  const [weeks, setWeeks] = useState([]);
  const [projectId, setProjectId] = useState(null);
  const [projectSettings, setProjectSettngs] = useState(null);
  const [project, setProject] = useState(null);
  const [selectedWeeks, setSelectedWeeks] = useState(new Set());
  const [zeroWeeks, setZeroWeeks] = useState([]);
  const [zeroWeeksExpanded, setZeroWeeksExpanded] = useState(false);
  const [totals, setTotals] = useState({
    totalTurnover: 0,
    totalTkc: 0,
    totalRevenue: 0,
    totalOtherCost: 0,
    totalEmployeeCost: 0,
    totalExtraCost: 0,
    totalTotalCost: 0,
    totalProfit: 0,
  });

  const getWeeksData = (projectId) => {
    axios
      .get(`/admin/weeks/get_weeks_for_total_overview?project_id=${projectId}`)
      .then((res) => {
        console.log(res);
        if (res.data.non_zero_weeks.length > 0) {
          setWeeks(res.data.non_zero_weeks);
          setZeroWeeks(res.data.zero_weeks);
          setProject(res.data.project);
          setProjectSettngs(res.data.project_settings);
          calculateTotals(res.data.non_zero_weeks);
        }
      });
  };

  useEffect(() => {
    const pathSegments = window.location.pathname.split("/");
    const projectId = pathSegments[3];
    setProjectId(projectId);
    getWeeksData(projectId);
  }, []);

  const calculateTotals = (weeks) => {
    let totalTurnover = 0;
    let totalTkc = 0;
    let totalRevenue = 0;
    let totalOtherCost = 0;
    let totalEmployeeCost = 0;
    let totalExtraCost = 0;
    let totalTotalCost = 0;
    let totalProfit = 0;

    weeks.forEach((week) => {
      totalTurnover += parseFloat(week.turnOverWeek);
      totalTkc += parseFloat(week.totalTkcCostWeek);
      totalRevenue += parseFloat(week.totalRevenue);
      totalOtherCost += parseFloat(week.otherCost);
      totalEmployeeCost += parseFloat(week.totalCostWeekEmployee);
      totalExtraCost += parseFloat(week.totalExtraCostWeek);
      totalTotalCost += parseFloat(week.totalCost);
      totalProfit += parseFloat(week.profit);
    });

    setTotals({
      totalTurnover,
      totalTkc,
      totalRevenue,
      totalOtherCost,
      totalEmployeeCost,
      totalExtraCost,
      totalTotalCost,
      totalProfit,
    });
  };

  const calculateSelectedTotals = () => {
    let totalTurnover = 0;
    let totalTkc = 0;
    let totalRevenue = 0;
    let totalOtherCost = 0;
    let totalEmployeeCost = 0;
    let totalExtraCost = 0;
    let totalTotalCost = 0;
    let totalProfit = 0;

    weeks.forEach((week) => {
      if (selectedWeeks.has(week.id)) {
        totalTurnover += parseFloat(week.turnOverWeek);
        totalTkc += parseFloat(week.totalTkcCostWeek);
        totalRevenue += parseFloat(week.totalRevenue);
        totalOtherCost += parseFloat(week.otherCost);
        totalEmployeeCost += parseFloat(week.totalCostWeekEmployee);
        totalExtraCost += parseFloat(week.totalExtraCostWeek);
        totalTotalCost += parseFloat(week.totalCost);
        totalProfit += parseFloat(week.profit);
      }
    });

    return {
      totalTurnover,
      totalTkc,
      totalRevenue,
      totalOtherCost,
      totalEmployeeCost,
      totalExtraCost,
      totalTotalCost,
      totalProfit,
    };
  };

  const handleCheckboxChange = (weekId) => {
    const newSelectedWeeks = new Set(selectedWeeks);
    if (newSelectedWeeks.has(weekId)) {
      newSelectedWeeks.delete(weekId);
    } else {
      newSelectedWeeks.add(weekId);
    }
    setSelectedWeeks(newSelectedWeeks);
  };

  const getDisplayedTotals = () => {
    if (selectedWeeks.size === 0) {
      return totals;
    }
    return calculateSelectedTotals();
  };

  const displayedTotals = getDisplayedTotals();

  function formatNumber(amount) {
    const [integerPart, decimalPart] = amount.toFixed(2).toString().split(".");
    const formattedIntegerPart = integerPart.replace(/\d(?=(...)+$)/g, "$&.");
    return `${formattedIntegerPart},${decimalPart}`;
  }

  return (
    <div className="table-container">
      <table className="trestle-table total-overview-table">
        <thead>
          <tr style={{ cursor: "default" }}>
            <th></th>
            <th>Weeknummer</th>
            <th>Omzet week</th>
            {project?.tbs == false && <th>TKC</th>}
            {project?.tbs === false && <th>Totale omzet</th>}
            <th>
              {projectSettings?.ak_cost
                ? `${parseInt(projectSettings?.ak_cost)}%AKA`
                : "15%AKA"}
            </th>
            <th>Kosten personeel</th>
            <th>Overige kosten</th>
            <th>Totale kosten</th>
            <th>Winst</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td></td>
            <td></td>
            <td>€ {formatNumber(displayedTotals.totalTurnover)}</td>
            {project?.tbs == false && (
              <td>€ {formatNumber(displayedTotals.totalTkc)}</td>
            )}
            {project?.tbs == false && (
              <td>€ {formatNumber(displayedTotals.totalRevenue)}</td>
            )}
            <td>€ {formatNumber(displayedTotals.totalOtherCost)}</td>
            <td>€ {formatNumber(displayedTotals.totalEmployeeCost)}</td>
            <td>€ {formatNumber(displayedTotals.totalExtraCost)}</td>
            <td>€ {formatNumber(displayedTotals.totalTotalCost)}</td>
            <td>€ {formatNumber(displayedTotals.totalProfit)}</td>
            <td></td>
          </tr>
          {weeks.map((week) => (
            <tr key={week.id} style={{ cursor: "default" }}>
              <td>
                <input
                  type="checkbox"
                  checked={selectedWeeks.has(week.id)}
                  onChange={() => handleCheckboxChange(week.id)}
                />
              </td>
              <td>{week.weekNumber}</td>
              <td>€ {formatNumber(parseFloat(week.turnOverWeek))}</td>
              {project?.tbs == false && (
                <td>€ {formatNumber(parseFloat(week.totalTkcCostWeek))}</td>
              )}
              {project?.tbs == false && (
                <td>€ {formatNumber(parseFloat(week.totalRevenue))}</td>
              )}
              <td>€ {formatNumber(parseFloat(week.otherCost))}</td>
              <td>€ {formatNumber(parseFloat(week.totalCostWeekEmployee))}</td>
              <td>€ {formatNumber(parseFloat(week.totalExtraCostWeek))}</td>
              <td>€ {formatNumber(parseFloat(week.totalCost))}</td>
              <td>€ {formatNumber(parseFloat(week.profit))}</td>
              <td className="actions">
                <div>
                  <a
                    href={`/admin/weeks/${week.id}/create_pdf_generator?preview=true&template=totaloverview`}
                    className="btn btn-primary"
                    target="_blank"
                    rel="nofollow"
                    data-method="post"
                  >
                    <i className="fas fa-eye mr-1"></i>
                  </a>
                  <a
                    href={`/admin/weeks/${week.id}/create_pdf_generator?template=totaloverview`}
                    className="btn btn-primary"
                    target="_blank"
                    rel="nofollow"
                    data-method="post"
                  >
                    Exporteer PDF
                  </a>
                </div>
              </td>
            </tr>
          ))}
          <tr
            style={{ cursor: "pointer" }}
            onClick={() => setZeroWeeksExpanded(!zeroWeeksExpanded)}
          >
            <td style={{ fontWeight: "bold" }}>
              {zeroWeeks?.length > 0 && zeroWeeksExpanded ? "▼ " : "► "}
            </td>
          </tr>
          {zeroWeeks?.length > 0 &&
            zeroWeeksExpanded &&
            zeroWeeks.map((week) => (
              <tr key={week.id} style={{ cursor: "default" }}>
                <td>
                  <input
                    type="checkbox"
                    checked={selectedWeeks.has(week.id)}
                    onChange={() => handleCheckboxChange(week.id)}
                  />
                </td>
                <td>{week.weekNumber}</td>
                <td>€ {formatNumber(parseFloat(week.turnOverWeek))}</td>
                {project?.tbs == false && (
                  <td>€ {formatNumber(parseFloat(week.totalTkcCostWeek))}</td>
                )}
                {project?.tbs == false && (
                  <td>€ {formatNumber(parseFloat(week.totalRevenue))}</td>
                )}
                <td>€ {formatNumber(parseFloat(week.otherCost))}</td>
                <td>
                  € {formatNumber(parseFloat(week.totalCostWeekEmployee))}
                </td>
                <td>€ {formatNumber(parseFloat(week.totalExtraCostWeek))}</td>
                <td>€ {formatNumber(parseFloat(week.totalCost))}</td>
                <td>€ {formatNumber(parseFloat(week.profit))}</td>
                <td className="actions">
                  <div>
                    <a
                      href={`/admin/weeks/${week.id}/create_pdf_generator?preview=true&template=totaloverview`}
                      className="btn btn-primary"
                      target="_blank"
                      rel="nofollow"
                      data-method="post"
                    >
                      <i className="fas fa-eye mr-1"></i>
                    </a>
                    <a
                      href={`/admin/weeks/${week.id}/create_pdf_generator?template=totaloverview`}
                      className="btn btn-primary"
                      target="_blank"
                      rel="nofollow"
                      data-method="post"
                    >
                      Exporteer PDF
                    </a>
                  </div>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
};

export default TotalWeekOverviewList;
