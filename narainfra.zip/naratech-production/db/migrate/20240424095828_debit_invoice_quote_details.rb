class DebitInvoiceQuoteDetails < ActiveRecord::Migration[6.1]
  def change
    create_table :debit_invoice_quote_details do |t|
      t.references :debit_invoice_quote, null: false, foreign_key: true
      t.string :description
      t.string :unit
      t.decimal :amount, default: 0
      t.decimal :price, default: 0
      t.decimal :total_amount, default: 0
      t.decimal :vat_percentage, default: 0
      # Add other fields as needed for invoice details

      t.timestamps
    end
  end
end
