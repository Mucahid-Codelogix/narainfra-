class AddTypeInEquipmentsAndRemove < ActiveRecord::Migration[6.1]
  def change
    remove_column :employees, :marital_status
    add_column :equipment_materials, :type_name, :string
  end
end
