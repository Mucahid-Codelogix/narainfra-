class RenameContractersToContractorsInDb < ActiveRecord::Migration[6.1]
  def change
    rename_table :contracter_contact_persons, :contractor_contact_persons
    rename_table :contracter_finances, :contractor_finances
    rename_table :contracters, :contractors
    rename_column :contractor_contact_persons, :contracter_id, :contractor_id
    rename_column :contractor_finances, :contracter_id, :contractor_id
    rename_column :employees, :contracter_id, :contractor_id
    rename_column :invoices, :contracter_id, :contractor_id
    rename_column :contractors, :contracter_id, :contractor_id
    rename_column :contractors, :contracter_name, :contractor_name
  end
end
