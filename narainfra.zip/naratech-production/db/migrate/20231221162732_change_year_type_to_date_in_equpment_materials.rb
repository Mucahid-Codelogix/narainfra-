class ChangeYearTypeToDateInEqupmentMaterials < ActiveRecord::Migration[6.1]
  def change
    remove_column :equipment_materials, :year
    add_column :equipment_materials, :construction_date, :date
  end
end
