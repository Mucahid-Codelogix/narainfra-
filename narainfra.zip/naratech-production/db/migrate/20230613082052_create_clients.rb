class CreateClients < ActiveRecord::Migration[6.1]
  def change
    create_table :clients do |t|
      t.string :client_name
      t.string :address
      t.string :postal_code
      t.string :email
      t.string :phone
      t.string :contactperson
      t.string :city
      t.integer :client_id
      t.decimal :flat_rate

      t.timestamps
    end
  end
end
