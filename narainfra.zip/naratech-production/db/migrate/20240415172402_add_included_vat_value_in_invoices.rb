class AddIncludedVatValueInInvoices < ActiveRecord::Migration[6.1]
  def change
    add_column :invoices, :included_vat_value, :decimal
    add_column :invoices, :total_included_vat, :decimal
    add_column :debit_invoices, :included_vat_value, :decimal
  end
end
