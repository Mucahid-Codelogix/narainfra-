class CreateTkcCosts < ActiveRecord::Migration[6.1]
  def change
    create_table :tkc_costs do |t|
      t.references :project, null: false, foreign_key: true
      t.references :week, null: false, foreign_key: true

      t.decimal :services, default: 0
      t.decimal :material, default: 0
      t.decimal :additional, default: 0
      t.decimal :tkc_total, default: 0
      t.string :description

      t.timestamps
    end
  end
end
