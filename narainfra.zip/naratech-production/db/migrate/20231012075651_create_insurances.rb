class CreateInsurances < ActiveRecord::Migration[6.1]
  def change
    create_table :insurances do |t|
      t.references :material, null: false, foreign_key: true
      t.string :insurer
      t.string :policy_number
      t.string :premium_period
      t.decimal :premium_per_period, default: 0
      t.date :commencement_date

      t.timestamps
    end
  end
end
