class AddEquipmentMaterialsInInsuranceLeaseContractNotesAndChangeMaterialTypeInMaterials < ActiveRecord::Migration[6.1]
  def change
    add_reference :lease_contracts, :equipment_material, null: true, foreign_key: true
    add_reference :insurances, :equipment_material, null: true, foreign_key: true
    add_reference :notes, :equipment_material, null: true, foreign_key: true
    change_column :materials, :material_type, :string, default: 'vehicle'
    change_column :lease_contracts, :material_id, :bigint, null: true
    change_column :insurances, :material_id, :bigint, null: true
    change_column :notes, :material_id, :bigint, null: true
  end
end
