class CreateEmployeesClients < ActiveRecord::Migration[6.1]
  def change
    create_table :employees_clients do |t|
      t.references :client, null: false, foreign_key: true
      t.references :employee, null: false, foreign_key: true
      t.bigint :employee_number, limit: 8

      t.timestamps
    end
  end
end
