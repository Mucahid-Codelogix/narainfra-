class AddIbanInContracterFinances < ActiveRecord::Migration[6.1]
  def change
    add_column :contracter_finances, :iban, :string
  end
end
