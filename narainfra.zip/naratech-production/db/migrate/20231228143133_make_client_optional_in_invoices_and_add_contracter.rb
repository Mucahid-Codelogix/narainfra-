class MakeClientOptionalInInvoicesAndAddContracter < ActiveRecord::Migration[6.1]
  def change
    # Make client optional
    change_column_null :invoices, :client_id, true

    # Add contractor reference
    add_reference :invoices, :contracter, foreign_key: true, null: true
  end
end
