class ChangeInvoiceNumberType < ActiveRecord::Migration[6.1]
  def change
    change_column :invoices, :invoice_number, :string
    change_column :debit_invoices, :invoice_number, :string
  end
end
