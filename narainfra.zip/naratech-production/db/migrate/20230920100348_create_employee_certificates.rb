class CreateEmployeeCertificates < ActiveRecord::Migration[6.1]
  def change
    create_table :employee_certificates do |t|
      t.references :employee, foreign_key: true
      t.string :certificate_type
      t.string :certificate_number
      t.date :date_achieved
      t.date :end_date

      t.timestamps
    end
  end
end
