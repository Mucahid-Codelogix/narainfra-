class CreateUniqueCosts < ActiveRecord::Migration[6.1]
  def change
    create_table :unique_costs do |t|
      t.references :tkc_cost, null: false, foreign_key: true
      t.string :description
      t.decimal :amount, default: 0.0
      t.decimal :price, default: 0.0
      t.decimal :total, default: 0.0
      t.timestamps
    end
  end
end
