class CreateSpecificationCodes < ActiveRecord::Migration[6.1]
  def change
    create_table :specification_codes do |t|
      t.string :specification_code
      t.string :description
      t.string :measurement
      t.decimal :price
      t.references :client, foreign_key: true

      t.timestamps
    end
  end
end
