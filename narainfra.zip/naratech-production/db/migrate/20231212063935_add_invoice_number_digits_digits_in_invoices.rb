class AddInvoiceNumberDigitsDigitsInInvoices < ActiveRecord::Migration[6.1]
  def change
    add_column :invoices, :invoice_number_digits, :integer
    add_column :invoices, :digits, :string
    add_column :invoices, :year, :string
    add_column :invoices, :invoice_number_character, :string
    add_column :debit_invoices, :invoice_number_digits, :integer
    add_column :debit_invoices, :digits, :string
    add_column :debit_invoices, :year, :string
    add_column :debit_invoices, :invoice_number_character, :string
    add_column :debit_invoices, :credited, :boolean, default: false
  end
end
