class AddDebitInvoiceInInvoiceCodeAndChangeInvoiceTypeInInvoice < ActiveRecord::Migration[6.1]
  def change
    change_column :invoices, :invoice_type, :string, default: 'credit'
    change_column :invoice_codes, :invoice_id, :bigint, null: true
    add_reference :invoice_codes, :debit_invoice, null: true, foreign_key: true
  end
end
