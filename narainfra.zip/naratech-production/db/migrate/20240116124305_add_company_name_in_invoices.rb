class AddCompanyNameInInvoices < ActiveRecord::Migration[6.1]
  def change
    add_column :invoices, :company_name, :string
  end
end
