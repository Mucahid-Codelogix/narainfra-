class CreateDebitInvoices < ActiveRecord::Migration[6.1]
  def change
    create_table :debit_invoices do |t|
      t.references :client, null: false, foreign_key: true
      t.references :project, null: false, foreign_key: true
      t.references :week, null: false, foreign_key: true

      t.integer :invoice_number
      t.string :relation
      t.string :description
      t.date :invoice_date
      t.date :expiration_date
      t.date :paid_date
      t.string :payment_term
      t.integer :status, default: 0
      t.string :invoice_type, default: 'debit'

      t.timestamps
    end
  end
end
