class RemoveTkcDescriptionFromTkcCosts < ActiveRecord::Migration[6.1]
  def up
    TkcCost.find_each do |tkc_cost|
      tkc_cost.create_rich_text_tkc_description(body: tkc_cost.description) if tkc_cost.description.present?
    end
    remove_column :tkc_costs, :tkc_description, :string
  end

  def down
    add_column :tkc_costs, :tkc_description, :string
    TkcCost.find_each do |tkc_cost|
      tkc_cost.update(description: tkc_cost.tkc_description.body.to_plain_text) if tkc_cost.tkc_description.present?
    end
  end
end
