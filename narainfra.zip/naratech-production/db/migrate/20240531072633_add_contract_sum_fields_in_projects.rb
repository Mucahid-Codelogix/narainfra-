class AddContractSumFieldsInProjects < ActiveRecord::Migration[6.1]
  def change
    add_column :projects, :contract_sum_amount, :decimal, default: 0
    add_column :projects, :contract_sum, :boolean, default: false
  end
end
