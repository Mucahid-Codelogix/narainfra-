class CreateRelationBetweenProjectAndDiscipline < ActiveRecord::Migration[6.1]
  def change
    remove_reference :disciplines, :project, foreign_key: true

    create_table :project_disciplines do |t|
      t.references :discipline, null: false, foreign_key: true
      t.references :project, null: false, foreign_key: true

      t.timestamps
    end
  end
end
