class RemoveColumnsFromTkcCosts < ActiveRecord::Migration[6.1]
  def change
    remove_column :tkc_costs, :services, :decimal
    remove_column :tkc_costs, :material, :decimal
    remove_column :tkc_costs, :additional, :decimal
    remove_column :tkc_costs, :description, :string
  end
end
