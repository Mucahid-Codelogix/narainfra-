class CreateWeeks < ActiveRecord::Migration[6.1]
  def change
    create_table :weeks do |t|
      t.references :project, null: false, foreign_key: true
      t.integer :week_number
      t.date :start_date
      t.date :end_date
      t.integer :year
      t.integer :pdf_status
      t.integer :tkc_status

      t.timestamps
    end
  end
end
