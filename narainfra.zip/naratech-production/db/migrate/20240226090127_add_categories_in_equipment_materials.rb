class AddCategoriesInEquipmentMaterials < ActiveRecord::Migration[6.1]
  def change
    add_column :equipment_materials, :category, :integer, default: 0
  end
end
