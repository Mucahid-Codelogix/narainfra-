class MadeSpecificationCodeOptionalInPurchaseOreders < ActiveRecord::Migration[6.1]
  def change
    change_column_null :purchase_orders, :specification_code_id, true
    add_column :purchase_orders, :description, :string
  end
end
