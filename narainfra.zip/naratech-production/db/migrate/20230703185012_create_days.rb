class CreateDays < ActiveRecord::Migration[6.1]
  def change
    create_table :days do |t|
      t.references :week, null: false, foreign_key: true
      t.references :project, null: false, foreign_key: true
      t.integer :day_name, null: false
      t.date :date, null: false

      t.timestamps
    end
  end
end
