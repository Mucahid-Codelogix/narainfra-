class AddStatusToWeeks < ActiveRecord::Migration[6.1]
  def change
    add_column :weeks, :status, :integer, default: 0
    add_column :weeks, :note, :string
  end
end
