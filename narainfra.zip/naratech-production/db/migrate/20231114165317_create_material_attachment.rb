class CreateMaterialAttachment < ActiveRecord::Migration[6.1]
  def change
    create_table :material_attachments do |t|
      t.references :material, null: true, foreign_key: true
      t.references :equipment_material, null: true, foreign_key: true
      t.string :title

      t.timestamps
    end
  end
end
