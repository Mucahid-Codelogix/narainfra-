class CreateEquipmentMaterials < ActiveRecord::Migration[6.1]
  def change
    create_table :equipment_materials do |t|
      t.string :ref_number
      t.string :serial_number
      t.string :material_type, default: "equipment"
      t.string :brand
      t.decimal :purchase_value
      t.date :purchase_date
      t.date :inspection_date
      t.string :year
      t.string :description
      t.integer :in_use, default: 0

      t.timestamps
    end
  end
end
