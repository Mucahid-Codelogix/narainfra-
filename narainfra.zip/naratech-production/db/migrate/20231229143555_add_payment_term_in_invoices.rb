class AddPaymentTermInInvoices < ActiveRecord::Migration[6.1]
  def change
    add_column :invoices, :payment_term, :decimal
    add_column :debit_invoices, :payment_term, :decimal
  end
end
