class CreateExtraCosts < ActiveRecord::Migration[6.1]
  def change
    create_table :extra_costs do |t|
      t.references :project, null: false, foreign_key: true
      t.references :week, null: false, foreign_key: true

      t.integer :item_type, default: 0
      t.decimal :cost, default: 0.0
      t.string :description

      t.timestamps
    end
  end
end
