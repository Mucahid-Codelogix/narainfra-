class ModifyFinances < ActiveRecord::Migration[6.1]
  def change
    add_column :finances, :payment_term_value, :integer, default: 30
    remove_column :invoices, :vat
    remove_column :invoices, :payment_term
    remove_column :debit_invoices, :vat
    remove_column :debit_invoices, :payment_term
  end
end
