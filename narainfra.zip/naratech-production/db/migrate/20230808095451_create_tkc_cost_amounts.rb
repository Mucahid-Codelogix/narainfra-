class CreateTkcCostAmounts < ActiveRecord::Migration[6.1]
  def change
    create_table :tkc_cost_amounts do |t|
      t.references :project, null: false, foreign_key: true
      t.references :specification_code, null: false, foreign_key: true
      t.references :tkc_cost, null: false, foreign_key: true
      t.decimal :amount, default: 0
      t.decimal :price, default: 0
      t.decimal :total_amount, default: 0

      t.timestamps
    end
  end
end
