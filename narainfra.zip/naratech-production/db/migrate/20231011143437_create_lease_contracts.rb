class CreateLeaseContracts < ActiveRecord::Migration[6.1]
  def change
    create_table :lease_contracts do |t|
      t.references :material, null: false, foreign_key: true
      t.string :lease_company
      t.string :contract_number
      t.string :lease_amount_ex_vat
      t.timestamps
    end
  end
end
