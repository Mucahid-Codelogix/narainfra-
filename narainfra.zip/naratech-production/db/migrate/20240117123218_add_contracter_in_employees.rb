class AddContracterInEmployees < ActiveRecord::Migration[6.1]
  def change
    add_reference :employees, :contracter, foreign_key: true, null: true
    remove_column :employees, :company
  end
end
