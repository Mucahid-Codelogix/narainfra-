class CreateEmployeeSchedulings < ActiveRecord::Migration[6.1]
  def change
    create_table :employee_schedulings do |t|
      t.references :project, null: false, foreign_key: true
      t.references :employee, null: false, foreign_key: true
      t.references :week, null: false, foreign_key: true
      t.references :specification_code, null: true, foreign_key: true
      t.boolean :include_specification_code, default: false

      t.jsonb :schedule_dates, null: true, default: []

      t.decimal :rate

      t.timestamps
    end
  end
end
