class CreateProjects < ActiveRecord::Migration[6.1]
  def change
    create_table :projects do |t|
      t.references :client, foreign_key: true
      t.references :user, foreign_key: true

      t.string :projectnumber
      t.string :projectleader
      t.string :projectperformer
      t.string :contactpersoon
      t.string :place
      t.string :supervisor
      t.string :address
      t.string :zip_code
      t.date :start_date
      t.date :end_date
      t.boolean :archived, default: false
      t.boolean :tbs, default: false

      t.timestamps
    end
  end
end
