class CreateMaterials < ActiveRecord::Migration[6.1]
  def change
    create_table :materials do |t|
      t.integer :material_type, default: 0
      t.string :ref_number
      t.string :type_name
      t.string :brand
      t.string :number_plate
      t.string :driver
      t.string :year
      t.string :description
      t.integer :in_use, default: 0

      t.timestamps
    end
  end
end
