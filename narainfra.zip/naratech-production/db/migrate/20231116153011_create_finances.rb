class CreateFinances < ActiveRecord::Migration[6.1]
  def change
    create_table :finances do |t|
      t.references :client, null: false, foreign_key: true

      t.boolean :vat_reversed, default: false
      t.string :vat_number
      t.integer :kvk_number
      t.decimal :c_account_percentage, default: 0.0
      t.decimal :g_account_percentage, default: 0.0
      t.decimal :vat, default: 21.0

      t.timestamps
    end
  end
end
