class ChangeYearTypeToDateInMaterials < ActiveRecord::Migration[6.1]
  def change
    remove_column :materials, :year
    add_column :materials, :construction_date, :date
  end
end
