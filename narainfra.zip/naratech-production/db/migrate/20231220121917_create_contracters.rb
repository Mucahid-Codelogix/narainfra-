class CreateContracters < ActiveRecord::Migration[6.1]
  def change
    create_table :contracters do |t|
      t.string :contracter_name
      t.string :address
      t.string :postal_code
      t.string :email
      t.string :phone
      t.string :contactperson
      t.string :city
      t.integer :contracter_id
      t.decimal :flat_rate
      t.boolean :active, default: true

      t.timestamps
    end
  end
end
