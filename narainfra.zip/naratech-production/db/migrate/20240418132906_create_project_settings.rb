class CreateProjectSettings < ActiveRecord::Migration[6.1]
  def change
    create_table :project_settings do |t|
      t.decimal :ak_cost, default: 0.0
      t.timestamps
    end
  end
end
