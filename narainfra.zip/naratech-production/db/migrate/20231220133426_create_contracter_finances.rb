class CreateContracterFinances < ActiveRecord::Migration[6.1]
  def change
    create_table :contracter_finances do |t|
      t.bigint :contracter_id, null: false
      t.boolean :vat_reversed, default: false
      t.string :vat_number
      t.integer :kvk_number
      t.decimal :c_account_percentage, default: 0.0
      t.decimal :g_account_percentage, default: 0.0
      t.decimal :vat, default: 21.0
      t.integer :payment_term_value, default: 30

      t.timestamps
    end
  end
end
