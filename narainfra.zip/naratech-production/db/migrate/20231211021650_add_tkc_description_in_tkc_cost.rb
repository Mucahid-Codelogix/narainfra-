class AddTkcDescriptionInTkcCost < ActiveRecord::Migration[6.1]
  def change
    add_column :tkc_costs, :tkc_description, :string
  end
end
