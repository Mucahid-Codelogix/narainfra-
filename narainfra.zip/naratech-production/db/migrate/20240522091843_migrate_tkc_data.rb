class MigrateTkcData < ActiveRecord::Migration[6.1]
  def up
    TkcCost.find_each do |tkc_cost|
      create_unique_costs(tkc_cost, :material)
      create_unique_costs(tkc_cost, :additional)
      create_unique_costs(tkc_cost, :services)
    end
  end

  def down
    UniqueCost.delete_all
  end

  private

  def create_unique_costs(tkc_cost, field)
    value = tkc_cost.send(field)
    if value.present? && value > 0
      UniqueCost.create!(
        tkc_cost: tkc_cost,
        description: "#{field.to_s.capitalize}",
        amount: 1,
        price: value,
        total: value
      )
    end
    tkc_cost.update(tkc_total: 0)
  end
end
