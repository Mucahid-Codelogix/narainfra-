class CreateSelectedSpecificationCodes < ActiveRecord::Migration[6.1]
  def change
    create_table :selected_specification_codes do |t|
      t.references :specification_code, null: false, foreign_key: true
      t.references :project, null: false, foreign_key: true
      t.float :total_budget

      t.timestamps
    end
  end
end
