class AddRolesToUsers < ActiveRecord::Migration[6.1]
  def change
    add_column :users, :role, :integer, default: 0
    User.update_all(role: User.roles[:admin])
  end
end
