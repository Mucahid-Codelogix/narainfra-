class ModifyEmployees < ActiveRecord::Migration[6.1]
  def change
    add_column :employees, :email, :string
    add_column :employees, :phone, :string
    add_column :employees, :active, :boolean, default: true
  end
end
