class AddPaymentDatePaymentAmountAndTotalInInvoices < ActiveRecord::Migration[6.1]
  def change
    add_column :invoices, :payment_date, :date
    add_column :invoices, :total, :decimal, default: 0.0
    add_column :invoices, :paid_value, :decimal, default: 0.0
    add_column :debit_invoices, :payment_date, :date
    add_column :debit_invoices, :total, :decimal, default: 0.0
    add_column :debit_invoices, :paid_value, :decimal, default: 0.0
  end
end
