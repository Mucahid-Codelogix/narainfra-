class ModifyInvoicesAndCreateInvoiceDetails < ActiveRecord::Migration[6.1]
  def change
    remove_reference :invoices, :project, foreign_key: true
    remove_reference :invoices, :week, foreign_key: true
    remove_reference :debit_invoices, :project, foreign_key: true
    remove_reference :debit_invoices, :week, foreign_key: true
    remove_column :invoices, :relation
    remove_column :debit_invoices, :relation
    add_column :invoices, :vat, :decimal, default: 0.0
    add_column :debit_invoices, :vat, :decimal, default: 0.0


    # Create a new table for invoice_details
    create_table :invoice_details do |t|
      t.references :invoice, null: true, foreign_key: true
      t.references :debit_invoice, null: true, foreign_key: true
      t.string :description
      t.string :unit
      t.decimal :amount, default: 0
      t.decimal :price, default: 0
      t.decimal :total_amount, default: 0
      # Add other fields as needed for invoice details

      t.timestamps
    end
  end
end
