class CreateContracterContactPersons < ActiveRecord::Migration[6.1]
  def change
    create_table :contracter_contact_persons do |t|
      t.references :contracter, foreign_key: true
      t.string :name
      t.string :position
      t.string :email
      t.string :phone

      t.timestamps
    end
  end
end
