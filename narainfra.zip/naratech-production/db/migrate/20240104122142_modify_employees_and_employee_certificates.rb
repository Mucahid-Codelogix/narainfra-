class ModifyEmployeesAndEmployeeCertificates < ActiveRecord::Migration[6.1]
  def change
    remove_column :employees, :position
    add_reference :employees, :role, foreign_key: true, null: true
    remove_column :employee_certificates, :certificate_type
    add_reference :employee_certificates, :certificate_type, foreign_key: true, null: true
  end
end
