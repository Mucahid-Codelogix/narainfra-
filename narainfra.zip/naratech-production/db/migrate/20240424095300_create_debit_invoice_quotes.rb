class CreateDebitInvoiceQuotes < ActiveRecord::Migration[6.1]
  def change
    create_table :debit_invoice_quotes do |t|
      t.references :client, null: false, foreign_key: true

      t.string :quote_number
      t.string :description
      t.date :invoice_date
      t.date :expiration_date
      t.decimal :total, default: 0
      t.decimal :payment_term, default: 0
      t.integer :invoice_number_digits
      t.string :digits
      t.string :year
      t.string :invoice_number_character

      t.timestamps
    end
  end
end
