class AddVatPercentageInInvoiceDetailsForOtherTypeInvoice < ActiveRecord::Migration[6.1]
  def change
    add_column :invoice_details, :vat_percentage, :decimal
    add_column :invoice_details, :total_amount_included_vat, :decimal
  end
end
