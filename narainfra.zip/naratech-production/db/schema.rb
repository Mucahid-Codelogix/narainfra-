# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2024_06_12_135651) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "action_text_rich_texts", force: :cascade do |t|
    t.string "name", null: false
    t.text "body"
    t.string "record_type", null: false
    t.bigint "record_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["record_type", "record_id", "name"], name: "index_action_text_rich_texts_uniqueness", unique: true
  end

  create_table "active_storage_attachments", force: :cascade do |t|
    t.string "name", null: false
    t.string "record_type", null: false
    t.bigint "record_id", null: false
    t.bigint "blob_id", null: false
    t.datetime "created_at", null: false
    t.index ["blob_id"], name: "index_active_storage_attachments_on_blob_id"
    t.index ["record_type", "record_id", "name", "blob_id"], name: "index_active_storage_attachments_uniqueness", unique: true
  end

  create_table "active_storage_blobs", force: :cascade do |t|
    t.string "key", null: false
    t.string "filename", null: false
    t.string "content_type"
    t.text "metadata"
    t.string "service_name", null: false
    t.bigint "byte_size", null: false
    t.string "checksum", null: false
    t.datetime "created_at", null: false
    t.index ["key"], name: "index_active_storage_blobs_on_key", unique: true
  end

  create_table "active_storage_variant_records", force: :cascade do |t|
    t.bigint "blob_id", null: false
    t.string "variation_digest", null: false
    t.index ["blob_id", "variation_digest"], name: "index_active_storage_variant_records_uniqueness", unique: true
  end

  create_table "activities", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.string "activity_name"
    t.string "color"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["project_id"], name: "index_activities_on_project_id"
  end

  create_table "certificate_types", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "client_contact_persons", force: :cascade do |t|
    t.bigint "client_id"
    t.string "name"
    t.string "position"
    t.string "email"
    t.string "phone"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["client_id"], name: "index_client_contact_persons_on_client_id"
  end

  create_table "clients", force: :cascade do |t|
    t.string "client_name"
    t.string "address"
    t.string "postal_code"
    t.string "email"
    t.string "phone"
    t.string "contactperson"
    t.string "city"
    t.integer "client_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.boolean "active", default: true
  end

  create_table "contractor_contact_persons", force: :cascade do |t|
    t.bigint "contractor_id"
    t.string "name"
    t.string "position"
    t.string "email"
    t.string "phone"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["contractor_id"], name: "index_contractor_contact_persons_on_contractor_id"
  end

  create_table "contractor_finances", force: :cascade do |t|
    t.bigint "contractor_id", null: false
    t.boolean "vat_reversed", default: false
    t.string "vat_number"
    t.integer "kvk_number"
    t.decimal "c_account_percentage", default: "0.0"
    t.decimal "g_account_percentage", default: "0.0"
    t.decimal "vat", default: "21.0"
    t.integer "payment_term_value", default: 30
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "iban"
  end

  create_table "contractors", force: :cascade do |t|
    t.string "contractor_name"
    t.string "address"
    t.string "postal_code"
    t.string "email"
    t.string "phone"
    t.string "contactperson"
    t.string "city"
    t.integer "contractor_id"
    t.decimal "flat_rate"
    t.boolean "active", default: true
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "days", force: :cascade do |t|
    t.bigint "week_id", null: false
    t.bigint "project_id", null: false
    t.integer "day_name", null: false
    t.date "date", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["project_id"], name: "index_days_on_project_id"
    t.index ["week_id"], name: "index_days_on_week_id"
  end

  create_table "debit_invoice_quote_details", force: :cascade do |t|
    t.bigint "debit_invoice_quote_id", null: false
    t.string "description"
    t.string "unit"
    t.decimal "amount", default: "0.0"
    t.decimal "price", default: "0.0"
    t.decimal "total_amount", default: "0.0"
    t.decimal "vat_percentage", default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["debit_invoice_quote_id"], name: "index_debit_invoice_quote_details_on_debit_invoice_quote_id"
  end

  create_table "debit_invoice_quotes", force: :cascade do |t|
    t.bigint "client_id", null: false
    t.string "quote_number"
    t.string "description"
    t.date "invoice_date"
    t.date "expiration_date"
    t.decimal "total", default: "0.0"
    t.decimal "payment_term", default: "0.0"
    t.integer "invoice_number_digits"
    t.string "digits"
    t.string "year"
    t.string "invoice_number_character"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["client_id"], name: "index_debit_invoice_quotes_on_client_id"
  end

  create_table "debit_invoices", force: :cascade do |t|
    t.bigint "client_id", null: false
    t.string "invoice_number"
    t.string "description"
    t.date "invoice_date"
    t.date "expiration_date"
    t.date "paid_date"
    t.integer "status", default: 0
    t.string "invoice_type", default: "debit"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.date "payment_date"
    t.decimal "total", default: "0.0"
    t.decimal "paid_value", default: "0.0"
    t.integer "invoice_number_digits"
    t.string "digits"
    t.string "year"
    t.string "invoice_number_character"
    t.boolean "credited", default: false
    t.decimal "payment_term"
    t.decimal "included_vat_value"
    t.index ["client_id"], name: "index_debit_invoices_on_client_id"
  end

  create_table "disciplines", force: :cascade do |t|
    t.bigint "client_id", null: false
    t.string "name"
    t.decimal "flat_rate"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["client_id"], name: "index_disciplines_on_client_id"
  end

  create_table "employee_certificates", force: :cascade do |t|
    t.bigint "employee_id"
    t.string "certificate_number"
    t.date "date_achieved"
    t.date "end_date"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "certificate_type_id"
    t.index ["certificate_type_id"], name: "index_employee_certificates_on_certificate_type_id"
    t.index ["employee_id"], name: "index_employee_certificates_on_employee_id"
  end

  create_table "employee_schedulings", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "employee_id", null: false
    t.bigint "week_id", null: false
    t.bigint "specification_code_id"
    t.boolean "include_specification_code", default: false
    t.jsonb "schedule_dates", default: []
    t.decimal "rate"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["employee_id"], name: "index_employee_schedulings_on_employee_id"
    t.index ["project_id"], name: "index_employee_schedulings_on_project_id"
    t.index ["specification_code_id"], name: "index_employee_schedulings_on_specification_code_id"
    t.index ["week_id"], name: "index_employee_schedulings_on_week_id"
  end

  create_table "employees", force: :cascade do |t|
    t.string "first_name"
    t.string "last_name"
    t.integer "gender", default: 0
    t.decimal "rate", default: "0.0"
    t.string "social_number"
    t.date "date_of_birth"
    t.string "place_of_birth"
    t.string "bank_account_number"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "role_id"
    t.bigint "contractor_id"
    t.string "email"
    t.string "phone"
    t.boolean "active", default: true
    t.index ["contractor_id"], name: "index_employees_on_contractor_id"
    t.index ["role_id"], name: "index_employees_on_role_id"
  end

  create_table "employees_clients", force: :cascade do |t|
    t.bigint "client_id", null: false
    t.bigint "employee_id", null: false
    t.bigint "employee_number"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["client_id"], name: "index_employees_clients_on_client_id"
    t.index ["employee_id"], name: "index_employees_clients_on_employee_id"
  end

  create_table "employees_teams", force: :cascade do |t|
    t.bigint "team_id", null: false
    t.bigint "employee_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["employee_id"], name: "index_employees_teams_on_employee_id"
    t.index ["team_id"], name: "index_employees_teams_on_team_id"
  end

  create_table "equipment_materials", force: :cascade do |t|
    t.string "ref_number"
    t.string "serial_number"
    t.string "material_type", default: "equipment"
    t.string "brand"
    t.decimal "purchase_value"
    t.date "purchase_date"
    t.date "inspection_date"
    t.string "description"
    t.integer "in_use", default: 0
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.date "construction_date"
    t.string "type_name"
    t.integer "category", default: 0
  end

  create_table "extra_costs", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "week_id", null: false
    t.integer "item_type", default: 0
    t.decimal "cost", default: "0.0"
    t.string "description"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["project_id"], name: "index_extra_costs_on_project_id"
    t.index ["week_id"], name: "index_extra_costs_on_week_id"
  end

  create_table "finances", force: :cascade do |t|
    t.bigint "client_id", null: false
    t.boolean "vat_reversed", default: false
    t.string "vat_number"
    t.integer "kvk_number"
    t.decimal "c_account_percentage", default: "0.0"
    t.decimal "g_account_percentage", default: "0.0"
    t.decimal "vat", default: "21.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.integer "payment_term_value", default: 30
    t.index ["client_id"], name: "index_finances_on_client_id"
  end

  create_table "insurances", force: :cascade do |t|
    t.bigint "material_id"
    t.string "insurer"
    t.string "policy_number"
    t.string "premium_period"
    t.decimal "premium_per_period", default: "0.0"
    t.date "commencement_date"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "equipment_material_id"
    t.index ["equipment_material_id"], name: "index_insurances_on_equipment_material_id"
    t.index ["material_id"], name: "index_insurances_on_material_id"
  end

  create_table "invoice_codes", force: :cascade do |t|
    t.bigint "specification_code_id", null: false
    t.bigint "invoice_id"
    t.decimal "amount", default: "0.0"
    t.decimal "price", default: "0.0"
    t.decimal "total_amount", default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "debit_invoice_id"
    t.index ["debit_invoice_id"], name: "index_invoice_codes_on_debit_invoice_id"
    t.index ["invoice_id"], name: "index_invoice_codes_on_invoice_id"
    t.index ["specification_code_id"], name: "index_invoice_codes_on_specification_code_id"
  end

  create_table "invoice_details", force: :cascade do |t|
    t.bigint "invoice_id"
    t.bigint "debit_invoice_id"
    t.string "description"
    t.string "unit"
    t.decimal "amount", default: "0.0"
    t.decimal "price", default: "0.0"
    t.decimal "total_amount", default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.decimal "vat_percentage"
    t.decimal "total_amount_included_vat"
    t.index ["debit_invoice_id"], name: "index_invoice_details_on_debit_invoice_id"
    t.index ["invoice_id"], name: "index_invoice_details_on_invoice_id"
  end

  create_table "invoice_settings", force: :cascade do |t|
    t.integer "year"
    t.string "characters"
    t.integer "digits_length"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "invoices", force: :cascade do |t|
    t.bigint "client_id"
    t.string "invoice_number"
    t.string "description"
    t.date "invoice_date"
    t.date "expiration_date"
    t.date "paid_date"
    t.integer "status", default: 0
    t.string "invoice_type", default: "credit"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.date "payment_date"
    t.decimal "total", default: "0.0"
    t.decimal "paid_value", default: "0.0"
    t.integer "invoice_number_digits"
    t.string "digits"
    t.string "year"
    t.string "invoice_number_character"
    t.bigint "contractor_id"
    t.decimal "payment_term"
    t.string "company_name"
    t.decimal "included_vat_value"
    t.decimal "total_included_vat"
    t.index ["client_id"], name: "index_invoices_on_client_id"
    t.index ["contractor_id"], name: "index_invoices_on_contractor_id"
  end

  create_table "lease_contracts", force: :cascade do |t|
    t.bigint "material_id"
    t.string "lease_company"
    t.string "contract_number"
    t.string "lease_amount_ex_vat"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "equipment_material_id"
    t.index ["equipment_material_id"], name: "index_lease_contracts_on_equipment_material_id"
    t.index ["material_id"], name: "index_lease_contracts_on_material_id"
  end

  create_table "material_attachments", force: :cascade do |t|
    t.bigint "material_id"
    t.bigint "equipment_material_id"
    t.string "title"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["equipment_material_id"], name: "index_material_attachments_on_equipment_material_id"
    t.index ["material_id"], name: "index_material_attachments_on_material_id"
  end

  create_table "materials", force: :cascade do |t|
    t.string "material_type", default: "vehicle"
    t.string "ref_number"
    t.string "type_name"
    t.string "brand"
    t.string "number_plate"
    t.string "driver"
    t.string "description"
    t.integer "in_use", default: 0
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.date "construction_date"
    t.boolean "active", default: true
  end

  create_table "notes", force: :cascade do |t|
    t.bigint "user_id", null: false
    t.bigint "material_id"
    t.string "comment"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "equipment_material_id"
    t.index ["equipment_material_id"], name: "index_notes_on_equipment_material_id"
    t.index ["material_id"], name: "index_notes_on_material_id"
    t.index ["user_id"], name: "index_notes_on_user_id"
  end

  create_table "plan_teams", force: :cascade do |t|
    t.bigint "plan_id", null: false
    t.bigint "team_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["plan_id"], name: "index_plan_teams_on_plan_id"
    t.index ["team_id"], name: "index_plan_teams_on_team_id"
  end

  create_table "plans", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "activity_id", null: false
    t.bigint "start_week_id"
    t.bigint "end_week_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["activity_id"], name: "index_plans_on_activity_id"
    t.index ["end_week_id"], name: "index_plans_on_end_week_id"
    t.index ["project_id"], name: "index_plans_on_project_id"
    t.index ["start_week_id"], name: "index_plans_on_start_week_id"
  end

  create_table "project_disciplines", force: :cascade do |t|
    t.bigint "discipline_id", null: false
    t.bigint "project_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["discipline_id"], name: "index_project_disciplines_on_discipline_id"
    t.index ["project_id"], name: "index_project_disciplines_on_project_id"
  end

  create_table "project_settings", force: :cascade do |t|
    t.decimal "ak_cost", default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "projects", force: :cascade do |t|
    t.bigint "client_id"
    t.bigint "user_id"
    t.string "projectnumber"
    t.string "projectleader"
    t.string "projectperformer"
    t.string "contactpersoon"
    t.string "place"
    t.string "supervisor"
    t.string "address"
    t.string "zip_code"
    t.date "start_date"
    t.date "end_date"
    t.boolean "archived", default: false
    t.boolean "tbs", default: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.decimal "contract_sum_amount", default: "0.0"
    t.boolean "contract_sum", default: false
    t.index ["client_id"], name: "index_projects_on_client_id"
    t.index ["user_id"], name: "index_projects_on_user_id"
  end

  create_table "purchase_orders", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "specification_code_id"
    t.bigint "week_id", null: false
    t.decimal "amount", default: "0.0"
    t.decimal "price", default: "0.0"
    t.decimal "total_amount", default: "0.0"
    t.decimal "total_budget", default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "description"
    t.index ["project_id"], name: "index_purchase_orders_on_project_id"
    t.index ["specification_code_id"], name: "index_purchase_orders_on_specification_code_id"
    t.index ["week_id"], name: "index_purchase_orders_on_week_id"
  end

  create_table "roles", force: :cascade do |t|
    t.string "role_title"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "selected_specification_codes", force: :cascade do |t|
    t.bigint "specification_code_id", null: false
    t.bigint "project_id", null: false
    t.float "total_budget"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["project_id"], name: "index_selected_specification_codes_on_project_id"
    t.index ["specification_code_id"], name: "index_selected_specification_codes_on_specification_code_id"
  end

  create_table "specification_codes", force: :cascade do |t|
    t.string "specification_code"
    t.string "description"
    t.string "measurement"
    t.decimal "price"
    t.bigint "client_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "discipline_id"
    t.index ["client_id"], name: "index_specification_codes_on_client_id"
    t.index ["discipline_id"], name: "index_specification_codes_on_discipline_id"
  end

  create_table "teams", force: :cascade do |t|
    t.string "team_name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "tkc_cost_amounts", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "specification_code_id", null: false
    t.bigint "tkc_cost_id", null: false
    t.decimal "amount", default: "0.0"
    t.decimal "price", default: "0.0"
    t.decimal "total_amount", default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["project_id"], name: "index_tkc_cost_amounts_on_project_id"
    t.index ["specification_code_id"], name: "index_tkc_cost_amounts_on_specification_code_id"
    t.index ["tkc_cost_id"], name: "index_tkc_cost_amounts_on_tkc_cost_id"
  end

  create_table "tkc_costs", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.bigint "week_id", null: false
    t.decimal "tkc_total", default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["project_id"], name: "index_tkc_costs_on_project_id"
    t.index ["week_id"], name: "index_tkc_costs_on_week_id"
  end

  create_table "unique_costs", force: :cascade do |t|
    t.bigint "tkc_cost_id", null: false
    t.string "description"
    t.decimal "amount", default: "0.0"
    t.decimal "price", default: "0.0"
    t.decimal "total", default: "0.0"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["tkc_cost_id"], name: "index_unique_costs_on_tkc_cost_id"
  end

  create_table "users", force: :cascade do |t|
    t.string "first_name"
    t.string "last_name"
    t.string "email"
    t.string "password_digest"
    t.string "remember_token"
    t.datetime "remember_token_expires_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.integer "role", default: 0
  end

  create_table "weeks", force: :cascade do |t|
    t.bigint "project_id", null: false
    t.integer "week_number"
    t.date "start_date"
    t.date "end_date"
    t.integer "year"
    t.integer "tkc_status"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.integer "status", default: 0
    t.string "note"
    t.index ["project_id"], name: "index_weeks_on_project_id"
  end

  add_foreign_key "active_storage_attachments", "active_storage_blobs", column: "blob_id"
  add_foreign_key "active_storage_variant_records", "active_storage_blobs", column: "blob_id"
  add_foreign_key "activities", "projects"
  add_foreign_key "client_contact_persons", "clients"
  add_foreign_key "contractor_contact_persons", "contractors"
  add_foreign_key "days", "projects"
  add_foreign_key "days", "weeks"
  add_foreign_key "debit_invoice_quote_details", "debit_invoice_quotes"
  add_foreign_key "debit_invoice_quotes", "clients"
  add_foreign_key "debit_invoices", "clients"
  add_foreign_key "disciplines", "clients"
  add_foreign_key "employee_certificates", "certificate_types"
  add_foreign_key "employee_certificates", "employees"
  add_foreign_key "employee_schedulings", "employees"
  add_foreign_key "employee_schedulings", "projects"
  add_foreign_key "employee_schedulings", "specification_codes"
  add_foreign_key "employee_schedulings", "weeks"
  add_foreign_key "employees", "contractors"
  add_foreign_key "employees", "roles"
  add_foreign_key "employees_clients", "clients"
  add_foreign_key "employees_clients", "employees"
  add_foreign_key "employees_teams", "employees"
  add_foreign_key "employees_teams", "teams"
  add_foreign_key "extra_costs", "projects"
  add_foreign_key "extra_costs", "weeks"
  add_foreign_key "finances", "clients"
  add_foreign_key "insurances", "equipment_materials"
  add_foreign_key "insurances", "materials"
  add_foreign_key "invoice_codes", "debit_invoices"
  add_foreign_key "invoice_codes", "invoices"
  add_foreign_key "invoice_codes", "specification_codes"
  add_foreign_key "invoice_details", "debit_invoices"
  add_foreign_key "invoice_details", "invoices"
  add_foreign_key "invoices", "clients"
  add_foreign_key "invoices", "contractors"
  add_foreign_key "lease_contracts", "equipment_materials"
  add_foreign_key "lease_contracts", "materials"
  add_foreign_key "material_attachments", "equipment_materials"
  add_foreign_key "material_attachments", "materials"
  add_foreign_key "notes", "equipment_materials"
  add_foreign_key "notes", "materials"
  add_foreign_key "notes", "users"
  add_foreign_key "plan_teams", "plans"
  add_foreign_key "plan_teams", "teams"
  add_foreign_key "plans", "activities"
  add_foreign_key "plans", "projects"
  add_foreign_key "plans", "weeks", column: "end_week_id"
  add_foreign_key "plans", "weeks", column: "start_week_id"
  add_foreign_key "project_disciplines", "disciplines"
  add_foreign_key "project_disciplines", "projects"
  add_foreign_key "projects", "clients"
  add_foreign_key "projects", "users"
  add_foreign_key "purchase_orders", "projects"
  add_foreign_key "purchase_orders", "specification_codes"
  add_foreign_key "purchase_orders", "weeks"
  add_foreign_key "selected_specification_codes", "projects"
  add_foreign_key "selected_specification_codes", "specification_codes"
  add_foreign_key "specification_codes", "clients"
  add_foreign_key "specification_codes", "disciplines"
  add_foreign_key "tkc_cost_amounts", "projects"
  add_foreign_key "tkc_cost_amounts", "specification_codes"
  add_foreign_key "tkc_cost_amounts", "tkc_costs"
  add_foreign_key "tkc_costs", "projects"
  add_foreign_key "tkc_costs", "weeks"
  add_foreign_key "unique_costs", "tkc_costs"
  add_foreign_key "weeks", "projects"
end
