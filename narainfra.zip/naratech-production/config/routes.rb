Rails.application.routes.draw do
  root to: "trestle/auth/sessions#new"
  resources :clients do
    resources :specification_codes
  end
  get "projects/:id/total_overview", to: "projects_admin/admin#total_overview", as: "total_overview_projects_admin"

  namespace :clients_admin do
    post "clients/import_excel", to: "admin#import_excel", as: :import_excel
  end

  resources :projects

  # namespace :admin do
  #   resources :clients do
  #     collection do
  #       post :import_excel
  #     end
  #   end
  # end
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
